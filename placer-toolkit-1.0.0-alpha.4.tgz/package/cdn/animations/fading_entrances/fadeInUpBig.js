import{a}from"../../chunks/chunk.Z6NCEETZ.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInUpBig};
