import{a}from"../../chunks/chunk.PP72VCB4.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInDownBig};
