import{a}from"../../chunks/chunk.TSZI2CPF.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInBottomRight};
