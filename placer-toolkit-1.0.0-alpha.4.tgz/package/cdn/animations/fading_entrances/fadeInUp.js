import{a}from"../../chunks/chunk.4CAEAIFN.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInUp};
