import{a}from"../../chunks/chunk.NU2STAMX.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInRight};
