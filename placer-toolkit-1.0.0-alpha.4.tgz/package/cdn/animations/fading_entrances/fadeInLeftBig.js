import{a}from"../../chunks/chunk.B27E7VEZ.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInLeftBig};
