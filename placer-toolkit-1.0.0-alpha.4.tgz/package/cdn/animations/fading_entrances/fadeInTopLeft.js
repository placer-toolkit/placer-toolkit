import{a}from"../../chunks/chunk.PBL2P7GX.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInTopLeft};
