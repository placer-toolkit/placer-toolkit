import{a}from"../../chunks/chunk.PCTA7J6C.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInTopRight};
