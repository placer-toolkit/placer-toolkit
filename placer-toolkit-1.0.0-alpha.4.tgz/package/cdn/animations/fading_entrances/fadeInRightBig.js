import{a}from"../../chunks/chunk.7QYDQTBC.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeInRightBig};
