import{a}from"../../chunks/chunk.N72C3VU3.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeIn};
