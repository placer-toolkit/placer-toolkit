import{a}from"../../chunks/chunk.3U3NAHEY.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateOutUpRight};
