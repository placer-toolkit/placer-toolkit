import{a}from"../../chunks/chunk.NE3XXRZM.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateOutDownRight};
