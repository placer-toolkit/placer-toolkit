import{a}from"../../chunks/chunk.IGMWK7NZ.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as flipOutY};
