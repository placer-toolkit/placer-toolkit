import{a}from"../../chunks/chunk.UJQFNBOE.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as flipInY};
