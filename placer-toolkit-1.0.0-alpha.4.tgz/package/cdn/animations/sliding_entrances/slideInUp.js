import{a}from"../../chunks/chunk.EMVTQD7Z.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as slideInUp};
