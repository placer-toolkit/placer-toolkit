import{a}from"../../chunks/chunk.ELYXTKTB.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as slideInRight};
