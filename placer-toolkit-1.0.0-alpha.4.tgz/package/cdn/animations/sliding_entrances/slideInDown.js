import{a}from"../../chunks/chunk.2SQLMTYR.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as slideInDown};
