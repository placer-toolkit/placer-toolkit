import{a}from"../../chunks/chunk.LGGEB3IB.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as backInLeft};
