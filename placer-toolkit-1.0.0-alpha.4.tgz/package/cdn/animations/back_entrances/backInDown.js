import{a}from"../../chunks/chunk.GUYJ76FZ.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as backInDown};
