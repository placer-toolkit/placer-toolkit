import{a}from"../../chunks/chunk.ECBLO7D3.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as hinge};
