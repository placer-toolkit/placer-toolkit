import{a}from"../../chunks/chunk.U7RBI2DC.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rollIn};
