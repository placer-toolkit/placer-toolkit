import{a}from"../../chunks/chunk.ZE2WQTE4.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as jackInTheBox};
