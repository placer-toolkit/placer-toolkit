import{a}from"../../chunks/chunk.5G3DFRPP.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as lightSpeedInRight};
