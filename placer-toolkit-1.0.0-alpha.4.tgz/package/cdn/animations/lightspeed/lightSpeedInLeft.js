import{a}from"../../chunks/chunk.SEIDC2AV.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as lightSpeedInLeft};
