import{a}from"../../chunks/chunk.KYRT75BX.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as zoomInRight};
