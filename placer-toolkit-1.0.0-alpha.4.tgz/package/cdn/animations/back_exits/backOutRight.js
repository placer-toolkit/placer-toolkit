import{a}from"../../chunks/chunk.KPQGFV2T.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as backOutRight};
