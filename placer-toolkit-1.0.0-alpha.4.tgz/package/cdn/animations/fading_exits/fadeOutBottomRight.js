import{a}from"../../chunks/chunk.6SP3MLBX.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutBottomRight};
