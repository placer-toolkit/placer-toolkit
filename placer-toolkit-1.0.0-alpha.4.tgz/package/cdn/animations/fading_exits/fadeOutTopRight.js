import{a}from"../../chunks/chunk.G443HDU2.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutTopRight};
