import{a}from"../../chunks/chunk.IJXVLI7F.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutUpBig};
