import{a}from"../../chunks/chunk.2K4PNLGV.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutDownBig};
