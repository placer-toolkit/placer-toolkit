import{a}from"../../chunks/chunk.2SM5MTG6.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOut};
