import{a}from"../../chunks/chunk.MO7QMIH2.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutRightBig};
