import{a}from"../../chunks/chunk.V3AEPIKH.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutBottomLeft};
