import{a}from"../../chunks/chunk.O537LU5E.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutTopLeft};
