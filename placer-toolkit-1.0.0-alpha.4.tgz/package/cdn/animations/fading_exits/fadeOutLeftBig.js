import{a}from"../../chunks/chunk.DG6SQOFC.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutLeftBig};
