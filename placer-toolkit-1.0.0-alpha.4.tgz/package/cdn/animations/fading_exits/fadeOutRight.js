import{a}from"../../chunks/chunk.EZBCPDK5.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutRight};
