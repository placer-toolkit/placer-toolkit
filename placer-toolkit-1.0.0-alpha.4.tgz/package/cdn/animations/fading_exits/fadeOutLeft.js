import{a}from"../../chunks/chunk.ZJK5UEUE.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutLeft};
