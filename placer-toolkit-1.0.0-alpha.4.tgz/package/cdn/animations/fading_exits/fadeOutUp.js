import{a}from"../../chunks/chunk.M256MZ2P.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutUp};
