import{a}from"../../chunks/chunk.22DZRUGL.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as fadeOutDown};
