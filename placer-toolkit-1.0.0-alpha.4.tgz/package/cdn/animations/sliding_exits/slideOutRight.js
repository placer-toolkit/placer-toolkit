import{a}from"../../chunks/chunk.M2NVAC3Z.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as slideOutRight};
