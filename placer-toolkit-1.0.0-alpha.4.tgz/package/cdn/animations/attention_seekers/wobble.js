import{a}from"../../chunks/chunk.LVUPLZGE.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as wobble};
