import{a}from"../../chunks/chunk.EDLGCMPJ.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as headShake};
