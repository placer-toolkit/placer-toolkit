import{a}from"../../chunks/chunk.6RYC5FEW.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as shake};
