import{a}from"../../chunks/chunk.HNKZJPU5.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as bounce};
