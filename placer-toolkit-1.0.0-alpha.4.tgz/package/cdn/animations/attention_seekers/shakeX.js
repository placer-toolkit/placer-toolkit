import{a}from"../../chunks/chunk.R4FKXVN2.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as shakeX};
