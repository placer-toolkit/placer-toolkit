import{a}from"../../chunks/chunk.TMAMLCL3.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as tada};
