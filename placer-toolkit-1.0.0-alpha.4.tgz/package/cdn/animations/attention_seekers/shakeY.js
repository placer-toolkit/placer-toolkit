import{a}from"../../chunks/chunk.X2UEAQ7T.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as shakeY};
