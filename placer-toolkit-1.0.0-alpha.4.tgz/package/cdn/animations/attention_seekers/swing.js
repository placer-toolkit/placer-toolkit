import{a}from"../../chunks/chunk.4VMSMOA5.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as swing};
