import{a}from"../../chunks/chunk.TSGCOVAS.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as jello};
