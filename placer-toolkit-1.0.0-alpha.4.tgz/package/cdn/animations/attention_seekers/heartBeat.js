import{a}from"../../chunks/chunk.NPYG3KBW.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as heartBeat};
