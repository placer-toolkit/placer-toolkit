import{a}from"../../chunks/chunk.UY4REGW5.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as flash};
