import{a}from"../../chunks/chunk.ORA34WZP.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rubberBand};
