import{a}from"../../chunks/chunk.MAQ3AU52.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateIn};
