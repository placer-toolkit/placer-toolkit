import{a}from"../../chunks/chunk.XNUSDBIN.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateInDownRight};
