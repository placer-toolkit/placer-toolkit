import{a}from"../../chunks/chunk.LHYUHRTC.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateInUpRight};
