import{a}from"../../chunks/chunk.MM4THVKJ.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateInUpLeft};
