import{a}from"../../chunks/chunk.5PONJGRH.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as rotateInDownLeft};
