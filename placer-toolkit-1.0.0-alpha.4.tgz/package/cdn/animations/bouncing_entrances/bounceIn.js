import{a}from"../../chunks/chunk.WLREBMFL.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as bounceIn};
