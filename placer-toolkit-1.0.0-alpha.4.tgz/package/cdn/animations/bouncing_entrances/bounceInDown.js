import{a}from"../../chunks/chunk.YPCDSPNA.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as bounceInDown};
