import{a}from"../../chunks/chunk.RFDMVIMA.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as bounceInRight};
