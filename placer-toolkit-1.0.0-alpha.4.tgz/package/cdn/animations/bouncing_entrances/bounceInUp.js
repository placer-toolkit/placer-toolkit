import{a}from"../../chunks/chunk.LWZCSGTE.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as bounceInUp};
