import{a,b}from"../chunks/chunk.U4YNKCI4.js";import"../chunks/chunk.E6MOE4FE.js";export{a as activeElements,b as getDeepestActiveElement};
