import{a}from"../chunks/chunk.LIZVMFP3.js";import"../chunks/chunk.E6MOE4FE.js";export{a as getOffset};
