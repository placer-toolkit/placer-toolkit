import"../chunks/chunk.E6MOE4FE.js";var n=t=>{let{activeElement:e}=document;e&&t.contains(e)&&document.activeElement?.blur()};export{n as blurActiveElement};
