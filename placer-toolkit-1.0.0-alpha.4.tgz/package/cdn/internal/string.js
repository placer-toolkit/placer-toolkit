import{a}from"../chunks/chunk.P7X6ERDI.js";import"../chunks/chunk.E6MOE4FE.js";export{a as uppercaseFirstLetter};
