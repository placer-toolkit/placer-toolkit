import{a}from"../chunks/chunk.64A22SHE.js";import"../chunks/chunk.E6MOE4FE.js";export{a as getText};
