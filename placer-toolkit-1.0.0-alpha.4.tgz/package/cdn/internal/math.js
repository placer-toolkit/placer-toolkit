import{a,b}from"../chunks/chunk.ZS4GILCB.js";import"../chunks/chunk.E6MOE4FE.js";export{a as clamp,b as uniqueID};
