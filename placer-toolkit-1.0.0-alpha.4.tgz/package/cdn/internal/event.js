import{a}from"../chunks/chunk.OOQOIJSK.js";import"../chunks/chunk.E6MOE4FE.js";export{a as waitForEvent};
