import{a}from"../chunks/chunk.H2EOXVSZ.js";import"../chunks/chunk.E6MOE4FE.js";export{a as watch};
