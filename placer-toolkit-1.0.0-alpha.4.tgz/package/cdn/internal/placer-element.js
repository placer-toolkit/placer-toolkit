import{g as a}from"../chunks/chunk.PLBYMK2K.js";import"../chunks/chunk.FKNAQN55.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PlacerElement};
