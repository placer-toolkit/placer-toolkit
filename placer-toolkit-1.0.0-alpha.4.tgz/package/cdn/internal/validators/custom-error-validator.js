import{a}from"../../chunks/chunk.TYUCUXHN.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as CustomErrorValidator};
