import{a}from"../../chunks/chunk.S5DN2ZZE.js";import"../../chunks/chunk.E6MOE4FE.js";export{a as MirrorValidator};
