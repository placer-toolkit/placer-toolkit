import{a,b}from"../chunks/chunk.V65QAGBQ.js";import"../chunks/chunk.E6MOE4FE.js";export{b as submitForm,a as submitOnEnter};
