import{a}from"../chunks/chunk.RQ34LIU5.js";import"../chunks/chunk.E6MOE4FE.js";export{a as parseSpaceDelimitedTokens};
