import{a}from"../chunks/chunk.UPTMZCQ7.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcInvalidEvent};
