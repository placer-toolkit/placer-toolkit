import"../chunks/chunk.E6MOE4FE.js";var e=class extends Event{constructor(){super("pc-lazy-change",{bubbles:!0,cancelable:!1,composed:!0})}};export{e as PcLazyChangeEvent};
