import{a}from"../chunks/chunk.JAVH5USB.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcStartEvent};
