import{a}from"../chunks/chunk.ONCZNBNA.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcRemoveEvent};
