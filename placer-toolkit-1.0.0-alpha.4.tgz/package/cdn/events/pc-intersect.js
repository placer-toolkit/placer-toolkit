import"../chunks/chunk.E6MOE4FE.js";var e=class extends Event{constructor(t){super("pc-intersect",{bubbles:!1,cancelable:!1,composed:!0}),this.detail=t}};export{e as PcIntersectEvent};
