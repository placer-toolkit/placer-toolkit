import{a}from"../chunks/chunk.B3IRGDRW.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcCloseEvent};
