import{a}from"../chunks/chunk.SOXONO4R.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcHoverEvent};
