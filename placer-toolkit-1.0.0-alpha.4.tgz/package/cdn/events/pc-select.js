import{a}from"../chunks/chunk.C4FIATXW.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcSelectEvent};
