import{a}from"../chunks/chunk.5C3US2KL.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcLoadEvent};
