import"../chunks/chunk.E6MOE4FE.js";var e=class extends Event{constructor(r){super("pc-include-error",{bubbles:!0,cancelable:!1,composed:!0}),this.detail=r}};export{e as PcIncludeErrorEvent};
