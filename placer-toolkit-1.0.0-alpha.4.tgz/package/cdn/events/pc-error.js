import{a}from"../chunks/chunk.V52RFTK3.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcErrorEvent};
