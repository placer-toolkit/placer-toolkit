import{a}from"../chunks/chunk.YRR4IRLY.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcClearEvent};
