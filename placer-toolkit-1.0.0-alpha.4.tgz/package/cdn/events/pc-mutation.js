import{a}from"../chunks/chunk.RV7PEGXR.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcMutationEvent};
