import{a}from"../chunks/chunk.Y452TQZB.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcAfterShowEvent};
