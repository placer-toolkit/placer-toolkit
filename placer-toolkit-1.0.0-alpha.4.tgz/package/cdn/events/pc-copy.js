import{a}from"../chunks/chunk.KZLUYESF.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcCopyEvent};
