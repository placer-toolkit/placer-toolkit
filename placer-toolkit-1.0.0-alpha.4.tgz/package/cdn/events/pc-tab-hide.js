import{a}from"../chunks/chunk.AZ2IVZIA.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcTabHideEvent};
