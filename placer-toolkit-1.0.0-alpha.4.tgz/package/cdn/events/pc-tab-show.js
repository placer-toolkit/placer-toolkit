import{a}from"../chunks/chunk.MQGHP5IK.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcTabShowEvent};
