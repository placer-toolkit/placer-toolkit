import{a}from"../chunks/chunk.BQPFQFVC.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcSubmenuOpeningEvent};
