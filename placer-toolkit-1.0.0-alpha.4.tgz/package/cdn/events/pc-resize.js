import{a}from"../chunks/chunk.44AADS42.js";import"../chunks/chunk.E6MOE4FE.js";export{a as PcResizeEvent};
