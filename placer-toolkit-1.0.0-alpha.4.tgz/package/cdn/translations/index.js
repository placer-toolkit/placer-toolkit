import{a,b,c}from"../chunks/chunk.ZPHZCJBG.js";import"../chunks/chunk.E6MOE4FE.js";export{c as LocalizeController,a as registerTranslation,b as update};
