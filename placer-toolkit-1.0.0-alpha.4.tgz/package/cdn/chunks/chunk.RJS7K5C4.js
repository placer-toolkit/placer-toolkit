import{a as l}from"./chunk.5PPF3EHL.js";import{a as m}from"./chunk.RXMQHF36.js";import{a as k}from"./chunk.W5PM7F34.js";import{a as v}from"./chunk.BSQP4EKW.js";import{a as c}from"./chunk.OVU4POJI.js";import{a as b}from"./chunk.43BYYM5E.js";import{a as f}from"./chunk.AGGS6MN5.js";import{a as n}from"./chunk.NOX5TXXZ.js";import{a as h,b as o,c as u,e as p}from"./chunk.PLBYMK2K.js";import{d as r,f as d}from"./chunk.FKNAQN55.js";import{a}from"./chunk.H2EOXVSZ.js";import{b as t}from"./chunk.E6MOE4FE.js";var g=`:host {
    display: inline-block;
}

.checkbox {
    display: inline-flex;
    align-items: flex-start;
    position: relative;
    font-family: var(--pc-font-sans);
    font-size: inherit;
    font-weight: var(--pc-form-control-value-font-weight);
    line-height: var(--pc-form-control-value-line-height);
    vertical-align: middle;
    cursor: pointer;
}

.control {
    display: inline-flex;
    position: relative;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    inline-size: var(--pc-form-control-toggle-size);
    block-size: var(--pc-form-control-toggle-size);
    background-color: transparent;
    color: var(--pc-color-primary-on-loud);
    border: var(--pc-form-control-border-width) var(--pc-border-style)
        var(--pc-form-control-border-color);
    border-radius: var(--pc-border-radius-s);
    font-size: inherit;
    transition: all var(--pc-transition-fast) ease-in-out;
}

.control pc-icon {
    opacity: 0;
    visibility: hidden;
    transition:
        opacity var(--pc-transition-fast) ease-in-out,
        visibility var(--pc-transition-fast) ease-in-out;
}

.checked .control pc-icon,
.indeterminate .control pc-icon {
    opacity: 1;
    visibility: visible;
}

.checked:not(> .fade-out) .control pc-icon {
    opacity: 1;
    visibility: visible;
}

.control.fade-out pc-icon {
    opacity: 0;
    visibility: hidden;
}

.input {
    position: absolute;
    margin: 0;
    padding: 0;
    opacity: 0;
    pointer-events: none;
}

pc-icon {
    display: inline-flex;
    font-size: inherit;
    scale: 0.8;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    .checkbox:not(.checked):not(.disabled) .control:hover {
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-border-color),
            var(--pc-color-mix-hover)
        );
    }
}

.checkbox:not(.checked):not(.disabled) .control:focus-visible {
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-border-color),
        var(--pc-color-mix-hover)
    );
}

.checkbox:not(.checked):not(.disabled) .control:active {
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-border-color),
        var(--pc-color-mix-active)
    );
}

.checkbox:not(.checked):not(.disabled) .input:focus-visible ~ .control {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.checked .control,
.indeterminate .control {
    background-color: var(--pc-form-control-activated-color);
    border-color: var(--pc-form-control-activated-color);
}

@media (hover: hover) {
    .checkbox.checked:not(.disabled) .control:hover,
    .checkbox.indeterminate:not(.disabled) .control:hover {
        background-color: color-mix(
            in oklab,
            var(--pc-form-control-activated-color),
            var(--pc-color-mix-hover)
        );
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-activated-color),
            var(--pc-color-mix-hover)
        );
    }
}

.checkbox.checked:not(.disabled) .control:focus-visible,
.checkbox.indeterminate:not(.disabled) .control:focus-visible {
    background-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-hover)
    );
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-hover)
    );
}

.checkbox.checked:not(.disabled) .control:active,
.checkbox.indeterminate:not(.disabled) .control:active {
    background-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-active)
    );
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-active)
    );
}

.checkbox.checked:not(.disabled) .input:focus-visible ~ .control,
.checkbox.indeterminate:not(.disabled) .input:focus-visible ~ .control {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

[part~="label"] {
    display: inline-flex;
    margin-inline-start: 0.5em !important;
}

:host([required]) [part~="label"]::after {
    content: var(--pc-form-control-required-content);
    color: var(--pc-form-control-required-content-color);
    margin-inline-start: var(--pc-form-control-required-content-offset);
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var e=class extends n{constructor(){super(...arguments);this.hasSlotController=new f(this,"hint");this.isFadingOut=!1;this.title="";this.name="";this._value=this.getAttribute("value")??null;this.size="medium";this.disabled=!1;this.checked=!1;this.indeterminate=!1;this.defaultChecked=this.hasAttribute("checked");this.required=!1;this.hint=""}static get validators(){let i=[b({validationProperty:"checked",validationElement:Object.assign(document.createElement("input"),{type:"checkbox",required:!0})})];return[...super.validators,...i]}get value(){let i=this._value||"on";return this.checked?i:null}set value(i){this._value=i}handleClick(){this.indeterminate||this.checked&&(this.isFadingOut=!0,setTimeout(()=>this.isFadingOut=!1,150)),this.hasInteracted=!0,this.checked=!this.checked,this.indeterminate=!1,this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))})}handleDefaultCheckedChange(){!this.hasInteracted&&this.checked!==this.defaultChecked&&(this.checked=this.defaultChecked,this.handleValueOrCheckedChange())}handleValueOrCheckedChange(){this.setValue(this.checked?this.value:null,this._value),this.updateValidity()}handleDisabledChange(){this.customStates.set("disabled",this.disabled)}handleStateChange(){!this.indeterminate&&this.checked&&(this.isFadingOut=!1),this.hasUpdated&&(this.input.checked=this.checked,this.input.indeterminate=this.indeterminate),this.customStates.set("checked",this.checked),this.customStates.set("indeterminate",this.indeterminate),this.updateValidity()}willUpdate(i){super.willUpdate(i),i.has("defaultChecked")&&(this.hasInteracted||(this.checked=this.defaultChecked)),(i.has("value")||i.has("checked"))&&this.handleValueOrCheckedChange()}formResetCallback(){this.checked=this.defaultChecked,super.formResetCallback(),this.handleValueOrCheckedChange()}click(){this.input.click()}focus(i){this.input.focus(i)}blur(){this.input.blur()}render(){let i=this.hasSlotController.test("hint"),s=this.hint?!0:!!i;return r`
            <label
                part="base"
                class=${c({checkbox:!0,checked:this.checked&&!this.isFadingOut,indeterminate:this.indeterminate,disabled:this.disabled})}
            >
                <input
                    class="input"
                    type="checkbox"
                    title=${this.title}
                    name=${this.name}
                    value=${m(this.value)}
                    .indeterminate=${l(this.indeterminate)}
                    .checked=${l(this.checked)}
                    .disabled=${this.disabled}
                    .required=${this.required}
                    aria-checked=${this.checked?"true":"false"}
                    aria-describedby=${this.hint?"hint":d}
                    @click=${this.handleClick}
                />

                <span
                    part="control ${this.checked?"checkbox-checked":""} ${this.indeterminate?"checkbox-indeterminate":""}"
                    class=${c({control:!0,"fade-in":this.checked&&!this.isFadingOut,"fade-out":this.isFadingOut})}
                >
                    ${this.checked||this.isFadingOut?r`
                              <pc-icon
                                  part="icon-checked"
                                  library="system"
                                  icon-style="solid"
                                  name="check"
                              ></pc-icon>
                          `:""}
                    ${this.indeterminate?r`
                              <pc-icon
                                  part="icon-indeterminate"
                                  library="system"
                                  icon-style="solid"
                                  name="minus"
                              ></pc-icon>
                          `:""}
                </span>

                <slot class="label" part="label"></slot>
            </label>

            <slot
                part="hint"
                class=${c({"has-hint":s})}
                name="hint"
                id="hint"
                aria-hidden=${s?"false":"true"}
            >
                ${this.hint}
            </slot>
        `}};e.css=[k,v,g],e.shadowRootOptions={...n.shadowRootOptions,delegatesFocus:!0},t([p('input[type="checkbox"]')],e.prototype,"input",2),t([u()],e.prototype,"isFadingOut",2),t([o()],e.prototype,"title",2),t([o()],e.prototype,"name",2),t([o({reflect:!0})],e.prototype,"value",1),t([o({reflect:!0})],e.prototype,"size",2),t([o({type:Boolean})],e.prototype,"disabled",2),t([o({type:Boolean,reflect:!0})],e.prototype,"checked",2),t([o({type:Boolean,reflect:!0})],e.prototype,"indeterminate",2),t([o({type:Boolean,reflect:!0,attribute:"checked"})],e.prototype,"defaultChecked",2),t([o({type:Boolean,reflect:!0})],e.prototype,"required",2),t([o()],e.prototype,"hint",2),t([a("defaultChecked")],e.prototype,"handleDefaultCheckedChange",1),t([a("disabled")],e.prototype,"handleDisabledChange",1),t([a(["checked","indeterminate"])],e.prototype,"handleStateChange",1),e=t([h("pc-checkbox")],e);export{e as a};
