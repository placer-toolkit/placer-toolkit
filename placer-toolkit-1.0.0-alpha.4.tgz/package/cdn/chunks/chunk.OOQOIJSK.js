function o(n,t){return new Promise(e=>{function r(i){i.target===n&&(n.removeEventListener(t,r),e())}n.addEventListener(t,r)})}export{o as a};
