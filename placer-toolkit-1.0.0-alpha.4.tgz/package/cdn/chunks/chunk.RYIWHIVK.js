import{a as o}from"./chunk.OVU4POJI.js";import{a as r,b as a,g as s}from"./chunk.PLBYMK2K.js";import{d as i}from"./chunk.FKNAQN55.js";import{a as l}from"./chunk.H2EOXVSZ.js";import{b as e}from"./chunk.E6MOE4FE.js";var p=`:host {
    display: none;
}

:host([active]) {
    display: block;
}

.tab-panel {
    display: block;
    padding: 0;
}
`;var n=0,t=class extends s{constructor(){super(...arguments);this.attributeID=++n;this.componentID=`pc-tab-panel-${this.attributeID}`;this.name="";this.active=!1}connectedCallback(){super.connectedCallback(),this.id=this.id.length>0?this.id:this.componentID,this.setAttribute("role","tabpanel")}handleActiveChange(){this.setAttribute("aria-hidden",this.active?"false":"true")}render(){return i`
            <slot
                part="base"
                class=${o({"tab-panel":!0,active:this.active})}
            ></slot>
        `}};t.css=p,e([a({reflect:!0})],t.prototype,"name",2),e([a({type:Boolean,reflect:!0})],t.prototype,"active",2),e([l("active")],t.prototype,"handleActiveChange",1),t=e([r("pc-tab-panel")],t);export{t as a};
