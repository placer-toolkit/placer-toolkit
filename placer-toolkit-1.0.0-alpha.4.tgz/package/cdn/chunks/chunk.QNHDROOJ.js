import{a as k}from"./chunk.OVU4POJI.js";import{a as A}from"./chunk.Y452TQZB.js";import{a as z}from"./chunk.OOPBLVP2.js";import{a as x}from"./chunk.OMC4FRTB.js";import{a as H}from"./chunk.GFCFF7RE.js";import{a as c,d as h,e as p}from"./chunk.RZZMGXAZ.js";import{a as m}from"./chunk.OOQOIJSK.js";import{a as d}from"./chunk.NOX5TXXZ.js";import{a as y,b as s,c as v,e as n,g as w}from"./chunk.PLBYMK2K.js";import{d as b}from"./chunk.FKNAQN55.js";import{a as g}from"./chunk.H2EOXVSZ.js";import{a as u,c as f}from"./chunk.N5AZOOIZ.js";import{a as E}from"./chunk.TBG3XWQL.js";import{b as r}from"./chunk.E6MOE4FE.js";var S=`:host {
    display: block;
}

.details {
    background-color: var(--pc-color-surface-default);
    color: var(--pc-color-text-normal);
    border: var(--pc-panel-border-width) var(--pc-panel-border-style)
        var(--pc-color-surface-border);
    border-radius: var(--pc-border-radius-l);
    overflow-anchor: none;
}

:host([variant~="outlined"]) .details {
    background-color: var(--pc-color-surface-default);
    border-color: var(--pc-color-surface-border);
}

:host([variant~="filled"]) .details {
    background-color: var(--pc-color-neutral-fill-quiet);
    border-color: transparent;
}

:host([variant~="filled"][variant~="outlined"]) .details {
    border-color: var(--pc-color-neutral-border-quiet);
}

:host([variant~="plain"]) .details {
    background-color: transparent;
    border-color: transparent;
}

.disabled {
    opacity: 0.5;
}

.header {
    display: flex;
    align-items: center;
    border-radius: var(--pc-border-radius-l);
    padding: var(--pc-spacing-m);
    user-select: none;
    -webkit-user-select: none;
    cursor: pointer;
    transition: border-radius var(--pc-transition-fast)
        cubic-bezier(0.55, 0, 0.55, 0.2);
}

.open .header {
    border-end-start-radius: 0;
    border-end-end-radius: 0;
    transition-timing-function: cubic-bezier(0.33, 1, 0.68, 1);
}

.header::-webkit-details-marker {
    display: none;
}

.header:focus {
    outline: none;
}

.header:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: calc(var(--pc-focus-ring-offset) + 0.0625rem);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.disabled .header {
    cursor: not-allowed;
}

.disabled .header:focus-visible {
    outline: none;
    box-shadow: none;
}

.summary {
    display: flex;
    align-items: center;
    flex: 1 1 auto;
}

.summary-icon {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    transition: rotate var(--pc-transition-fast) ease-in-out;
}

.open .summary-icon {
    rotate: 90deg;
}

.open.is-rtl .summary-icon {
    rotate: -90deg;
}

.open slot[name="expand-icon"],
.details:not(.open) slot[name="collapse-icon"] {
    display: none;
}

.body {
    overflow: hidden;
}

.content {
    display: block;
    padding: var(--pc-spacing-m);
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;u("details.show",{keyframes:[{blockSize:"0",opacity:"0"},{blockSize:"auto",opacity:"1"}],options:{duration:300,easing:"cubic-bezier(0.33, 1, 0.68, 1)"}});u("details.hide",{keyframes:[{blockSize:"auto",opacity:"1"},{blockSize:"0",opacity:"0"}],options:{duration:200,easing:"cubic-bezier(0.55, 0, 0.55, 0.2)"}});var t=class extends w{constructor(){super(...arguments);this.localize=new E(this);this.isAnimating=!1;this.open=!1;this.variant="outlined";this.disabled=!1}firstUpdated(){this.body.style.blockSize=this.open?"auto":"0",this.open&&(this.details.open=!0),this.detailsObserver=new MutationObserver(e=>{for(let a of e)a.type==="attributes"&&a.attributeName==="open"&&(this.details.open?this.show():this.hide())}),this.detailsObserver.observe(this.details,{attributes:!0})}disconnectedCallback(){super.disconnectedCallback(),this.detailsObserver?.disconnect()}handleSummaryClick(e){e.composedPath().some(i=>{if(!(i instanceof HTMLElement)||i===this.header)return!1;let l=i.tagName?.toLowerCase();return["a","button","input","textarea","select"].includes(l)?!0:i instanceof d?!("disabled"in i)||!i.disabled:!1})||(e.preventDefault(),this.disabled||(this.open?this.hide():this.show(),this.header.focus()))}handleSummaryKeyDown(e){e.composedPath().some(i=>{if(!(i instanceof HTMLElement)||i===this.header)return!1;let l=i.tagName?.toLowerCase();return["a","button","input","textarea","select"].includes(l)?!0:i instanceof d?!("disabled"in i)||!i.disabled:!1})||((e.key==="Enter"||e.key===" ")&&(e.preventDefault(),this.open?this.hide():this.show()),(e.key==="ArrowUp"||e.key==="ArrowLeft")&&(e.preventDefault(),this.hide()),(e.key==="ArrowDown"||e.key==="ArrowRight")&&(e.preventDefault(),this.show()))}async handleOpenChange(){if(this.open){this.details.open=!0;let e=new H;if(this.dispatchEvent(e),e.defaultPrevented){this.open=!1,this.details.open=!1;return}this.isAnimating=!0,await h(this.body);let{keyframes:a,options:o}=f(this,"details.show",{dir:this.localize.dir()});await c(this.body,p(a,this.body.scrollHeight),o),this.body.style.blockSize="auto",this.isAnimating=!1,this.dispatchEvent(new A)}else{let e=new x;if(this.dispatchEvent(e),e.defaultPrevented){this.details.open=!0,this.open=!0;return}this.isAnimating=!0,await h(this.body);let{keyframes:a,options:o}=f(this,"details.hide",{dir:this.localize.dir()});await c(this.body,p(a,this.body.scrollHeight),o),this.body.style.blockSize="auto",this.isAnimating=!1,this.details.open=!1,this.dispatchEvent(new z)}}async show(){if(!(this.open||this.disabled))return this.open=!0,m(this,"pc-after-show")}async hide(){if(!(!this.open||this.disabled))return this.open=!1,m(this,"pc-after-hide")}render(){let e=this.localize.dir()==="rtl";return b`
            <details
                part="base"
                class=${k({details:!0,open:this.open,disabled:this.disabled,"is-rtl":e})}
            >
                <summary
                    part="header"
                    class="header"
                    id="header"
                    role="button"
                    aria-expanded=${this.open?"true":"false"}
                    aria-controls="content"
                    aria-disabled=${this.disabled?"true":"false"}
                    tabindex=${this.disabled?"-1":"0"}
                    @click=${this.handleSummaryClick}
                    @keydown=${this.handleSummaryKeyDown}
                >
                    <slot class="summary" part="summary" name="summary">
                        ${this.summary}
                    </slot>

                    <span part="summary-icon" class="summary-icon">
                        <slot name="expand-icon">
                            <pc-icon
                                library="system"
                                icon-style="solid"
                                name=${e?"chevron-left":"chevron-right"}
                            ></pc-icon>
                        </slot>
                        <slot name="collapse-icon">
                            <pc-icon
                                library="system"
                                icon-style="solid"
                                name=${e?"chevron-left":"chevron-right"}
                            ></pc-icon>
                        </slot>
                    </span>
                </summary>

                <div
                    class="body"
                    part="body"
                    role="region"
                    aria-labelledby="header"
                >
                    <slot class="content" part="content" id="content"></slot>
                </div>
            </details>
        `}};t.css=S,r([n(".details")],t.prototype,"details",2),r([n(".header")],t.prototype,"header",2),r([n(".body")],t.prototype,"body",2),r([v()],t.prototype,"isAnimating",2),r([s({type:Boolean,reflect:!0})],t.prototype,"open",2),r([s()],t.prototype,"summary",2),r([s({reflect:!0})],t.prototype,"variant",2),r([s({type:Boolean})],t.prototype,"disabled",2),r([g("open",{waitUntilFirstUpdate:!0})],t.prototype,"handleOpenChange",1),t=r([y("pc-details")],t);export{t as a};
