var e=class extends Event{constructor(){super("pc-after-show",{bubbles:!0,cancelable:!1,composed:!0})}};export{e as a};
