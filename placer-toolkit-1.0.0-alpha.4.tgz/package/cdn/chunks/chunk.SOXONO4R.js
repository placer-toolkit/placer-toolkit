var e=class extends Event{constructor(t){super("pc-hover",{bubbles:!0,cancelable:!1,composed:!0}),this.detail=t}};export{e as a};
