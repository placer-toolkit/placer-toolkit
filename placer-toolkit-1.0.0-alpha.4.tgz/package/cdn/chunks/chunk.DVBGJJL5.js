import{a as k}from"./chunk.OVU4POJI.js";import{a as L}from"./chunk.Y452TQZB.js";import{a as E}from"./chunk.OOPBLVP2.js";import{a as C}from"./chunk.OMC4FRTB.js";import{a as T}from"./chunk.GFCFF7RE.js";import{a as l}from"./chunk.RZZMGXAZ.js";import{a as f}from"./chunk.P7X6ERDI.js";import{a as x}from"./chunk.AGGS6MN5.js";import{a as h,b as m}from"./chunk.R2GXUKDX.js";import{a as y,b as s,e as b,g}from"./chunk.PLBYMK2K.js";import{d as p}from"./chunk.FKNAQN55.js";import{a as S}from"./chunk.RQ34LIU5.js";import{a as v}from"./chunk.H2EOXVSZ.js";import{a as r,c}from"./chunk.N5AZOOIZ.js";import{a as z}from"./chunk.TBG3XWQL.js";import{b as o}from"./chunk.E6MOE4FE.js";var D=`:host {
    --size: 25rem;
    --header-spacing: var(--pc-spacing-xl);
    --body-spacing: var(--pc-spacing-s) var(--pc-spacing-xl);
    --footer-spacing: var(--pc-spacing-s) var(--pc-spacing-xl)
        var(--pc-spacing-xl);

    display: none;
}

:host([open]) {
    display: block;
}

.drawer {
    display: flex;
    flex-direction: column;
    inset-block-start: 0;
    inset-inline-start: 0;
    margin: 0;
    padding: 0;
    inline-size: 100%;
    max-inline-size: 100%;
    block-size: 100%;
    max-block-size: 100%;
    background-color: var(--pc-color-surface-raised);
    color: inherit;
    border: none;
    box-shadow: var(--pc-shadow-xl);
    overflow: auto;
}

.drawer::backdrop {
    background-color: var(--pc-color-overlay-modal);
}

.drawer.show::backdrop {
    animation: drawer-backdrop-open 0.3s cubic-bezier(0.23, 1, 0.32, 1);
}

.drawer.hide::backdrop {
    animation: drawer-backdrop-close 0.2s cubic-bezier(0.755, 0.05, 0.855, 0.06);
}

.drawer:focus {
    outline: none;
}

.top {
    inset-block-start: 0;
    inset-block-end: auto;
    inset-inline-start: 0;
    inset-inline-end: auto;
    inline-size: 100%;
    block-size: var(--size);
}

.end {
    inset-block-start: 0;
    inset-block-end: auto;
    inset-inline-start: auto;
    inset-inline-end: 0;
    inline-size: var(--size);
    block-size: 100%;
}

.bottom {
    inset-block-start: auto;
    inset-block-end: 0;
    inset-inline-start: 0;
    inset-inline-end: auto;
    inline-size: 100%;
    block-size: var(--size);
}

.start {
    inset-block-start: 0;
    inset-block-end: auto;
    inset-inline-start: 0;
    inset-inline-end: auto;
    inline-size: var(--size);
    block-size: 100%;
}

.header {
    display: flex;
    gap: var(--pc-spacing-l);
    flex: 0 0 auto;
    flex-wrap: nowrap;
    padding: var(--header-spacing);
}

.title {
    align-self: center;
    flex: 1 1 auto;
    margin: 0;
    font-family: inherit;
    font-size: var(--pc-font-size-l);
    font-weight: var(--pc-font-weight-bold);
    line-height: var(--pc-line-height-dense);
}

.header-actions {
    display: flex;
    align-self: flex-start;
    justify-content: flex-end;
    gap: var(--pc-spacing-xs);
    flex-shrink: 0;
    flex-wrap: wrap;
}

.header-actions pc-button,
.header-actions ::slotted(pc-button) {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
}

.body {
    display: block;
    flex: 1 1 auto;
    padding: var(--body-spacing);
    overflow: auto;
    -webkit-overflow-scrolling: touch;
}

.footer {
    flex: 0 0 auto;
    padding: var(--footer-spacing);
    text-align: end;
}

.footer ::slotted(pc-button:not(:first-of-type)) {
    margin-inline-start: var(--pc-spacing-xs);
}

.drawer:not(.has-footer) .footer {
    display: none;
}

.drawer:not(:has(> .header)) .body {
    --body-spacing: var(--pc-spacing-xl) var(--pc-spacing-xl)
        var(--pc-spacing-s) var(--pc-spacing-xl);
}

.drawer:not(.has-footer) .body {
    --body-spacing: var(--pc-spacing-s) var(--pc-spacing-xl)
        var(--pc-spacing-xl) var(--pc-spacing-xl);
}

.drawer:not(:has(> .header), .has-footer) .body {
    --body-spacing: var(--pc-spacing-xl);
}

@keyframes drawer-backdrop-open {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes drawer-backdrop-close {
    0% {
        opacity: 1;
    }

    100% {
        opacity: 0;
    }
}

@media (forced-colors: active) {
    .drawer-panel {
        border: 1px solid oklch(100% 0 0);
    }
}
`;document.addEventListener("click",u=>{let d=u.target.closest("[data-drawer]");if(d instanceof Element){let[e,t]=S(d.getAttribute("data-drawer")||"");if(e==="open"&&t?.length){let n=d.getRootNode().getElementById(t);n?.localName==="pc-drawer"?n.open=!0:console.warn(`A drawer with an id of \u201C${t}\u201D could not be found in this document.`)}}});document.addEventListener("pointerdown",()=>{});r("drawer.showTop",{keyframes:[{opacity:0,translate:"0 -100%"},{opacity:1,translate:"0 0"}],options:{duration:300,easing:"cubic-bezier(0.23, 1, 0.32, 1)"}});r("drawer.hideTop",{keyframes:[{opacity:1,translate:"0 0"},{opacity:0,translate:"0 -100%"}],options:{duration:200,easing:"cubic-bezier(0.755, 0.05, 0.855, 0.06)"}});r("drawer.showEnd",{keyframes:[{opacity:0,translate:"100%"},{opacity:1,translate:"0"}],rtlKeyframes:[{opacity:0,translate:"-100%"},{opacity:1,translate:"0"}],options:{duration:300,easing:"cubic-bezier(0.23, 1, 0.32, 1)"}});r("drawer.hideEnd",{keyframes:[{opacity:1,translate:"0"},{opacity:0,translate:"100%"}],rtlKeyframes:[{opacity:1,translate:"0"},{opacity:0,translate:"-100%"}],options:{duration:200,easing:"cubic-bezier(0.755, 0.05, 0.855, 0.06)"}});r("drawer.showBottom",{keyframes:[{opacity:0,translate:"0 100%"},{opacity:1,translate:"0 0"}],options:{duration:300,easing:"cubic-bezier(0.23, 1, 0.32, 1)"}});r("drawer.hideBottom",{keyframes:[{opacity:1,translate:"0 0"},{opacity:0,translate:"0 100%"}],options:{duration:200,easing:"cubic-bezier(0.755, 0.05, 0.855, 0.06)"}});r("drawer.showStart",{keyframes:[{opacity:0,translate:"-100%"},{opacity:1,translate:"0"}],rtlKeyframes:[{opacity:0,translate:"100%"},{opacity:1,translate:"0"}],options:{duration:300,easing:"cubic-bezier(0.23, 1, 0.32, 1)"}});r("drawer.hideStart",{keyframes:[{opacity:1,translate:"0"},{opacity:0,translate:"-100%"}],rtlKeyframes:[{opacity:1,translate:"0"},{opacity:0,translate:"100%"}],options:{duration:200,easing:"cubic-bezier(0.755, 0.05, 0.855, 0.06)"}});r("drawer.denyClose",{keyframes:[{scale:1},{scale:1.01},{scale:1}],options:{duration:250,easing:"cubic-bezier(0.68, -0.55, 0.265, 1.55)"}});var a=class extends g{constructor(){super(...arguments);this.hasSlotController=new x(this,"footer");this.localize=new z(this);this.open=!1;this.label="";this.placement="end";this.noHeader=!1;this.noLightDismiss=!1;this.handleDocumentKeyDown=e=>{e.key==="Escape"&&this.open&&(e.preventDefault(),e.stopPropagation(),this.requestClose(this.drawer))}}firstUpdated(){this.open&&(this.addOpenListeners(),this.drawer.showModal(),h(this))}disconnectedCallback(){super.disconnectedCallback(),m(this),this.removeOpenListeners()}async requestClose(e){let t=new C({source:e});if(this.dispatchEvent(t),t.defaultPrevented){this.open=!0;let w=c(this,"drawer.denyClose",{dir:this.localize.dir()});l(this.drawer,w.keyframes,w.options);return}this.removeOpenListeners(),this.drawer.classList.add("hide"),this.drawer.classList.remove("show");let i=c(this,`drawer.hide${f(this.placement)}`,{dir:this.localize.dir()});await l(this.drawer,i.keyframes,i.options),this.open=!1,this.drawer.close(),m(this);let n=this.originalTrigger;typeof n?.focus=="function"&&setTimeout(()=>n.focus()),this.dispatchEvent(new E)}addOpenListeners(){document.addEventListener("keydown",this.handleDocumentKeyDown)}removeOpenListeners(){document.removeEventListener("keydown",this.handleDocumentKeyDown)}handleDrawerCancel(e){e.preventDefault(),!this.drawer.classList.contains("hide")&&e.target===this.drawer&&this.requestClose(this.drawer)}handleDrawerClick(e){let i=e.target.closest('[data-drawer="close"]');i&&(e.stopPropagation(),this.requestClose(i))}async handleDrawerPointerDown(e){if(e.target===this.drawer)if(!this.noLightDismiss)this.requestClose(this.drawer);else{let t=c(this,"drawer.denyClose",{dir:this.localize.dir()});l(this.drawer,t.keyframes,t.options)}}handleOpenChange(){this.open&&!this.drawer.open?this.show():this.drawer.open&&(this.open=!0,this.requestClose(this.drawer))}async show(){let e=new T;if(this.dispatchEvent(e),e.defaultPrevented){this.open=!1;return}this.addOpenListeners(),this.originalTrigger=document.activeElement,this.open=!0,this.drawer.showModal(),h(this),requestAnimationFrame(()=>{let i=this.querySelector("[autofocus]");i&&typeof i.focus=="function"?i.focus():this.drawer.focus()}),this.drawer.classList.add("show"),this.drawer.classList.remove("hide");let t=c(this,`drawer.show${f(this.placement)}`,{dir:this.localize.dir()});l(this.drawer,t.keyframes,t.options),this.dispatchEvent(new L)}render(){return p`
            <dialog
                part="drawer"
                class=${k({drawer:!0,open:this.open,top:this.placement==="top",end:this.placement==="end",bottom:this.placement==="bottom",start:this.placement==="start","has-footer":this.hasSlotController.test("footer")})}
                @click=${this.handleDrawerClick}
                @pointerdown=${this.handleDrawerPointerDown}
                @cancel=${this.handleDrawerCancel}
            >
                ${this.noHeader?"":p`
                          <header part="header" class="header">
                              <h2 part="title" class="title" id="title">
                                  <slot name="label">
                                      ${this.label.length>0?this.label:"\u200B"}
                                  </slot>
                              </h2>
                              <div part="header-actions" class="header-actions">
                                  <slot name="header-actions"></slot>
                                  <pc-button
                                      part="close-button"
                                      class="drawer-close"
                                      size="small"
                                      variant="plain"
                                      exportparts="base:close-button-base"
                                      @click=${e=>this.requestClose(e.target)}
                                  >
                                      <pc-icon
                                          library="system"
                                          icon-style="solid"
                                          name="xmark"
                                          label=${this.localize.term("close")}
                                      ></pc-icon>
                                  </pc-button>
                              </div>
                          </header>
                      `}

                <div part="body" class="body" tabindex="-1">
                    <slot></slot>
                </div>

                <footer part="footer" class="footer">
                    <slot name="footer"></slot>
                </footer>
            </dialog>
        `}};a.css=D,o([b(".drawer")],a.prototype,"drawer",2),o([s({type:Boolean,reflect:!0})],a.prototype,"open",2),o([s({reflect:!0})],a.prototype,"label",2),o([s({reflect:!0})],a.prototype,"placement",2),o([s({attribute:"no-header",type:Boolean,reflect:!0})],a.prototype,"noHeader",2),o([s({attribute:"no-light-dismiss",type:Boolean})],a.prototype,"noLightDismiss",2),o([v("open",{waitUntilFirstUpdate:!0})],a.prototype,"handleOpenChange",1),a=o([y("pc-drawer")],a);export{a};
