import{a as i}from"./chunk.IX4OV3X6.js";import{a as n}from"./chunk.BSQP4EKW.js";import{a as s}from"./chunk.ONCZNBNA.js";import{a as l,b as o,g as a}from"./chunk.PLBYMK2K.js";import{d as t}from"./chunk.FKNAQN55.js";import{a as c}from"./chunk.TBG3XWQL.js";import{b as r}from"./chunk.E6MOE4FE.js";var p=`:host {
    display: inline-flex;
    align-items: center;
    gap: 0.5em;
    padding-inline: 0.75em;
    background-color: var(--pc-color-fill-quiet);
    color: var(--pc-color-on-quiet);
    border: var(--pc-border-width-s) var(--pc-border-style)
        var(--pc-color-border-normal);
    border-radius: var(--pc-border-radius-m);
    block-size: calc(var(--pc-form-control-height) * 0.8);
    line-height: calc(
        var(--pc-form-control-height) - var(--pc-form-control-border-width) * 2
    );
    white-space: nowrap;
    user-select: none;
    -webkit-user-select: none;
}

:host([variant~="accent"]) {
    background-color: var(--pc-color-fill-loud);
    color: var(--pc-color-on-loud);
    border-color: transparent;
}

:host([variant~="outlined"]) {
    background-color: transparent;
    color: var(--pc-color-on-quiet);
    border-color: var(--pc-color-border-loud);
}

:host([variant~="filled"]) {
    background-color: var(--pc-color-fill-quiet);
    color: var(--pc-color-on-quiet);
    border-color: transparent;
}

:host([variant~="filled"][variant~="outlined"]) {
    border-color: var(--pc-color-border-normal);
}

:host([pill]) {
    border-radius: var(--pc-border-radius-pill);
}

.remove-tag-button {
    inline-size: 0.75em;
    block-size: 0.75em;
}

.remove-tag-button::part(base) {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    inline-size: 0.75em;
    block-size: 0.75em;
    background-color: transparent;
    color: var(--pc-color-on-quiet);
    font-size: var(--pc-font-size-smaller);
}
`;var e=class extends a{constructor(){super(...arguments);this.localize=new c(this);this.appearance="neutral";this.variant="filled outlined";this.size="medium";this.pill=!1;this.removable=!1}handleRemoveClick(){this.dispatchEvent(new s)}render(){return t`
            <slot class="tag-content" part="content"></slot>

            ${this.removable?t`
                      <pc-button
                          class="remove-tag-button"
                          part="remove-button"
                          tabindex="-1"
                          @click=${this.handleRemoveClick}
                          exportparts="base:remove-button-base"
                      >
                          <pc-icon
                              library="system"
                              icon-style="solid"
                              name="xmark"
                              label=${this.localize.term("remove")}
                          ></pc-icon>
                      </pc-button>
                  `:""}
        `}};e.css=[i,n,p],r([o({reflect:!0})],e.prototype,"appearance",2),r([o({reflect:!0})],e.prototype,"variant",2),r([o({reflect:!0})],e.prototype,"size",2),r([o({type:Boolean,reflect:!0})],e.prototype,"pill",2),r([o({type:Boolean})],e.prototype,"removable",2),e=r([l("pc-tag")],e);export{e as a};
