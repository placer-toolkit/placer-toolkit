import{a as h}from"./chunk.W5PM7F34.js";import{a as d}from"./chunk.BSQP4EKW.js";import{a as s}from"./chunk.OVU4POJI.js";import{a as n}from"./chunk.NOX5TXXZ.js";import{a,b as t,c}from"./chunk.PLBYMK2K.js";import{d as l}from"./chunk.FKNAQN55.js";import{b as e}from"./chunk.E6MOE4FE.js";var v=`:host {
    display: inline-block;
}

:host(:focus-visible) {
    outline: 0;
}

.radio {
    display: inline-flex;
    align-items: flex-start;
    position: relative;
    font-family: var(--pc-font-sans);
    font-size: inherit;
    font-weight: var(--pc-form-control-value-font-weight);
    line-height: var(--pc-form-control-value-line-height);
    vertical-align: middle;
    cursor: pointer;
}

.control {
    display: inline-flex;
    position: relative;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    inline-size: var(--pc-form-control-toggle-size);
    block-size: var(--pc-form-control-toggle-size);
    background-color: transparent;
    color: var(--pc-color-surface-default);
    border: var(--pc-form-control-border-width) var(--pc-border-style)
        var(--pc-form-control-border-color);
    border-radius: var(--pc-border-radius-circle);
    font-size: inherit;
    transition: all var(--pc-transition-fast) ease-in-out;
}

.control svg {
    display: inline-flex;
    inline-size: var(--pc-form-control-toggle-size);
    block-size: var(--pc-form-control-toggle-size);
    font-size: inherit;
    scale: 0.8;
    opacity: 0;
    visibility: hidden;
    transition: all var(--pc-transition-fast) ease-in-out;
}

.checked .control svg {
    opacity: 1;
    visibility: visible;
}

@media (hover: hover) {
    .radio:not(.checked):not(.disabled) .control:hover {
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-border-color),
            var(--pc-color-mix-hover)
        );
    }
}

.radio:not(.checked):not(.disabled) .control:focus-visible {
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-border-color),
        var(--pc-color-mix-hover)
    );
}

.radio:not(.checked):not(.disabled) .control:active {
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-border-color),
        var(--pc-color-mix-active)
    );
}

:host(:focus-visible) .control {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.checked .control {
    background-color: var(--pc-form-control-activated-color);
    border-color: var(--pc-form-control-activated-color);
}

@media (hover: hover) {
    .radio.checked:not(.disabled) .control:hover {
        background-color: var(--pc-form-control-activated-color);
        border-color: var(--pc-form-control-activated-color);
    }
}

.radio.checked:not(.disabled) .control:focus-visible {
    background-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-hover)
    );
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-hover)
    );
}

.radio.checked:not(.disabled) .control:active {
    background-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-active)
    );
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-active)
    );
}

.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

[part~="label"] {
    display: inline-block;
    margin-inline-start: 0.5em !important;
}

/* If the radio isn\u2019t checked, hide the circle icon in High Contrast mode on Windows */
.radio:not(.checked) svg {
    opacity: 0;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var o=class extends n{constructor(){super();this.checked=!1;this.forceDisabled=!1;this.size="medium";this.disabled=!1;this.handleClick=()=>{!this.disabled&&!this.checked&&(this.checked=!0)};this.addEventListener("click",this.handleClick)}connectedCallback(){super.connectedCallback(),this.setInitialAttributes()}setInitialAttributes(){this.setAttribute("role","radio"),this.setAttribute("tabindex","-1"),this.setAttribute("aria-disabled",this.disabled?"true":"false")}updated(r){if(super.updated(r),r.has("checked")&&(this.customStates.set("checked",this.checked),this.setAttribute("aria-checked",this.checked?"true":"false"),!this.disabled&&!this.forceDisabled&&(this.tabIndex=this.checked?0:-1)),r.has("disabled")||r.has("forceDisabled")){let i=this.disabled||this.forceDisabled;this.customStates.set("disabled",i),this.setAttribute("aria-disabled",i?"true":"false"),i?this.tabIndex=-1:this.tabIndex=this.checked?0:-1}}setValue(){}render(){return l`
            <span
                part="base"
                class=${s({radio:!0,checked:this.checked,disabled:this.disabled})}
            >
                <span
                    class="control"
                    part="${`control ${this.checked?"control-checked":""}`}"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        class="checked-icon"
                        part="checked-icon"
                        viewBox="0 0 16 16"
                    >
                        <circle cx="8" cy="8" r="4.5" fill="currentColor" />
                    </svg>
                </span>

                <slot class="label" part="label"></slot>
            </span>
        `}};o.css=[h,d,v],e([c()],o.prototype,"checked",2),e([c()],o.prototype,"forceDisabled",2),e([t()],o.prototype,"value",2),e([t({reflect:!0})],o.prototype,"size",2),e([t({type:Boolean})],o.prototype,"disabled",2),o=e([a("pc-radio")],o);export{o as a};
