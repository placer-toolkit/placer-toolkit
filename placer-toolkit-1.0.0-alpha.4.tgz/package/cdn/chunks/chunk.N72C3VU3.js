var o=[{offset:0,opacity:"0"},{offset:1,opacity:"1"}];export{o as a};
