import{a as h}from"./chunk.64A22SHE.js";import{a as o,b as s,c as i,e as n,g as c}from"./chunk.PLBYMK2K.js";import{d as r}from"./chunk.FKNAQN55.js";import{a as d}from"./chunk.TBG3XWQL.js";import{b as a}from"./chunk.E6MOE4FE.js";var u=`:host {
    display: flex;
    position: relative;
    align-items: center;
    padding-inline-start: 0.5em;
    padding-inline-end: 1.75em;
    padding-block: 0.5em;
    color: var(--pc-color-text-normal);
    border-radius: var(--pc-border-radius-m);
    font: inherit;
    line-height: var(--pc-line-height-dense);
    user-select: none;
    -webkit-user-select: none;
    cursor: pointer;
    transition: all var(--pc-transition-fast) ease-in-out;
}

:host(:focus) {
    outline: none;
}

@media (hover: hover) {
    :host(:hover:not([disabled], :state(current)):is(:state(hover), :hover)) {
        background-color: var(--pc-color-neutral-fill-normal);
        color: var(--pc-color-neutral-on-normal);
    }
}

:host(:active:not([disabled], :state(current)):state(hover)),
:host(:active:not([disabled], :state(current))) {
    background-color: color-mix(
        in oklab,
        var(--pc-color-neutral-fill-normal),
        var(--pc-color-mix-active)
    );
    color: color-mix(
        in oklab,
        var(--pc-color-neutral-on-normal),
        var(--pc-color-mix-active)
    );
}

:host(:state(current)),
:host([disabled]:state(current)) {
    background-color: var(--pc-color-neutral-fill-normal);
    color: var(--pc-color-neutral-on-normal);
    opacity: 1;
}

:host([disabled]) {
    outline: none;
    opacity: 0.5;
    cursor: not-allowed;
}

.label {
    display: inline-block;
    flex: 1 1 auto;
}

.check {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    visibility: hidden;
    font-size: var(--pc-font-size-smaller);
    padding-inline-end: 0.5em;
}

:host(:state(selected)) .check {
    visibility: visible;
}

.prefix,
.suffix {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
}

.prefix::slotted(*) {
    margin-inline-end: 0.5em;
}

.suffix::slotted(*) {
    margin-inline-start: 0.5em;
}

@media (forced-colors: active) {
    :host(:hover:not([aria-disabled="true"])) {
        outline: 1px dashed SelectedItem;
        outline-offset: -1px;
    }
}
`;var t=class extends c{constructor(){super(...arguments);this.isInitialized=!1;this.localize=new d(this);this.current=!1;this.defaultLabel="";this.value="";this.disabled=!1;this.selected=!1;this.defaultSelected=!1;this._label="";this.handleHover=e=>{e.type==="mouseenter"?this.customStates.set("hover",!0):e.type==="mouseleave"&&this.customStates.set("hover",!1)}}get label(){return this._label?this._label:(this.defaultLabel||this.updateDefaultLabel(),this.defaultLabel)}set label(e){let l=this._label;this._label=e||"",this._label!==l&&this.requestUpdate("label",l)}connectedCallback(){super.connectedCallback(),this.setAttribute("role","option"),this.setAttribute("aria-selected","false"),this.addEventListener("mouseenter",this.handleHover),this.addEventListener("mouseleave",this.handleHover),this.updateDefaultLabel()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseenter",this.handleHover),this.removeEventListener("mouseleave",this.handleHover)}handleDefaultSlotChange(){this.updateDefaultLabel(),this.isInitialized?customElements.whenDefined("pc-select").then(()=>{let e=this.closest("pc-select");e&&(e.handleDefaultSlotChange(),e.selectionChanged?.())}):this.isInitialized=!0}willUpdate(e){if(e.has("defaultSelected")&&!this.closest("pc-select")?.hasInteracted&&this.defaultSelected){let l=this.selected;this.selected=this.defaultSelected,this.requestUpdate("selected",l)}super.willUpdate(e)}updated(e){super.updated(e),e.has("disabled")&&this.setAttribute("aria-disabled",this.disabled?"true":"false"),e.has("selected")&&(this.setAttribute("aria-selected",this.selected?"true":"false"),this.customStates.set("selected",this.selected),this.handleDefaultSlotChange()),e.has("value")&&(typeof this.value!="string"&&(this.value=String(this.value)),this.handleDefaultSlotChange()),e.has("current")&&this.customStates.set("current",this.current)}firstUpdated(e){if(super.firstUpdated(e),this.selected&&!this.defaultSelected){let l=this.closest("pc-select");l&&!l.hasInteracted&&l.selectionChanged?.()}}updateDefaultLabel(){let e=this.defaultLabel;this.defaultLabel=h(this).trim();let l=this.defaultLabel!==e;return!this._label&&l&&this.requestUpdate("label",e),l}render(){return r`
            <pc-icon
                class="check"
                part="checked-icon"
                library="system"
                icon-style="solid"
                name="check"
                aria-hidden="true"
            ></pc-icon>
            <slot class="prefix" part="prefix" name="prefix"></slot>
            <slot
                class="label"
                part="label"
                @slotchange=${this.handleDefaultSlotChange}
            ></slot>
            <slot class="suffix" part="suffix" name="prefix"></slot>
        `}};t.css=u,a([n(".label")],t.prototype,"defaultSlot",2),a([i()],t.prototype,"current",2),a([i()],t.prototype,"defaultLabel",2),a([s({reflect:!0})],t.prototype,"value",2),a([s({type:Boolean})],t.prototype,"disabled",2),a([s({type:Boolean,attribute:!1})],t.prototype,"selected",2),a([s({type:Boolean,attribute:"selected"})],t.prototype,"defaultSelected",2),a([s()],t.prototype,"label",1),t=a([o("pc-option")],t);export{t as a};
