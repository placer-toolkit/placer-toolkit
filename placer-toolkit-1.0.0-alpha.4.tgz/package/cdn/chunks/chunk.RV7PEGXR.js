var t=class extends Event{constructor(e){super("pc-mutation",{bubbles:!0,cancelable:!1,composed:!0}),this.detail=e}};export{t as a};
