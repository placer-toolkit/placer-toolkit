var e=class extends Event{constructor(a){super("pc-tab-show",{bubbles:!0,cancelable:!1,composed:!0}),this.detail=a}};export{e as a};
