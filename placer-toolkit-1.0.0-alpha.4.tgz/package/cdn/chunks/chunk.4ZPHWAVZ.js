import{a as c}from"./chunk.IX4OV3X6.js";import{a as i}from"./chunk.BSQP4EKW.js";import{a as l,b as e,g as t}from"./chunk.PLBYMK2K.js";import{d as a}from"./chunk.FKNAQN55.js";import{b as o}from"./chunk.E6MOE4FE.js";var n=`.callout {
    display: flex;
    position: relative;
    align-items: stretch;
    background-color: var(--pc-color-fill-quiet);
    color: var(--pc-color-text-normal);
    border: var(--pc-panel-border-width) var(--pc-panel-border-style)
        var(--pc-color-border-quiet);
    border-radius: var(--pc-panel-border-radius);
    padding: 1em;
}

/* This is a fallback for Markdown and MDX */
.callout ::slotted(p) {
    margin: 0;
}

:host([variant~="accent"]) .callout {
    background-color: var(--pc-color-fill-loud);
    color: var(--pc-color-on-loud);
    border-color: transparent;

    [part~="icon"] {
        color: currentColor;
    }
}

:host([variant~="outlined"]) .callout {
    background-color: transparent;
    border-color: var(--pc-color-border-loud);
}

:host([variant~="filled"]) .callout {
    background-color: var(--pc-color-fill-quiet);
    border-color: transparent;
}

:host([variant~="filled"][variant~="outlined"]) .callout {
    border-color: var(--pc-color-border-quiet);
}

:host([variant~="plain"]) .callout {
    background-color: transparent;
    border-color: transparent;
}

.callout [part~="icon"] {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    color: var(--pc-color-on-quiet);
    font-size: 1.25em;
}

.callout ::slotted([slot="icon"]) {
    margin-inline-end: var(--pc-form-control-padding-inline);
}

.callout [part~="message"] {
    display: block;
    flex: 1 1 auto;
    overflow: hidden;
}
`;var r=class extends t{constructor(){super(...arguments);this.appearance="primary";this.variant="filled outlined";this.size="medium"}render(){return a`
            <aside part="base" class="callout">
                <div part="icon">
                    <slot name="icon" aria-hidden="true"></slot>
                </div>

                <div part="message">
                    <slot></slot>
                </div>
            </aside>
        `}};r.css=[c,i,n],o([e({reflect:!0})],r.prototype,"appearance",2),o([e({reflect:!0})],r.prototype,"variant",2),o([e({reflect:!0})],r.prototype,"size",2),r=o([l("pc-callout")],r);export{r as a};
