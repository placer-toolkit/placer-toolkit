import{a as v}from"./chunk.4Q2NU4EV.js";import{a}from"./chunk.GG6CNHGL.js";import{a as u}from"./chunk.OVU4POJI.js";import{a as l}from"./chunk.ZS4GILCB.js";import{a as y}from"./chunk.ZLITPNV3.js";import{a as p,b as h,e as n,g as f}from"./chunk.PLBYMK2K.js";import{d}from"./chunk.FKNAQN55.js";import{a as m}from"./chunk.H2EOXVSZ.js";import{a as b}from"./chunk.TBG3XWQL.js";import{b as o}from"./chunk.E6MOE4FE.js";var z=`:host {
    --divider-width: 0.125rem;
    --handle-size: 2.5rem;

    display: inline-block;
    position: relative;
}

.comparer {
    display: block;
    inline-size: 100%;
    max-inline-size: 100%;
    block-size: 100%;
    max-block-size: 100%;
    overflow: hidden;
}

.content {
    block-size: 100%;
}

.before-content,
.after-content {
    display: block;
    pointer-events: none;
    block-size: 100%;
}

.before-content ::slotted(*),
.after-content ::slotted(*) {
    display: block;
    max-inline-size: 100% !important;
    block-size: auto;
    border-radius: var(--pc-border-radius-m);
}

.after-content {
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    inline-size: 100%;
    block-size: 100%;
}

.divider {
    display: flex;
    position: absolute;
    align-items: center;
    justify-content: center;
    inset-block-start: 0;
    inline-size: var(--divider-width);
    block-size: 100%;
    background-color: var(--pc-color-surface-default);
    translate: calc(var(--divider-width) / -2);
    cursor: ew-resize;
}

.handle {
    display: flex;
    position: absolute;
    align-items: center;
    justify-content: center;
    inset-block-start: calc(50% - (var(--handle-size) / 2));
    inline-size: var(--handle-size);
    block-size: var(--handle-size);
    background-color: var(--pc-color-surface-default);
    border-radius: var(--pc-border-radius-circle);
    font-size: calc(var(--handle-size) * 0.4);
    color: var(--pc-color-neutral-on-quiet);
    cursor: inherit;
    z-index: 10;
}

.handle:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var t=class extends f{constructor(){super(...arguments);this.localize=new b(this);this.position=50}handleDrag(i){let{width:r}=this.base.getBoundingClientRect(),s=this.localize.dir()==="rtl";i.preventDefault(),y(this.base,{onMove:e=>{let c=parseFloat(l(e/r*100,0,100).toFixed(2));s?this.position=c:this.position=parseFloat((100-c).toFixed(2))},initialEvent:i})}handleKeyDown(i){let r=this.localize.dir()==="rtl";if(["ArrowLeft","ArrowRight","Home","End"].includes(i.key)){let s=i.shiftKey?10:1;i.preventDefault();let e=r?this.position:100-this.position;i.key==="ArrowLeft"&&(e-=s),i.key==="ArrowRight"&&(e+=s),i.key==="Home"&&(e=0),i.key==="End"&&(e=100),e=l(e,0,100),r?this.position=parseFloat(e.toFixed(2)):this.position=parseFloat((100-e).toFixed(2))}}handlePositionChange(){this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}render(){let i=this.localize.dir()==="rtl";return d`
            <div
                part="base"
                class=${u({comparer:!0,"is-rtl":i})}
                id="comparer"
                @keydown=${this.handleKeyDown}
            >
                <div class="content">
                    <div part="before" class="before-content">
                        <slot name="before"></slot>
                    </div>

                    <div
                        part="after"
                        class="after-content"
                        style=${a({clipPath:i?`inset(0 ${100-this.position}% 0 0)`:`inset(0 0 0 ${100-this.position}%)`})}
                    >
                        <slot name="after"></slot>
                    </div>
                </div>

                <div
                    part="divider"
                    class="divider"
                    style=${a({left:i?`${this.position}%`:`${100-this.position}%`})}
                    @mousedown=${this.handleDrag}
                    @touchstart=${this.handleDrag}
                >
                    <div
                        part="handle"
                        class="handle"
                        role="scrollbar"
                        aria-orientation="horizontal"
                        aria-valuenow=${this.position}
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-controls="comparer"
                        tabindex="0"
                    >
                        <slot name="handle">
                            <pc-icon
                                library="system"
                                icon-style="solid"
                                name="grip-vertical"
                            ></pc-icon>
                        </slot>
                    </div>
                </div>
            </div>
        `}};t.css=z,t.scopedElement={"pc-icon":v},o([n(".comparer")],t.prototype,"base",2),o([n(".handle")],t.prototype,"handle",2),o([h({type:Number,reflect:!0})],t.prototype,"position",2),o([m("position",{waitUntilFirstUpdate:!0})],t.prototype,"handlePositionChange",1),t=o([p("pc-comparer")],t);export{t as a};
