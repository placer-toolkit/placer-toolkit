import{a as v}from"./chunk.V52RFTK3.js";import{a as E}from"./chunk.5C3US2KL.js";import{a as f,b as s,c as g,g as b}from"./chunk.PLBYMK2K.js";import{d as p}from"./chunk.FKNAQN55.js";import{a as d}from"./chunk.H2EOXVSZ.js";import{a as w,b as R,c}from"./chunk.IONUBRP7.js";import{b as r}from"./chunk.E6MOE4FE.js";var S=`:host {
    --fa-primary-color: currentColor;
    --fa-secondary-color: currentColor;
    --fa-primary-opacity: 1;
    --fa-secondary-opacity: 0.4;

    display: inline-flex;
    justify-content: center;
    box-sizing: content-box !important;
    inline-size: auto;
    block-size: 1em;
}

svg {
    display: inline-block;
    inline-size: auto;
    block-size: inherit;
    fill: currentColor;
    overflow: visible;
}

/* Fixed\u2010width icons */
:host([library="default"]:not([auto-width])) svg *,
:host([library="system"]:not([auto-width])) svg * {
    /* This scaling gets rid of the whitespace around the icon grid. */
    scale: 1.25;
    transform-origin: center;
}

/* Primary layer */
svg path[data-duotone-primary] {
    color: var(--fa-primary-color);
    opacity: var(--fa-primary-opacity);
}

/* Secondary layer */
svg path[data-duotone-secondary] {
    color: var(--fa-secondary-color);
    opacity: var(--fa-secondary-opacity);
}
`;var n=Symbol(),u=Symbol(),m,y=new Map,e=class extends b{constructor(){super(...arguments);this.svg=null;this.iconStyle="solid";this.autoWidth=!1;this.swapOpacity=!1;this.label="";this.library="default";this.resolveIcon=async(t,o)=>{let i;if(o?.spriteSheet){this.hasUpdated||await this.updateComplete,this.svg=p`
                <svg part="svg">
                    <use part="use" href=${t}></use>
                </svg>
            `,await this.updateComplete;let a=this.shadowRoot.querySelector('[part="svg"]');return typeof o.mutator=="function"&&o.mutator(a,this),this.svg}try{if(i=await fetch(t,{mode:"cors"}),!i.ok)return i.status===410?n:u}catch{return u}try{let a=document.createElement("div");a.innerHTML=await i.text();let l=a.firstElementChild;if(l?.tagName?.toLowerCase()!=="svg")return n;m||(m=new DOMParser);let h=m.parseFromString(l.outerHTML,"text/html").body.querySelector("svg");return h?(h.part.add("svg"),document.adoptNode(h)):n}catch{return n}}}connectedCallback(){super.connectedCallback(),w(this)}firstUpdated(t){super.firstUpdated(t),this.setIcon()}disconnectedCallback(){super.disconnectedCallback(),R(this)}getIconSource(){let t=c(this.library);return this.name&&t?{url:t.resolver(this.name,this.iconStyle,this.autoWidth),fromLibrary:!0}:{url:this.src,fromLibrary:!1}}handleLabelChange(){typeof this.label=="string"&&this.label.length>0?(this.setAttribute("role","img"),this.setAttribute("aria-label",this.label),this.removeAttribute("aria-hidden")):(this.removeAttribute("role"),this.removeAttribute("aria-label"),this.setAttribute("aria-hidden","true"))}async setIcon(){let{url:t,fromLibrary:o}=this.getIconSource(),i=o?c(this.library):void 0;if(!t){this.svg=null;return}let a=y.get(t);a||(a=this.resolveIcon(t,i),y.set(t,a));let l=await a;if(l===u&&y.delete(t),t===this.getIconSource().url)switch(l){case u:case n:this.svg=null,this.dispatchEvent(new v);break;default:this.svg=l.cloneNode(!0),i?.mutator?.(this.svg,this),this.dispatchEvent(new E)}}updated(t){super.updated(t);let o=c(this.library),i=this.shadowRoot?.querySelector("svg");i&&o?.mutator?.(i,this)}render(){return this.hasUpdated?this.svg:p`
            <svg part="svg" width="16" height="16" fill="currentColor"></svg>
        `}};e.css=S,r([g()],e.prototype,"svg",2),r([s({reflect:!0})],e.prototype,"name",2),r([s({attribute:"icon-style",reflect:!0})],e.prototype,"iconStyle",2),r([s({attribute:"auto-width",type:Boolean,reflect:!0})],e.prototype,"autoWidth",2),r([s({attribute:"swap-opacity",type:Boolean,reflect:!0})],e.prototype,"swapOpacity",2),r([s()],e.prototype,"src",2),r([s()],e.prototype,"label",2),r([s({reflect:!0})],e.prototype,"library",2),r([d("label")],e.prototype,"handleLabelChange",1),r([d(["library","iconStyle","name","src","autoWidth","swapOpacity"])],e.prototype,"setIcon",1),e=r([f("pc-icon")],e);export{e as a};
