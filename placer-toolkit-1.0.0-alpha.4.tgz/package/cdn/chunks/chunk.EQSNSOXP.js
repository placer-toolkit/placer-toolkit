function c(e){let s=new FormData(e),r={};return s.forEach((t,n)=>{if(Reflect.has(r,n)){let o=r[n];Array.isArray(o)?o.push(t):r[n]=[r[n],t]}else r[n]=t}),r}export{c as a};
