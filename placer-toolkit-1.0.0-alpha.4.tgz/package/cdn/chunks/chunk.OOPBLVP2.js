var e=class extends Event{constructor(){super("pc-after-hide",{bubbles:!0,cancelable:!1,composed:!0})}};export{e as a};
