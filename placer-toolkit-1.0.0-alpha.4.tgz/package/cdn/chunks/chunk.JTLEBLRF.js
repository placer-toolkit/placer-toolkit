import{a as M}from"./chunk.JWIAHBHS.js";import{a as D}from"./chunk.W5PM7F34.js";import{a as C}from"./chunk.BSQP4EKW.js";import{a as S}from"./chunk.YRR4IRLY.js";import{a as m}from"./chunk.OVU4POJI.js";import{a as I}from"./chunk.Y452TQZB.js";import{a as z}from"./chunk.OOPBLVP2.js";import{a as $}from"./chunk.OMC4FRTB.js";import{a as L}from"./chunk.GFCFF7RE.js";import{a as v,d as g}from"./chunk.RZZMGXAZ.js";import{a as A}from"./chunk.43BYYM5E.js";import{a as w}from"./chunk.OOQOIJSK.js";import{a as k}from"./chunk.AGGS6MN5.js";import{c as T}from"./chunk.R2GXUKDX.js";import{a as E}from"./chunk.NOX5TXXZ.js";import{a as O,b as n,c as h,e as d}from"./chunk.PLBYMK2K.js";import{d as u}from"./chunk.FKNAQN55.js";import{a as f}from"./chunk.H2EOXVSZ.js";import{a as y,c as x}from"./chunk.N5AZOOIZ.js";import{a as V}from"./chunk.TBG3XWQL.js";import{b as a}from"./chunk.E6MOE4FE.js";var H=`:host {
    --tag-max-size: 10ch;
}

:host pc-tag {
    border-radius: calc(
        var(--pc-border-radius-m) -
            (
                var(--pc-form-control-height) * 0.1 -
                    var(--pc-form-control-border-width)
            )
    );
}

:host([pill]) pc-tag {
    border-radius: var(--pc-border-radius-pill);
}

:host pc-tag::part(content) {
    display: flex;
    align-items: center;
    max-inline-size: var(--tag-max-size);
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

:host .disabled [part~="combobox"] {
    opacity: 0.5;
    cursor: not-allowed;
    outline: none;
}

:host .enabled:is(.open, :focus-within) [part~="combobox"] {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.select {
    display: inline-flex;
    position: relative;
    flex: 1 1 auto;
    inline-size: 100%;
    vertical-align: middle;
}

.select::part(popup) {
    z-index: 900;
}

.select[data-current-placement^="top"]::part(popup) {
    transform-origin: bottom;
}

.select[data-current-placement^="bottom"]::part(popup) {
    transform-origin: top;
}

.combobox {
    display: flex;
    position: relative;
    align-items: center;
    justify-content: flex-start;
    flex: 1;
    min-inline-size: 0;
    inline-size: 100%;
    min-block-size: var(--pc-form-control-height);
    padding: 0 var(--pc-form-control-padding-inline);
    background-color: var(--pc-form-control-background-color);
    border: var(--pc-form-control-border-width)
        var(--pc-form-control-border-style) var(--pc-form-control-border-color);
    border-radius: var(--pc-form-control-border-radius);
    color: var(--pc-form-control-value-color);
    font-family: inherit;
    font-weight: var(--pc-form-control-value-font-weight);
    line-height: var(--pc-form-control-value-line-height);
    overflow: hidden;
    vertical-align: middle;
    cursor: pointer;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    :host(:not([disabled])) .enabled:not(.open, :focus-within) .combobox:hover {
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-border-color),
            var(--pc-color-mix-hover)
        );
    }
}

:host([multiple]) .select:not(.placeholder-visible) .combobox {
    padding-inline-start: 0;
    padding-block: calc(
        var(--pc-form-control-height) * 0.1 -
            var(--pc-form-control-border-width)
    );
}

:host([filled]) .combobox {
    background-color: var(--pc-color-neutral-fill-quiet);
    border-color: var(--pc-color-neutral-fill-quiet);
}

@media (hover: hover) {
    :host([filled]:not([disabled]))
        .enabled:not(.open, :focus-within)
        .combobox:hover {
        background-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-quiet),
            var(--pc-color-mix-hover)
        );
        border-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-quiet),
            var(--pc-color-mix-hover)
        );
    }
}

:host([pill]) .combobox {
    border-radius: var(--pc-border-radius-pill);
}

.display-input {
    position: relative;
    margin: 0;
    padding: 0;
    inline-size: 100%;
    background: transparent;
    color: var(--pc-form-control-value-color);
    border: none;
    outline: none;
    font: inherit;
    line-height: var(--pc-form-control-value-line-height);
    overflow: hidden;
    cursor: inherit;
    -webkit-appearance: none;
}

.display-input:focus {
    outline: none;
}

.display-input::placeholder {
    color: var(--pc-form-control-placeholder-color);
}

:host([multiple]) .select:not(.placeholder-visible) .display-input {
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    inline-size: 100%;
    block-size: 100%;
    opacity: 0;
    z-index: -1;
}

.value-input {
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    margin: 0;
    padding: 0;
    inline-size: 100%;
    block-size: 100%;
    opacity: 0;
    z-index: -1;
}

.tags {
    display: flex;
    align-items: center;
    flex: 1;
    flex-wrap: wrap;
    margin-inline-start: calc(
        var(--pc-form-control-height) * 0.1 -
            var(--pc-form-control-border-width)
    );
    gap: 0.25em;
}

.tags::slotted(pc-tag) {
    cursor: pointer !important;
}

.disabled .tags,
.disabled .tags::slotted(pc-tag) {
    cursor: not-allowed !important;
}

.prefix,
.suffix {
    display: inline-flex;
    align-items: center;
    flex: 0 0 auto;
}

.prefix::slotted(pc-icon),
.suffix::slotted(pc-icon) {
    color: var(--pc-color-neutral-on-quiet);
}

.prefix::slotted(*) {
    margin-inline-end: var(--pc-form-control-padding-inline);
}

.suffix::slotted(*) {
    margin-inline-start: var(--pc-form-control-padding-inline);
}

:host([multiple]) .prefix::slotted(*) {
    margin-inline: var(--pc-form-control-padding-inline);
}

[part~="clear-button"] {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-inline-start: var(--pc-form-control-padding-inline);
    padding: 0;
    border: none;
    background: transparent;
    color: var(--pc-color-neutral-on-quiet);
    font-size: inherit;
    cursor: pointer;
    transition: color var(--pc-transition-fast) ease-in-out;
}

[part~="clear-button"]:focus {
    outline: none;
}

@media (hover: hover) {
    [part~="clear-button"]:hover {
        color: color-mix(
            in oklab,
            var(--pc-color-neutral-on-quiet),
            var(--pc-color-mix-hover)
        );
    }
}

[part~="clear-button"]:active {
    color: color-mix(
        in oklab,
        var(--pc-color-neutral-on-quiet),
        var(--pc-color-mix-active)
    );
}

.expand-icon {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    color: var(--pc-color-neutral-on-quiet);
    rotate: 0;
    margin-inline-start: var(--pc-form-control-padding-inline);
    transition: rotate var(--pc-transition-fast) ease-in-out;
}

.open .expand-icon {
    rotate: -180deg;
}

.listbox {
    display: block;
    position: relative;
    font: inherit;
    background-color: var(--pc-color-surface-raised);
    border: none;
    border-radius: calc(var(--pc-border-radius-m) + var(--pc-spacing-xs));
    padding: var(--pc-spacing-xs);
    max-inline-size: var(--auto-size-available-width);
    max-block-size: var(--auto-size-available-height);
    overflow: auto;
    box-shadow: var(--pc-shadow-l);
    overscroll-behavior: none;
}

.listbox ::slotted(pc-divider) {
    --spacing: 0.25em;
}

slot:not([name])::slotted(small) {
    display: block;
    font-size: var(--pc-font-size-smaller);
    font-weight: var(--pc-font-weight-semibold);
    color: var(--pc-color-text-quiet);
    padding-block: 0.5em;
    padding-inline-start: 2em;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;y("select.show",{keyframes:[{offset:0,opacity:0,transform:"scaleY(0.35) scaleX(0.95) translateY(-10px) rotate(1deg)"},{offset:.25,opacity:1,transform:"scaleY(1.03) scaleX(1.005) translateY(2px) rotate(-0.5deg)"},{offset:.5,transform:"scaleY(0.995) scaleX(0.999) translateY(-0.5px) rotate(0.1deg)"},{offset:.75,transform:"scaleY(1.002) scaleX(1.0005) translateY(0.2px) rotate(-0.05deg)"},{offset:1,opacity:1,transform:"scaleY(1) scaleX(1) translateY(0) rotate(0deg)"}],options:{duration:1e3,easing:"cubic-bezier(0.2, 0.8, 0.2, 1)",fill:"forwards"}});y("select.hide",{keyframes:[{offset:0,opacity:1,transform:"scaleY(1) scaleX(1) translateY(0) rotate(0deg)"},{offset:.15,transform:"scaleY(1.005) scaleX(1.001) translateY(0.5px) rotate(-0.002deg)"},{offset:.4,transform:"scaleY(0.99) scaleX(0.998) translateY(-1px) rotate(0.008deg)"},{offset:.75,transform:"scaleY(0.6) scaleX(0.9) translateY(10px) rotate(0.007deg)"},{offset:1,opacity:0,transform:"scaleY(0.3) scaleX(0.8) translateY(25px) rotate(0.01deg)"}],options:{duration:400,easing:"cubic-bezier(0.6, 0.05, 0.8, 0.2)",fill:"forwards"}});var o=class extends E{constructor(){super(...arguments);this.assumeInteractionOn=["input","blur"];this.hasSlotController=new k(this,"label","hint");this.localize=new V(this);this.selectionOrder=new Map;this.typeToSelectString="";this.displayLabel="";this.selectedOptions=[];this.name="";this._defaultValue=null;this.size="medium";this.placeholder="";this.multiple=!1;this.maxOptionsVisible=3;this.disabled=!1;this.clearable=!1;this.open=!1;this.filled=!1;this.pill=!1;this.label="";this.placement="bottom";this.hint="";this.required=!1;this.getTag=e=>u`
            <pc-tag
                part="tag"
                size=${this.size}
                ?pill=${this.pill}
                removable
                @pc-remove=${t=>this.handleTagRemove(t,e)}
                exportparts="
                    base:tag-base,
                    content:tag-content,
                    remove-button:tag-remove-button,
                    remove-button-base:tag-remove-button-base
                "
            >
                ${e.label}
            </pc-tag>
        `;this.handleDocumentFocusIn=e=>{let t=e.composedPath();this&&!t.includes(this)&&this.hide()};this.handleDocumentKeyDown=e=>{let t=e.target,i=t.closest('[part~="clear-button"]')!==null,l=t.closest("pc-button")!==null;if(!(i||l)){if(e.key==="Escape"&&this.open&&(e.preventDefault(),e.stopPropagation(),this.hide(),this.displayInput.focus({preventScroll:!0})),e.key==="Enter"||e.key===" "&&this.typeToSelectString===""){if(e.preventDefault(),e.stopImmediatePropagation(),!this.open){this.show();return}this.currentOption&&!this.currentOption.disabled&&(this.valueHasChanged=!0,this.hasInteracted=!0,this.multiple?this.toggleOptionSelection(this.currentOption):this.setSelectedOptions(this.currentOption),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}),this.multiple||(this.hide(),this.displayInput.focus({preventScroll:!0})));return}if(["ArrowUp","ArrowDown","Home","End"].includes(e.key)){let r=this.getAllOptions(),p=r.indexOf(this.currentOption),s=Math.max(0,p);if(e.preventDefault(),!this.open&&(this.show(),this.currentOption))return;e.key==="ArrowDown"?(s=p+1,s>r.length-1&&(s=0)):e.key==="ArrowUp"?(s=p-1,s<0&&(s=r.length-1)):e.key==="Home"?s=0:e.key==="End"&&(s=r.length-1),this.setCurrentOption(r[s])}if(e.key&&e.key.length===1||e.key==="Backspace"){let r=this.getAllOptions();if(e.metaKey||e.ctrlKey||e.altKey)return;if(!this.open){if(e.key==="Backspace")return;this.show()}e.stopPropagation(),e.preventDefault(),clearTimeout(this.typeToSelectTimeout),this.typeToSelectTimeout=window.setTimeout(()=>{this.typeToSelectString=""},1e3),e.key==="Backspace"?this.typeToSelectString=this.typeToSelectString.slice(0,-1):this.typeToSelectString+=e.key.toLowerCase();for(let p of r)if(p.label.toLowerCase().startsWith(this.typeToSelectString)){this.setCurrentOption(p);break}}}};this.handleDocumentMouseDown=e=>{let t=e.composedPath();this&&!t.includes(this)&&this.hide()}}static get validators(){let e=[A({validationElement:Object.assign(document.createElement("select"),{required:!0})})];return[...super.validators,...e]}get validationTarget(){return this.valueInput}set defaultValue(e){this._defaultValue=this.convertDefaultValue(e)||""}get defaultValue(){return this.convertDefaultValue(this._defaultValue)}convertDefaultValue(e){return!(this.multiple||this.hasAttribute("multiple"))&&Array.isArray(e)&&(e=e[0]),e}set value(e){let t=this.value;e instanceof FormData&&(e=e.getAll(this.name)),e!=null&&!Array.isArray(e)&&(e=[e]),this._value=e??null,this.value!==t&&(this.valueHasChanged=!0,this.requestUpdate("value",t))}get value(){let e=this._value??this.defaultValue??null;e!=null&&(e=Array.isArray(e)?e:[e]),e==null?this.optionValues=new Set(null):this.optionValues=new Set(this.getAllOptions().filter(i=>!i.disabled).map(i=>i.value));let t=e;return e!=null&&(t=e.filter(i=>this.optionValues.has(i)),t=this.multiple?t:t[0],t=t??null),t}connectedCallback(){super.connectedCallback(),this.handleDefaultSlotChange(),this.open=!1}updateDefaultValue(){let t=this.getAllOptions().filter(i=>i.hasAttribute("selected")||i.defaultSelected);if(t.length>0){let i=t.map(l=>l.value);this._defaultValue=this.multiple?i:i[0]}this.hasAttribute("value")&&(this._defaultValue=this.getAttribute("value")||null)}addOpenListeners(){document.addEventListener("focusin",this.handleDocumentFocusIn),document.addEventListener("keydown",this.handleDocumentKeyDown),document.addEventListener("mousedown",this.handleDocumentMouseDown),this.getRootNode()!==document&&this.getRootNode().addEventListener("focusin",this.handleDocumentFocusIn)}removeOpenListeners(){document.removeEventListener("focusin",this.handleDocumentFocusIn),document.removeEventListener("keydown",this.handleDocumentKeyDown),document.removeEventListener("mousedown",this.handleDocumentMouseDown),this.getRootNode()!==document&&this.getRootNode().removeEventListener("focusin",this.handleDocumentFocusIn)}handleFocus(){this.displayInput.setSelectionRange(0,0)}handleLabelClick(){this.displayInput.focus()}handleComboboxClick(e){e.preventDefault()}handleComboboxMouseDown(e){let i=e.composedPath().some(l=>l instanceof Element&&l.tagName.toLowerCase()==="pc-button");this.disabled||i||(e.preventDefault(),this.displayInput.focus({preventScroll:!0}),this.open=!this.open)}handleComboboxKeyDown(e){e.stopPropagation(),this.handleDocumentKeyDown(e)}handleClearClick(e){e.stopPropagation(),this.value!==""&&(this.selectionOrder.clear(),this.setSelectedOptions([]),this.displayInput.focus({preventScroll:!0}),this.updateComplete.then(()=>{this.dispatchEvent(new S),this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))}handleClearMouseDown(e){e.stopPropagation(),e.preventDefault()}handleOptionClick(e){let i=e.target.closest("pc-option");i&&!i.disabled&&(this.hasInteracted=!0,this.valueHasChanged=!0,this.multiple?this.toggleOptionSelection(i):this.setSelectedOptions(i),this.updateComplete.then(()=>this.displayInput.focus({preventScroll:!0})),this.requestUpdate("value"),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}),this.multiple||(this.hide(),this.displayInput.focus({preventScroll:!0})))}handleDefaultSlotChange(){customElements.get("pc-option")||customElements.whenDefined("pc-option").then(()=>this.handleDefaultSlotChange());let e=this.getAllOptions();this.optionValues=void 0,this.updateDefaultValue();let t=this.value;if(t==null||!this.valueHasChanged&&!this.hasInteracted){this.selectionChanged();return}Array.isArray(t)||(t=[t]);let i=e.filter(l=>t.includes(l.value));this.setSelectedOptions(i)}handleTagRemove(e,t){if(e.stopPropagation(),this.disabled)return;this.hasInteracted=!0,this.valueHasChanged=!0;let i=t;if(!i){let l=e.target.closest("pc-tag[data-value]");if(l){let r=l.dataset.value;i=this.selectedOptions.find(p=>p.value===r)}}i&&(this.toggleOptionSelection(i,!1),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))}getAllOptions(){return this?.querySelectorAll?[...this.querySelectorAll("pc-option")]:[]}getFirstOption(){return this.querySelector("pc-option")}setCurrentOption(e){this.getAllOptions().forEach(i=>{i.current=!1,i.tabIndex=-1}),e&&(this.currentOption=e,e.current=!0,e.tabIndex=0,e.focus())}setSelectedOptions(e){let t=this.getAllOptions(),i=Array.isArray(e)?e:[e];t.forEach(l=>{i.includes(l)||(l.selected=!1)}),i.length&&i.forEach(l=>l.selected=!0),this.selectionChanged()}toggleOptionSelection(e,t){t===!0||t===!1?e.selected=t:e.selected=!e.selected,this.selectionChanged()}selectionChanged(){let t=this.getAllOptions().filter(s=>{if(!this.hasInteracted&&!this.valueHasChanged){let c=this.defaultValue,b=Array.isArray(c)?c:[c];return s.hasAttribute("selected")||s.defaultSelected||s.selected||b?.includes(s.value)}return s.selected}),i=new Set(t.map(s=>s.value));for(let s of this.selectionOrder.keys())i.has(s)||this.selectionOrder.delete(s);let r=(this.selectionOrder.size>0?Math.max(...this.selectionOrder.values()):-1)+1;for(let s of t)this.selectionOrder.has(s.value)||this.selectionOrder.set(s.value,r++);this.selectedOptions=t.sort((s,c)=>{let b=this.selectionOrder.get(s.value)??0,q=this.selectionOrder.get(c.value)??0;return b-q});let p=new Set(this.selectedOptions.map(s=>s.value));if(p.size>0||this._value){let s=this._value;if(this._value==null){let c=this.defaultValue??[];this._value=Array.isArray(c)?c:[c]}this._value=this._value?.filter(c=>!this.optionValues?.has(c))??null,this._value?.unshift(...p),this.requestUpdate("value",s)}if(this.multiple)this.placeholder&&!this.value?.length?this.displayLabel="":this.displayLabel=this.localize.term("numOptionsSelected",this.selectedOptions.length);else{let s=this.selectedOptions[0];this.displayLabel=s?.label??""}this.updateComplete.then(()=>{this.updateValidity()})}get tags(){return this.selectedOptions.map((e,t)=>{if(t<this.maxOptionsVisible||this.maxOptionsVisible<=0){let i=this.getTag(e,t);return i?typeof i=="string"?M(i):i:null}else if(t===this.maxOptionsVisible)return u`
                    <pc-tag
                        part="tag"
                        exportparts="
                            base:tag-base,
                            content:tag-content,
                            remove-button:tag-remove-button,
                            remove-button-base:tag-remove-button-base
                        "
                    >
                        +${this.selectedOptions.length-t}
                    </pc-tag>
                `;return null})}updated(e){super.updated(e),e.has("value")&&this.customStates.set("blank",!this.value)}handleDisabledChange(){this.disabled&&(this.open=!1)}handleValueChange(){let e=this.getAllOptions(),t=Array.isArray(this.value)?this.value:[this.value],i=e.filter(l=>t.includes(l.value));this.setSelectedOptions(i),this.updateValidity()}async handleOpenChange(){if(this.open&&!this.disabled){this.setCurrentOption(this.selectedOptions[0]||this.getFirstOption());let e=new L;if(this.dispatchEvent(e),e.defaultPrevented){this.open=!1;return}this.addOpenListeners(),await g(this),this.listbox.hidden=!1,this.popup.active=!0,requestAnimationFrame(()=>{this.setCurrentOption(this.currentOption)});let{keyframes:t,options:i}=x(this,"select.show",{dir:this.localize.dir()});await v(this.popup.popup,t,i),this.currentOption&&T(this.currentOption,this.listbox,"vertical","auto"),this.dispatchEvent(new I)}else{let e=new $;if(this.dispatchEvent(e),e.defaultPrevented){this.open=!1;return}this.removeOpenListeners(),await g(this);let{keyframes:t,options:i}=x(this,"select.hide",{dir:this.localize.dir()});await v(this.popup.popup,t,i),this.listbox.hidden=!0,this.popup.active=!1,this.dispatchEvent(new z)}}async show(){if(this.open||this.disabled){this.open=!1;return}return this.open=!0,w(this,"pc-after-show")}async hide(){if(!this.open||this.disabled){this.open=!1;return}return this.open=!1,w(this,"pc-after-hide")}focus(e){this.displayInput.focus(e)}blur(){this.displayInput.blur()}formResetCallback(){this.selectionOrder.clear(),this.value=this.defaultValue,super.formResetCallback(),this.handleValueChange(),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}render(){let e=this.hasSlotController.test("label"),t=this.hasSlotController.test("hint"),i=this.label?!0:!!e,l=this.hint?!0:!!t,r=this.clearable&&!this.disabled&&this.value&&this.value.length>0,p=!!(this.placeholder&&(!this.value||this.value.length===0));return u`
            <div
                part="form-control"
                class=${m({"form-control":!0,"form-control-has-label":i})}
            >
                <label
                    part="label"
                    class="label"
                    id="label"
                    aria-hidden=${i?"false":"true"}
                    @click=${this.handleLabelClick}
                >
                    <slot name="label">${this.label}</slot>
                </label>

                <div part="input" class="form-control-input">
                    <pc-popup
                        class=${m({select:!0,open:this.open,disabled:this.disabled,enabled:!this.disabled,multiple:this.multiple,"placeholder-visible":p})}
                        placement=${this.placement}
                        sync="width"
                        auto-size="vertical"
                        auto-size-padding="10"
                        shift
                        flip
                    >
                        <div
                            part="combobox"
                            class="combobox"
                            slot="anchor"
                            @keydown=${this.handleComboboxKeyDown}
                            @mousedown=${this.handleComboboxMouseDown}
                        >
                            <slot
                                class="prefix"
                                part="prefix"
                                name="prefix"
                            ></slot>

                            <input
                                part="display-input"
                                class="display-input"
                                type="text"
                                role="combobox"
                                placeholder=${this.placeholder}
                                .disabled=${this.disabled}
                                .value=${this.displayLabel}
                                autocomplete="off"
                                spellcheck="false"
                                autocapitalize="off"
                                aria-controls="listbox"
                                aria-expanded=${this.open?"true":"false"}
                                aria-haspopup="listbox"
                                aria-labelledby="label"
                                aria-disabled=${this.disabled?"true":"false"}
                                aria-describedby="hint"
                                tabindex="0"
                                readonly
                                @focus=${this.handleFocus}
                            />

                            ${this.multiple?u`
                                      <div
                                          part="tags"
                                          class="tags"
                                          @pc-remove=${this.handleTagRemove}
                                      >
                                          ${this.tags}
                                      </div>
                                  `:""}

                            <input
                                class="value-input"
                                type="text"
                                ?disabled=${this.disabled}
                                ?required=${this.required}
                                .value=${Array.isArray(this.value)?this.value.join(", "):this.value}
                                tabindex="-1"
                                aria-hidden="true"
                                @focus=${()=>this.focus()}
                            />

                            ${r?u`
                                      <button
                                          part="clear-button"
                                          type="button"
                                          aria-label=${this.localize.term("clearEntry")}
                                          @click=${this.handleClearClick}
                                          @mousedown=${this.handleClearMouseDown}
                                          tabindex="-1"
                                      >
                                          <slot name="clear-icon">
                                              <pc-icon
                                                  library="system"
                                                  icon-style="regular"
                                                  name="circle-xmark"
                                              ></pc-icon>
                                          </slot>
                                      </button>
                                  `:""}

                            <slot
                                class="suffix"
                                part="suffix"
                                name="suffix"
                            ></slot>

                            <slot
                                class="expand-icon"
                                part="expand-icon"
                                name="expand-icon"
                            >
                                <pc-icon
                                    library="system"
                                    icon-style="solid"
                                    name="chevron-down"
                                ></pc-icon>
                            </slot>
                        </div>

                        <div
                            part="listbox"
                            class="listbox"
                            id="listbox"
                            role="listbox"
                            aria-expanded=${this.open?"true":"false"}
                            aria-multiselectable=${this.multiple?"true":"false"}
                            aria-labelledby="label"
                            tabindex="-1"
                            @mouseup=${this.handleOptionClick}
                        >
                            <slot
                                @slotchange=${this.handleDefaultSlotChange}
                            ></slot>
                        </div>
                    </pc-popup>

                    <slot
                        part="hint"
                        class=${m({"has-hint":l})}
                        name="hint"
                        id="hint"
                        aria-hidden=${l?"false":"true"}
                    >
                        ${this.hint}
                    </slot>
                </div>
            </div>
        `}};o.css=[D,C,H],a([d(".select")],o.prototype,"popup",2),a([d(".combobox")],o.prototype,"combobox",2),a([d(".display-input")],o.prototype,"displayInput",2),a([d(".value-input")],o.prototype,"valueInput",2),a([d(".listbox")],o.prototype,"listbox",2),a([h()],o.prototype,"displayLabel",2),a([h()],o.prototype,"currentOption",2),a([h()],o.prototype,"selectedOptions",2),a([h()],o.prototype,"optionValues",2),a([n()],o.prototype,"name",2),a([n({attribute:!1})],o.prototype,"defaultValue",1),a([n({reflect:!0})],o.prototype,"size",2),a([n()],o.prototype,"placeholder",2),a([n({type:Boolean,reflect:!0})],o.prototype,"multiple",2),a([n({attribute:"max-options-visible",type:Number})],o.prototype,"maxOptionsVisible",2),a([n({type:Boolean})],o.prototype,"disabled",2),a([n({type:Boolean})],o.prototype,"clearable",2),a([n({type:Boolean,reflect:!0})],o.prototype,"open",2),a([n({type:Boolean,reflect:!0})],o.prototype,"filled",2),a([n({type:Boolean,reflect:!0})],o.prototype,"pill",2),a([n()],o.prototype,"label",2),a([n({reflect:!0})],o.prototype,"placement",2),a([n()],o.prototype,"hint",2),a([n({type:Boolean,reflect:!0})],o.prototype,"required",2),a([n()],o.prototype,"getTag",2),a([n({attribute:"value",reflect:!1})],o.prototype,"value",1),a([f("disabled",{waitUntilFirstUpdate:!0})],o.prototype,"handleDisabledChange",1),a([f("value",{waitUntilFirstUpdate:!0})],o.prototype,"handleValueChange",1),a([f("open",{waitUntilFirstUpdate:!0})],o.prototype,"handleOpenChange",1),o=a([O("pc-select")],o);export{o as a};
