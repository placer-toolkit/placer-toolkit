var e=class extends Event{constructor(){super("pc-show",{bubbles:!0,cancelable:!0,composed:!0})}};export{e as a};
