var e=class extends Event{constructor(){super("pc-close",{bubbles:!0,cancelable:!1,composed:!0})}};export{e as a};
