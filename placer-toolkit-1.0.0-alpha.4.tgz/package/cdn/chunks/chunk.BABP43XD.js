import{a as t,b as e,g as a}from"./chunk.PLBYMK2K.js";import{a as i}from"./chunk.H2EOXVSZ.js";import{b as o}from"./chunk.E6MOE4FE.js";var l=`:host {
    --color: var(--pc-color-surface-border);
    --stroke-width: var(--pc-panel-border-width);
    --spacing: var(--pc-content-spacing);

    flex-shrink: 0;
}

:host([orientation="horizontal"]) {
    display: block;
    margin-block: var(--spacing);
    inline-size: 100%;
    block-size: var(--stroke-width);
    background-color: var(--color);
    border-radius: var(--pc-border-radius-pill);
}

:host([orientation="vertical"]) {
    display: inline-block;
    margin: 0 var(--spacing);
    inline-size: var(--stroke-width);
    min-block-size: 1lh;
    block-size: 100%;
    background-color: var(--color);
    border-radius: var(--pc-border-radius-pill);
}
`;var r=class extends a{constructor(){super(...arguments);this.orientation="horizontal"}connectedCallback(){super.connectedCallback(),this.setAttribute("role","separator")}handleVerticalChange(){this.setAttribute("aria-orientation",this.orientation)}};r.css=l,o([e({reflect:!0})],r.prototype,"orientation",2),o([i("vertical")],r.prototype,"handleVerticalChange",1),r=o([t("pc-divider")],r);export{r as a};
