import{a as i,b as l,c as p}from"./chunk.SMFJUIOR.js";import{e as s,f as n,g as a}from"./chunk.FKNAQN55.js";var{I:d}=a;var A=e=>e.strings===void 0;var m={},$=(e,t=m)=>e._$AH=t;var v=l(class extends p{constructor(e){if(super(e),e.type!==i.PROPERTY&&e.type!==i.ATTRIBUTE&&e.type!==i.BOOLEAN_ATTRIBUTE)throw Error("The `live` directive is not allowed on child or event bindings");if(!A(e))throw Error("`live` bindings can only contain a single expression")}render(e){return e}update(e,[t]){if(t===s||t===n)return t;let r=e.element,o=e.name;if(e.type===i.PROPERTY){if(t===r[o])return s}else if(e.type===i.BOOLEAN_ATTRIBUTE){if(!!t===r.hasAttribute(o))return s}else if(e.type===i.ATTRIBUTE&&r.getAttribute(o)===t+"")return s;return $(e),t}});export{v as a};
/*! Bundled license information:

lit-html/directive-helpers.js:
lit-html/directives/live.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
