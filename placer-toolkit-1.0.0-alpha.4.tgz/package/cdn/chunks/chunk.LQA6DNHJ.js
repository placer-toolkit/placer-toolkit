import{a as c}from"./chunk.OVU4POJI.js";import{a as d}from"./chunk.V52RFTK3.js";import{a as s,b as a,c as o,g as l}from"./chunk.PLBYMK2K.js";import{d as r}from"./chunk.FKNAQN55.js";import{a as n}from"./chunk.H2EOXVSZ.js";import{b as i}from"./chunk.E6MOE4FE.js";var m=`:host {
    --size: 3rem;

    display: inline-block;
}

.avatar {
    display: inline-flex;
    position: relative;
    align-items: center;
    justify-content: center;
    inline-size: var(--size);
    block-size: var(--size);
    background-color: var(--pc-color-neutral-fill-normal);
    color: var(--pc-color-neutral-on-normal);
    font-family: var(--pc-font-sans);
    font-size: calc(var(--size) * 0.4);
    font-weight: var(--pc-font-weight-bold);
    user-select: none;
    -webkit-user-select: none;
    vertical-align: middle;
    transition: all var(--pc-transition-fast) ease-in-out;
}

.circle,
.circle .image {
    border-radius: var(--pc-border-radius-circle);
}

.rounded,
.rounded .image {
    border-radius: var(--pc-border-radius-m);
}

.square {
    border-radius: 0;
}

.icon {
    display: flex;
    position: absolute;
    align-items: center;
    justify-content: center;
    inset-block-start: 0;
    inset-inline-start: 0;
    inline-size: 100%;
    block-size: 100%;
}

.initials {
    line-height: 1;
    text-transform: uppercase;
}

.image {
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    inline-size: 100%;
    block-size: 100%;
    object-fit: cover;
    overflow: hidden;
}
`;var e=class extends l{constructor(){super(...arguments);this.hasError=!1;this.image="";this.label="";this.initials="";this.loading="eager";this.shape="circle"}handleImageChange(){this.hasError=!1}handleImageLoadError(){this.hasError=!0,this.dispatchEvent(new d)}render(){let p=r`
            <img
                class="image"
                part="image"
                src=${this.image}
                loading=${this.loading}
                alt=""
                @error=${this.handleImageLoadError}
            />
        `,t=r``;return this.initials?t=r`
                <div class="initials">${this.initials}</div>
            `:t=r`
                <div class="icon" part="icon" aria-hidden="true">
                    <slot name="icon">
                        <pc-icon
                            library="system"
                            icon-style="solid"
                            name="user"
                        ></pc-icon>
                    </slot>
                </div>
            `,r`
            <div
                part="base"
                class=${c({avatar:!0,circle:this.shape==="circle",rounded:this.shape==="rounded",square:this.shape==="square"})}
                role="img"
                aria-label=${this.label}
            >
                ${this.image&&!this.hasError?p:t}
            </div>
        `}};e.css=m,i([o()],e.prototype,"hasError",2),i([a()],e.prototype,"image",2),i([a()],e.prototype,"label",2),i([a()],e.prototype,"initials",2),i([a()],e.prototype,"loading",2),i([a({reflect:!0})],e.prototype,"shape",2),i([n("image")],e.prototype,"handleImageChange",1),e=i([s("pc-avatar")],e);export{e as a};
