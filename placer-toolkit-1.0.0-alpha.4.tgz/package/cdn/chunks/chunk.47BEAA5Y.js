import{a as y}from"./chunk.5PPF3EHL.js";import{a as g}from"./chunk.W5PM7F34.js";import{a as s}from"./chunk.RXMQHF36.js";import{a as v}from"./chunk.BSQP4EKW.js";import{a as d}from"./chunk.OVU4POJI.js";import{a as f}from"./chunk.S5DN2ZZE.js";import{a as m}from"./chunk.AGGS6MN5.js";import{a as b}from"./chunk.NOX5TXXZ.js";import{a as c,b as r,c as p,e as a}from"./chunk.PLBYMK2K.js";import{d as h}from"./chunk.FKNAQN55.js";import{a as u}from"./chunk.H2EOXVSZ.js";import{b as i}from"./chunk.E6MOE4FE.js";var z=`:host {
    border-width: 0;
}

.textarea {
    display: grid;
    align-items: center;
    margin: 0;
    -webkit-appearance: none;
    background-color: var(--pc-form-control-background-color);
    border: var(--pc-form-control-border-width)
        var(--pc-form-control-border-style) var(--pc-form-control-border-color);
    border-radius: var(--pc-form-control-border-radius);
    font: inherit;
    outline: none;
    cursor: inherit;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    .textarea:not(:has(:disabled), :focus-within):hover {
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-border-color),
            var(--pc-color-mix-hover)
        );
    }
}

.textarea:focus-within {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

:host([filled]) .textarea {
    background-color: var(--pc-color-neutral-fill-quiet);
    border-color: var(--pc-color-neutral-fill-quiet);
}

@media (hover: hover) {
    :host([filled]) .textarea:not(:has(:disabled), :focus-within):hover {
        background-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-quiet),
            var(--pc-color-mix-hover)
        );
        border-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-quiet),
            var(--pc-color-mix-hover)
        );
    }
}

textarea {
    display: block;
    margin: 0;
    padding-block: calc(
        (var(--pc-form-control-padding-block) * 1.25) - ((1lh - 1em) / 2)
    );
    padding-inline: calc(var(--pc-form-control-padding-inline) * 1.1765);
    inline-size: 100%;
    min-block-size: calc(
        var(--pc-form-control-height) - var(--border-width) * 2
    );
    background-color: transparent;
    color: inherit;
    border: none;
    font: inherit;
    box-shadow: none;
}

textarea:focus {
    outline: none;
}

textarea::placeholder {
    color: var(--pc-form-control-placeholder-color);
    user-select: none;
    -webkit-user-select: none;
}

textarea:autofill,
textarea:autofill:hover,
textarea:autofill:active,
textarea:autofill:focus {
    caret-color: var(--pc-form-control-value-color);
    box-shadow: none;
}

textarea::-webkit-search-decoration,
textarea::-webkit-search-cancel-button,
textarea::-webkit-search-results-button,
textarea::-webkit-search-results-decoration {
    -webkit-appearance: none;
}

.control,
.size-adjuster {
    grid-area: 1 / 1 / 2 / 2;
}

.size-adjuster {
    padding: 0;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
}

:host([resize="none"]) textarea {
    resize: none;
}

textarea,
:host([resize="vertical"]) textarea {
    resize: vertical;
}

:host([resize="horizontal"]) textarea {
    resize: horizontal;
}

:host([resize="both"]) textarea {
    resize: both;
}

:host([resize="auto"]) textarea {
    block-size: auto;
    overflow-y: hidden;
    resize: none;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var t=class extends b{constructor(){super(...arguments);this.assumeInteractionOn=["input","blur"];this.hasSlotController=new m(this,"label","hint");this.title="";this.name="";this._value=null;this.defaultValue=this.getAttribute("value")??"";this.size="medium";this.filled=!1;this.label="";this.hint="";this.placeholder="";this.rows=4;this.resize="vertical";this.disabled=!1;this.readonly=!1;this.required=!1;this.autocapitalize="sentences";this.autocorrect=!1;this.autofocus=!1;this.enterkeyhint="enter";this.spellcheck=!0}static get validators(){return[...super.validators,f()]}get value(){return this.valueHasChanged?this._value:this._value??this.defaultValue}set value(e){this._value!==e&&(this.valueHasChanged=!0,this._value=e)}connectedCallback(){super.connectedCallback(),this.resizeObserver=new ResizeObserver(()=>this.setTextareaDimensions()),this.updateComplete.then(()=>{if(this.setTextareaDimensions(),this.resizeObserver?.observe(this.input),this.input&&this.value!==this.input.value){let e=this.input.value;this.value=e}})}disconnectedCallback(){super.disconnectedCallback(),this.input&&this.resizeObserver?.unobserve(this.input)}handleChange(e){this.valueHasChanged=!0,this.value=this.input.value,this.setTextareaDimensions(),this.checkValidity(),this.relayNativeEvent(e,{bubbles:!0,composed:!0})}handleInput(e){this.valueHasChanged=!0,this.value=this.input.value,this.relayNativeEvent(e,{bubbles:!0,composed:!0})}handleBlur(){this.checkValidity()}setTextareaDimensions(){if(this.resize==="none"&&(this.base.style.inlineSize="",this.base.style.blockSize=""),this.resize==="auto"){this.sizeAdjuster.style.blockSize=`${this.input.clientHeight}px`,this.input.style.blockSize="auto",this.input.style.blockSize=`${this.input.scrollHeight}px`,this.base.style.inlineSize="",this.base.style.blockSize="";return}if(this.input.style.inlineSize){let e=Number(this.input.style.inlineSize.split(/px/)[0])+2;this.base.style.inlineSize=`${e}px`}if(this.input.style.width){let e=Number(this.input.style.width.split(/px/)[0])+2;this.base.style.width=`${e}px`}if(this.input.style.blockSize){let e=Number(this.input.style.blockSize.split(/px/)[0])+2;this.base.style.height=`${e}px`}if(this.input.style.height){let e=Number(this.input.style.height.split(/px/)[0])+2;this.base.style.height=`${e}px`}}handleRowsChange(){this.setTextareaDimensions()}async handleValueChange(){await this.updateComplete,this.checkValidity(),this.setTextareaDimensions()}updated(e){e.has("resize")&&this.setTextareaDimensions(),super.updated(e),e.has("value")&&this.customStates.set("blank",!this.value)}focus(e){this.input.focus(e)}blur(){this.input.blur()}select(){this.input.select()}scrollPosition(e){if(e){typeof e.top=="number"&&(this.input.scrollTop=e.top),typeof e.left=="number"&&(this.input.scrollLeft=e.left);return}return{top:this.input.scrollTop,left:this.input.scrollTop}}setSelectionRange(e,o,l="none"){this.input.setSelectionRange(e,o,l)}setRangeText(e,o,l,n="preserve"){let k=o??this.input.selectionStart,w=l??this.input.selectionEnd;this.input.setRangeText(e,k,w,n),this.value!==this.input.value&&(this.value=this.input.value,this.setTextareaDimensions())}formResetCallback(){this.value=this.defaultValue,super.formResetCallback()}render(){let e=this.hasSlotController.test("label"),o=this.hasSlotController.test("hint"),l=this.label?!0:!!e,n=this.hint?!0:!!o;return h`
            <label
                part="label"
                class="label"
                for="input"
                aria-hidden=${l?"false":"true"}
            >
                <slot name="label">${this.label}</slot>
            </label>

            <div part="base" class="textarea">
                <textarea
                    part="textarea"
                    class="control"
                    id="input"
                    title=${this.title}
                    name=${s(this.name)}
                    .value=${y(this.value)}
                    ?disabled=${this.disabled}
                    ?readonly=${this.readonly}
                    ?required=${this.required}
                    placeholder=${s(this.placeholder)}
                    rows=${s(this.rows)}
                    minlength=${s(this.minlength)}
                    maxlength=${s(this.maxlength)}
                    autocapitalize=${s(this.autocapitalize)}
                    autocorrect=${s(this.autocorrect)}
                    ?autofocus=${this.autofocus}
                    spellcheck=${s(this.spellcheck)}
                    enterkeyhint=${s(this.enterkeyhint)}
                    inputmode=${s(this.inputmode)}
                    aria-describedby="hint"
                    @change=${this.handleChange}
                    @input=${this.handleInput}
                    @blur=${this.handleBlur}
                ></textarea>

                <!-- This part is explicitly undocumented as it isn’t supposed to be accessed by users. -->
                <div
                    part="textarea-adjuster"
                    class="size-adjuster"
                    ?hidden=${this.resize!=="auto"}
                ></div>
            </div>

            <slot
                part="hint"
                class=${d({"has-hint":n})}
                id="hint"
                name="hint"
                aria-hidden=${n?"false":"true"}
            >
                ${this.hint}
            </slot>
        `}};t.css=[g,v,z],i([a(".control")],t.prototype,"input",2),i([a('[part~="base"]')],t.prototype,"base",2),i([a(".size-adjuster")],t.prototype,"sizeAdjuster",2),i([r()],t.prototype,"title",2),i([r()],t.prototype,"name",2),i([p()],t.prototype,"value",1),i([r({attribute:"value",reflect:!0})],t.prototype,"defaultValue",2),i([r({reflect:!0})],t.prototype,"size",2),i([r({type:Boolean,reflect:!0})],t.prototype,"filled",2),i([r()],t.prototype,"label",2),i([r()],t.prototype,"hint",2),i([r()],t.prototype,"placeholder",2),i([r({type:Number})],t.prototype,"rows",2),i([r()],t.prototype,"resize",2),i([r({type:Boolean})],t.prototype,"disabled",2),i([r({type:Boolean,reflect:!0})],t.prototype,"readonly",2),i([r({type:Boolean,reflect:!0})],t.prototype,"required",2),i([r({type:Number})],t.prototype,"minlength",2),i([r({type:Number})],t.prototype,"maxlength",2),i([r()],t.prototype,"autocapitalize",2),i([r({type:Boolean,converter:{fromAttribute:e=>!(!e||e==="off"),toAttribute:e=>e?"on":"off"}})],t.prototype,"autocorrect",2),i([r()],t.prototype,"autocomplete",2),i([r({type:Boolean})],t.prototype,"autofocus",2),i([r()],t.prototype,"enterkeyhint",2),i([r({type:Boolean,converter:{fromAttribute:e=>!(!e||e==="off"),toAttribute:e=>e?"on":"off"}})],t.prototype,"spellcheck",2),i([r()],t.prototype,"inputmode",2),i([u("rows",{waitUntilFirstUpdate:!0})],t.prototype,"handleRowsChange",1),i([u("value",{waitUntilFirstUpdate:!0})],t.prototype,"handleValueChange",1),t=i([c("pc-textarea")],t);export{t as a};
