import{a as y}from"./chunk.W5PM7F34.js";import{a as v}from"./chunk.BSQP4EKW.js";import{a as c}from"./chunk.OVU4POJI.js";import{a as g}from"./chunk.43BYYM5E.js";import{b as k}from"./chunk.ZS4GILCB.js";import{a as b}from"./chunk.AGGS6MN5.js";import{a as h}from"./chunk.NOX5TXXZ.js";import{a as p,b as o,c as m,e as f}from"./chunk.PLBYMK2K.js";import{d as u}from"./chunk.FKNAQN55.js";import{b as r}from"./chunk.E6MOE4FE.js";var E=`@layer pc-utilities {
    .pc-visually-hidden:not(:focus-within),
    .pc-visually-hidden-force {
        position: absolute !important;
        margin: -1px !important;
        padding: 0 !important;
        inline-size: 1px !important;
        block-size: 1px !important;
        width: 1px !important;
        height: 1px !important;
        clip-path: inset(50%) !important;
        border: none !important;
        overflow: hidden !important;
        white-space: nowrap !important;
    }
}
`;var w=`:host {
    display: block;
}

.form-control {
    position: relative;
    margin: 0;
    padding: 0;
    border: none;
}

.input {
    display: flex;
    flex-direction: column;
}

.form-control .label,
.form-control .hint {
    display: none;
}

.has-label .label {
    display: inline-block;
    margin-block-end: var(--pc-spacing-xs);
    padding: 0;
    color: var(--pc-input-label-color);
    line-height: var(--pc-line-height-normal);
    transition: color var(--pc-transition-fast) ease-in-out;
}

:host([required]) .label::after {
    content: var(--pc-input-required-content);
    margin-inline-start: var(--pc-input-required-content-offset);
    color: var(--pc-input-required-content-color);
}

.has-hint .hint {
    margin-block-start: var(--pc-spacing-xs);
    color: var(--pc-input-hint-color);
    font-family: var(--pc-input-font-family);
}
`;var l=class extends h{constructor(){super();this.hasSlotController=new b(this,"hint","label");this.label="";this.hint="";this.name=null;this._value=null;this.defaultValue=this.getAttribute("value")||null;this.size="medium";this.required=!1;this.handleRadioClick=t=>{let e=t.target.closest("pc-radio");if(!e||e.disabled||e.forceDisabled||this.disabled)return;let s=this.value;this.value=e.value??null,e.checked=!0;let i=this.getAllRadios();for(let n of i)e!==n&&(n.checked=!1,n.setAttribute("tabindex","-1"));this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})};this.addEventListener("click",this.handleRadioClick),this.addEventListener("keydown",this.handleKeyDown)}static get validators(){let t=[g({validationElement:Object.assign(document.createElement("input"),{required:!0,type:"radio",name:k("__pc-radio")})})];return[...super.validators,...t]}get value(){return this.valueHasChanged?this._value:this._value??this.defaultValue}set value(t){typeof t=="number"&&(t=String(t)),this.valueHasChanged=!0,this._value=t}get validationTarget(){let t=this.querySelector(":is(pc-radio):not([disabled])");if(t)return t}updated(t){(t.has("disabled")||t.has("size")||t.has("value"))&&this.syncRadioElements()}formResetCallback(...t){this.value=this.defaultValue,super.formResetCallback(...t),this.syncRadioElements()}getAllRadios(){return[...this.querySelectorAll("pc-radio")]}handleLabelClick(){this.focus()}async syncRadioElements(){let t=this.getAllRadios();if(await Promise.all(t.map(async e=>{await e.updateComplete,!e.disabled&&e.value===this.value?e.checked=!0:e.checked=!1})),this.disabled)t.forEach(e=>{e.tabIndex=-1});else{let e=t.filter(i=>!i.disabled),s=e.find(i=>i.checked);e.length>0&&(s?e.forEach(i=>{i.tabIndex=i.checked?0:-1}):e.forEach((i,n)=>{i.tabIndex=n===0?0:-1})),t.filter(i=>i.disabled).forEach(i=>{i.tabIndex=-1})}}handleKeyDown(t){if(!["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," "].includes(t.key)||this.disabled)return;let e=this.getAllRadios().filter(d=>!d.disabled);if(e.length<=0)return;t.preventDefault();let s=this.value,i=e.find(d=>d.checked)??e[0],n=t.key===" "?0:["ArrowUp","ArrowLeft"].includes(t.key)?-1:1,a=e.indexOf(i)+n;a||(a=0),a<0&&(a=e.length-1),a>e.length-1&&(a=0),this.getAllRadios().forEach(d=>{d.checked=!1,d.setAttribute("tabindex","-1")}),this.value=e[a].value??null,e[a].checked=!0,e[a].setAttribute("tabindex","0"),e[a].focus(),this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0})),this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),t.preventDefault()}syncRadios(){if(customElements.get("pc-radio")){this.syncRadioElements();return}customElements.get("pc-radio")?this.syncRadioElements():customElements.whenDefined("pc-radio").then(()=>this.syncRadios())}focus(t){if(this.disabled)return;let e=this.getAllRadios(),s=e.find(a=>a.checked),i=e.find(a=>!a.disabled),n=s||i;n&&n.focus(t)}render(){let t=this.hasSlotController.test("label"),e=this.hasSlotController.test("hint"),s=this.label?!0:!!t,i=this.hint?!0:!!e;return u`
            <fieldset
                part="form-control"
                class=${c({"form-control":!0,"radio-group":!0,"has-label":s,"has-hint":i})}
                role="radiogroup"
                aria-labelledby="label"
                aria-describedby="hint"
                aria-errormessage="error-message"
            >
                <label
                    class="label"
                    part="label"
                    id="label"
                    aria-hidden=${s?"false":"true"}
                    @click=${this.handleLabelClick}
                >
                    <slot name="label">${this.label}</slot>
                </label>

                <slot
                    part="input"
                    class="input"
                    @slotchange=${this.syncRadios}
                    @click=${this.handleRadioClick}
                    @keydown=${this.handleKeyDown}
                ></slot>

                <slot
                    class=${c({"has-hint":i})}
                    part="hint"
                    id="hint"
                    name="hint"
                    aria-hidden=${i?"false":"true"}
                >
                    ${this.hint}
                </slot>
            </fieldset>
        `}};l.shadowRootOptions={...h.shadowRootOptions,delegatesFocus:!0},l.css=[y,v,E,w],r([f("slot:not([name])")],l.prototype,"defaultSlot",2),r([o()],l.prototype,"label",2),r([o()],l.prototype,"hint",2),r([o()],l.prototype,"name",2),r([m()],l.prototype,"value",1),r([o({attribute:"value",reflect:!0})],l.prototype,"defaultValue",2),r([o({reflect:!0})],l.prototype,"size",2),r([o({type:Boolean,reflect:!0})],l.prototype,"required",2),l=r([p("pc-radio-group")],l);export{l as a};
