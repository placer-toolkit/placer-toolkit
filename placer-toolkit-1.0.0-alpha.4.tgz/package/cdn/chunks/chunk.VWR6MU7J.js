import{a as u}from"./chunk.JWIAHBHS.js";import{a as d}from"./chunk.GG6CNHGL.js";import{a as h}from"./chunk.OVU4POJI.js";import{a as p}from"./chunk.SOXONO4R.js";import{a as M}from"./chunk.ZS4GILCB.js";import{a as m,b as n,c,d as f,e as g,g as y}from"./chunk.PLBYMK2K.js";import{d as l}from"./chunk.FKNAQN55.js";import{a as v}from"./chunk.H2EOXVSZ.js";import{a as b}from"./chunk.TBG3XWQL.js";import{b as o}from"./chunk.E6MOE4FE.js";var w=`:host {
    --icon-color: var(--pc-color-neutral-border-loud);
    --icon-color-active: var(--pc-color-warning-fill-loud);
    --icon-size: 1.2rem;

    display: inline-flex;
}

.rating {
    position: relative;
    display: inline-flex;
    border-radius: var(--pc-border-radius-m);
    vertical-align: middle;
}

.rating:focus {
    outline: none;
}

.rating:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.rating-icons {
    display: inline-flex;
    position: relative;
    font-size: var(--icon-size);
    line-height: 0;
    color: var(--icon-color);
    white-space: nowrap;
    cursor: pointer;
}

.rating-icons > * {
    padding: 0.125em;
}

.rating-icon-active,
.rating-partial-filled {
    color: var(--icon-color-active);
}

.rating-partial-icon-container {
    position: relative;
}

.rating-partial-filled {
    position: absolute;
    inset-block-start: 0.125em;
    inset-inline-start: 0.125em;
}

.rating-icon {
    pointer-events: none;
    transition: all var(--pc-transition-fast) ease-in-out;
}

.rating-icon pc-icon::part(svg) {
    overflow: visible;
}

.rating-icon-hover {
    scale: 1.15;
}

.disabled .rating-icons,
.readonly .rating-icons {
    cursor: default;
}

.disabled .rating-icon-hover,
.readonly .rating-icon-hover {
    scale: none;
}

.disabled {
    opacity: 0.5;
}

.disabled .rating-icons {
    cursor: not-allowed;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}

@media (forced-colors: active) {
    .rating-icon-active {
        color: SelectedItem;
    }
}
`;var t=class extends y{constructor(){super(...arguments);this.localize=new b(this);this.hoverValue=0;this.isHovering=!1;this.label="";this.value=0;this.max=5;this.precision=1;this.readonly=!1;this.disabled=!1;this.getIcon=(e,a)=>a?`
                <pc-icon library="system" icon-style="solid" name="star"></pc-icon>
            `:`
                <pc-icon library="system" icon-style="regular" name="star"></pc-icon>
            `}getValueFromMousePosition(e){return this.getValueFromXCoordinate(e.clientX)}getValueFromTouchPosition(e){return this.getValueFromXCoordinate(e.touches[0].clientX)}getValueFromXCoordinate(e){let a=this.localize.dir()==="rtl",{left:i,right:r,width:s}=this.rating.getBoundingClientRect(),$=a?this.roundToPrecision((r-e)/s*this.max,this.precision):this.roundToPrecision((e-i)/s*this.max,this.precision);return M($,0,this.max)}handleClick(e){this.disabled||(this.setValue(this.getValueFromMousePosition(e)),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}))}setValue(e){this.disabled||this.readonly||(this.value=e===this.value?0:e,this.isHovering=!1)}handleKeyDown(e){let a=this.localize.dir()==="ltr",i=this.localize.dir()==="rtl",r=this.value;if(!(this.disabled||this.readonly)){if(e.key==="ArrowDown"||a&&e.key==="ArrowLeft"||i&&e.key==="ArrowRight"){let s=e.shiftKey?1:this.precision;this.value=Math.max(0,this.value-s),e.preventDefault()}if(e.key==="ArrowUp"||a&&e.key==="ArrowRight"||i&&e.key==="ArrowLeft"){let s=e.shiftKey?1:this.precision;this.value=Math.min(this.max,this.value+s),e.preventDefault()}e.key==="Home"&&(this.value=0,e.preventDefault()),e.key==="End"&&(this.value=this.max,e.preventDefault()),this.value!==r&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))})}}handleMouseEnter(e){this.isHovering=!0,this.hoverValue=this.getValueFromMousePosition(e)}handleMouseMove(e){this.hoverValue=this.getValueFromMousePosition(e)}handleMouseLeave(){this.isHovering=!1}handleTouchStart(e){this.isHovering=!0,this.hoverValue=this.getValueFromTouchPosition(e),e.preventDefault()}handleTouchMove(e){this.hoverValue=this.getValueFromTouchPosition(e)}handleTouchEnd(e){this.isHovering=!1,this.setValue(this.hoverValue),this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),e.preventDefault()}roundToPrecision(e,a=.5){let i=1/a;return Math.ceil(e*i)/i}handleHoverValueChange(){this.dispatchEvent(new p({phase:"move",value:this.hoverValue}))}handleIsHoveringChange(){this.dispatchEvent(new p({phase:this.isHovering?"start":"end",value:this.hoverValue}))}focus(e){this.rating.focus(e)}blur(){this.rating.blur()}render(){let e=this.localize.dir()==="rtl",a=Array.from(Array(this.max).keys()),i=0;return this.disabled||this.readonly?i=this.value:i=this.isHovering?this.hoverValue:this.value,l`
            <div
                part="base"
                class=${h({rating:!0,readonly:this.readonly,disabled:this.disabled,"is-rtl":e})}
                role="slider"
                aria-label=${this.label}
                aria-disabled=${this.disabled?"true":"false"}
                aria-readonly=${this.readonly?"true":"false"}
                aria-valuenow=${this.value}
                aria-valuemin=${0}
                aria-valuemax=${this.max}
                tabindex=${this.disabled||this.readonly?"-1":"0"}
                @click=${this.handleClick}
                @keydown=${this.handleKeyDown}
                @mouseenter=${this.handleMouseEnter}
                @touchstart=${this.handleTouchStart}
                @mouseleave=${this.handleMouseLeave}
                @touchend=${this.handleTouchEnd}
                @mousemove=${this.handleMouseMove}
                @touchmove=${this.handleTouchMove}
            >
                <span class="rating-icons">
                    ${a.map(r=>{let s=i>=r+1;return i>r&&i<r+1?l`
                                <span
                                    class=${h({"rating-icon":!0,"rating-partial-icon-container":!0,"rating-icon-hover":this.isHovering&&Math.ceil(i)===r+1})}
                                    role="presentation"
                                >
                                    <div
                                        style=${d({clipPath:e?`inset(0 ${(i-r)*100}% 0 0)`:`inset(0 0 0 ${(i-r)*100}%)`})}
                                    >
                                        ${u(this.getIcon(r+1,!1))}
                                    </div>
                                    <div
                                        class="rating-partial-filled"
                                        style=${d({clipPath:e?`inset(0 0 0 ${100-(i-r)*100}%)`:`inset(0 ${100-(i-r)*100}% 0 0)`})}
                                    >
                                        ${u(this.getIcon(r+1,!0))}
                                    </div>
                                </span>
                            `:l`
                            <span
                                class=${h({"rating-icon":!0,"rating-icon-hover":this.isHovering&&Math.ceil(i)===r+1,"rating-icon-active":i>=r+1})}
                                role="presentation"
                            >
                                ${u(this.getIcon(r+1,s))}
                            </span>
                        `})}
                </span>
            </div>
        `}};t.css=w,o([g(".rating")],t.prototype,"rating",2),o([c()],t.prototype,"hoverValue",2),o([c()],t.prototype,"isHovering",2),o([n()],t.prototype,"label",2),o([n({type:Number})],t.prototype,"value",2),o([n({type:Number})],t.prototype,"max",2),o([n({type:Number})],t.prototype,"precision",2),o([n({type:Boolean,reflect:!0})],t.prototype,"readonly",2),o([n({type:Boolean})],t.prototype,"disabled",2),o([n()],t.prototype,"getIcon",2),o([f({passive:!0})],t.prototype,"handleTouchMove",1),o([v("hoverValue")],t.prototype,"handleHoverValueChange",1),o([v("isHovering")],t.prototype,"handleIsHoveringChange",1),t=o([m("pc-rating")],t);export{t as a};
