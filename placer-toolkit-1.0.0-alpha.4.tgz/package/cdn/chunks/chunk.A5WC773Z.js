import{d as L,e as z,f as Y,g as H,j as O}from"./chunk.U3EO6U64.js";import{a as x}from"./chunk.BSQP4EKW.js";import{a as A}from"./chunk.Y452TQZB.js";import{a as P}from"./chunk.OOPBLVP2.js";import{a as M}from"./chunk.OMC4FRTB.js";import{a as C}from"./chunk.GFCFF7RE.js";import{a as R}from"./chunk.C4FIATXW.js";import{a as g,d as S}from"./chunk.RZZMGXAZ.js";import{a as $}from"./chunk.U4YNKCI4.js";import{b as D}from"./chunk.ZS4GILCB.js";import{a as k,b as f,e as b,g as I}from"./chunk.PLBYMK2K.js";import{d as w}from"./chunk.FKNAQN55.js";import{a as y,c as v}from"./chunk.N5AZOOIZ.js";import{a as T}from"./chunk.TBG3XWQL.js";import{b as c}from"./chunk.E6MOE4FE.js";var j=`:host {
    display: contents;
}

#menu {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0.25em;
    inline-size: max-content;
    max-inline-size: var(--auto-size-available-width) !important;
    max-block-size: var(--auto-size-available-height) !important;
    background-color: var(--pc-color-surface-raised);
    color: var(--pc-color-text-normal);
    border: var(--pc-border-width-s) var(--pc-border-style)
        var(--pc-color-surface-border);
    border-radius: calc(var(--pc-border-radius-m) + 0.25em);
    text-align: start;
    user-select: none;
    overflow: auto;
    box-shadow: var(--pc-shadow-m);
}

#menu ::slotted(h1),
#menu ::slotted(h2),
#menu ::slotted(h3),
#menu ::slotted(h4),
#menu ::slotted(h5),
#menu ::slotted(h6) {
    display: block !important;
    margin-block: 0.25em !important;
    margin-inline: 0 !important;
    padding-block: 0.25em !important;
    padding-inline: 1.1em !important;
    color: var(--pc-color-text-quiet) !important;
    font-family: var(--pc-font-sans) !important;
    font-weight: var(--pc-font-weight-semibold) !important;
    font-size: var(--pc-font-size-smaller) !important;
}

#menu ::slotted(pc-dropdown-item[checkbox-adjacent]) h1,
#menu ::slotted(pc-dropdown-item[checkbox-adjacent]) h2,
#menu ::slotted(pc-dropdown-item[checkbox-adjacent]) h3,
#menu ::slotted(pc-dropdown-item[checkbox-adjacent]) h4,
#menu ::slotted(pc-dropdown-item[checkbox-adjacent]) h5,
#menu ::slotted(pc-dropdown-item[checkbox-adjacent]) h6 {
    padding-inline: 2.25em !important;
}

#menu ::slotted(pc-divider) {
    --spacing: 0.25em;
}

pc-popup[data-current-placement^="top"] #menu {
    transform-origin: bottom;
}

pc-popup[data-current-placement^="bottom"] #menu {
    transform-origin: top;
}

pc-popup[data-current-placement^="left"] #menu {
    transform-origin: right;
}

pc-popup[data-current-placement^="right"] #menu {
    transform-origin: left;
}

pc-popup[data-current-placement="left-start"] #menu {
    transform-origin: right top;
}

pc-popup[data-current-placement="left-end"] #menu {
    transform-origin: right bottom;
}

pc-popup[data-current-placement="right-start"] #menu {
    transform-origin: left top;
}

pc-popup[data-current-placement="right-end"] #menu {
    transform-origin: left bottom;
}
`;var E=new Set;y("dropdown.show",{keyframes:[{offset:0,opacity:0,transform:"scaleY(0.35) scaleX(0.95) translateY(-10px) rotate(1deg)"},{offset:.25,opacity:1,transform:"scaleY(1.03) scaleX(1.005) translateY(2px) rotate(-0.5deg)"},{offset:.5,transform:"scaleY(0.995) scaleX(0.999) translateY(-0.5px) rotate(0.1deg)"},{offset:.75,transform:"scaleY(1.002) scaleX(1.0005) translateY(0.2px) rotate(-0.05deg)"},{offset:1,opacity:1,transform:"scaleY(1) scaleX(1) translateY(0) rotate(0deg)"}],options:{duration:1e3,easing:"cubic-bezier(0.2, 0.8, 0.2, 1)",fill:"forwards"}});y("dropdown.hide",{keyframes:[{offset:0,opacity:1,transform:"scaleY(1) scaleX(1) translateY(0) rotate(0deg)"},{offset:.15,transform:"scaleY(1.005) scaleX(1.001) translateY(0.5px) rotate(-0.002deg)"},{offset:.4,transform:"scaleY(0.99) scaleX(0.998) translateY(-1px) rotate(0.008deg)"},{offset:.75,transform:"scaleY(0.6) scaleX(0.9) translateY(10px) rotate(0.007deg)"},{offset:1,opacity:0,transform:"scaleY(0.3) scaleX(0.8) translateY(25px) rotate(0.01deg)"}],options:{duration:400,easing:"cubic-bezier(0.6, 0.05, 0.8, 0.2)",fill:"forwards"}});var m=class extends I{constructor(){super(...arguments);this.submenuCleanups=new Map;this.localize=new T(this);this.userTypedQuery="";this.openSubmenuStack=[];this.open=!1;this.size="medium";this.placement="bottom-start";this.distance=0;this.skidding=0;this.handleDocumentKeyDown=async e=>{let t=this.localize.dir()==="rtl";if(e.key==="Escape"){let o=this.getTrigger();e.preventDefault(),e.stopPropagation(),this.open=!1,o?.focus({preventScroll:!0});return}let n=[...$()].find(o=>o.localName==="pc-dropdown-item"),s=n?.localName==="pc-dropdown-item",r=this.getCurrentSubmenuItem(),i=!!r,a,u,p;i?(a=this.getSubmenuItems(r),u=a.find(o=>o.active||o===n),p=u?a.indexOf(u):-1):(a=this.getItems(),u=a.find(o=>o.active||o===n),p=u?a.indexOf(u):-1);let l;if(e.key==="ArrowUp"&&(e.preventDefault(),e.stopPropagation(),p>0?l=a[p-1]:l=a[a.length-1]),e.key==="ArrowDown"&&(e.preventDefault(),e.stopPropagation(),p!==-1&&p<a.length-1?l=a[p+1]:l=a[0]),e.key===(t?"ArrowLeft":"ArrowRight")&&s&&u&&u.hasSubmenu){e.preventDefault(),e.stopPropagation(),u.submenuOpen=!0,this.addToSubmenuStack(u),setTimeout(()=>{let o=this.getSubmenuItems(u);o.length>0&&(o.forEach((h,d)=>h.active=d===0),o[0].focus({preventScroll:!0}))},0);return}if(e.key===(t?"ArrowRight":"ArrowLeft")&&i){e.preventDefault(),e.stopPropagation();let o=this.removeFromSubmenuStack();o&&(o.submenuOpen=!1,setTimeout(()=>{o.focus({preventScroll:!0}),o.active=!0,(o.slot==="submenu"?this.getSubmenuItems(o.parentElement):this.getItems()).forEach(d=>{d!==o&&(d.active=!1)})},0));return}if((e.key==="Home"||e.key==="End")&&(e.preventDefault(),e.stopPropagation(),l=e.key==="Home"?a[0]:a[a.length-1]),e.key==="Tab"&&await this.hideMenu(),e.key.length===1&&!(e.metaKey||e.ctrlKey||e.altKey)&&!(e.key===" "&&this.userTypedQuery==="")&&(clearTimeout(this.userTypedTimeout),this.userTypedTimeout=setTimeout(()=>{this.userTypedQuery=""},1e3),this.userTypedQuery+=e.key,a.some(o=>{let h=(o.textContent||"").trim().toLowerCase(),d=this.userTypedQuery.trim().toLowerCase();return h.startsWith(d)?(l=o,!0):!1})),l){e.preventDefault(),e.stopPropagation(),a.forEach(o=>o.active=o===l),l.focus({preventScroll:!0});return}(e.key==="Enter"||e.key===" "&&this.userTypedQuery==="")&&s&&u&&(e.preventDefault(),e.stopPropagation(),u.hasSubmenu?(u.submenuOpen=!0,this.addToSubmenuStack(u),setTimeout(()=>{let o=this.getSubmenuItems(u);o.length>0&&(o.forEach((h,d)=>h.active=d===0),o[0].focus({preventScroll:!0}))},0)):this.makeSelection(u))};this.handleDocumentPointerDown=e=>{e.composedPath().some(s=>s instanceof HTMLElement?s===this||s.closest('pc-dropdown, [part="submenu"]'):!1)||(this.open=!1)};this.handleGlobalMouseMove=e=>{let t=this.getCurrentSubmenuItem();if(!t?.submenuOpen||!t.submenuElement)return;let n=t.submenuElement.getBoundingClientRect(),s=this.localize.dir()==="rtl",r=s?n.right:n.left,i=s?Math.max(e.clientX,r):Math.min(e.clientX,r),a=Math.max(n.top,Math.min(e.clientY,n.bottom));t.submenuElement.style.setProperty("--safe-triangle-cursor-x",`${i}px`),t.submenuElement.style.setProperty("--safe-triangle-cursor-y",`${a}px`);let u=t.matches(":hover"),p=t.submenuElement?.matches(":hover")||!!e.composedPath().find(l=>l instanceof HTMLElement&&l.closest('[part="submenu"]')===t.submenuElement);!u&&!p&&setTimeout(()=>{!t.matches(":hover")&&!t.submenuElement?.matches(":hover")&&(t.submenuOpen=!1)},100)}}firstUpdated(){this.syncARIAAttributes()}disconnectedCallback(){super.disconnectedCallback(),clearInterval(this.userTypedTimeout),this.closeAllSubmenus(),this.submenuCleanups.forEach(e=>e()),this.submenuCleanups.clear(),document.removeEventListener("mousemove",this.handleGlobalMouseMove)}async updated(e){e.has("open")&&(this.customStates.set("open",this.open),this.open?await this.showMenu():(this.closeAllSubmenus(),await this.hideMenu())),e.has("size")&&this.syncItemSizes()}getItems(e=!1){let t=this.defaultSlot.assignedElements({flatten:!0}).filter(n=>n.localName==="pc-dropdown-item");return e?t:t.filter(n=>!n.disabled)}getSubmenuItems(e,t=!1){let n=e.shadowRoot?.querySelector('slot[name="submenu"]')||e.querySelector('slot[name="submenu"]');if(!n)return[];let s=n.assignedElements({flatten:!0}).filter(r=>r.localName==="pc-dropdown-item");return t?s:s.filter(r=>!r.disabled)}syncItemSizes(){this.defaultSlot.assignedElements({flatten:!0}).filter(t=>t.localName==="pc-dropdown-item").forEach(t=>t.size=this.size)}addToSubmenuStack(e){let t=this.openSubmenuStack.indexOf(e);t!==-1?this.openSubmenuStack=this.openSubmenuStack.slice(0,t+1):this.openSubmenuStack.push(e)}removeFromSubmenuStack(){return this.openSubmenuStack.pop()}getCurrentSubmenuItem(){return this.openSubmenuStack.length>0?this.openSubmenuStack[this.openSubmenuStack.length-1]:void 0}closeAllSubmenus(){this.getItems(!0).forEach(t=>{t.submenuOpen=!1}),this.openSubmenuStack=[]}closeSiblingSubmenus(e){let t=e.closest('pc-dropdown-item:not([slot="submenu"])'),n;t?n=this.getSubmenuItems(t,!0):n=this.getItems(!0),n.forEach(s=>{s!==e&&s.submenuOpen&&(s.submenuOpen=!1)}),this.openSubmenuStack.includes(e)||this.openSubmenuStack.push(e)}getTrigger(){return this.querySelector('[slot="trigger"]')}async showMenu(){if(!this.getTrigger())return;let t=new C;if(this.dispatchEvent(t),t.defaultPrevented){this.open=!1;return}E.forEach(i=>i.open=!1),this.popup.active=!0,this.open=!0,E.add(this),this.syncARIAAttributes(),document.addEventListener("keydown",this.handleDocumentKeyDown),document.addEventListener("pointerdown",this.handleDocumentPointerDown),document.addEventListener("mousemove",this.handleGlobalMouseMove),this.menu.hidden=!1;let{keyframes:n,options:s}=v(this,"dropdown.show",{dir:this.localize.dir()});await g(this.menu,n,s),await S(this);let r=this.getItems();r.length>0&&(r.forEach((i,a)=>i.active=a===0),r[0].focus({preventScroll:!0})),this.dispatchEvent(new A)}async hideMenu(){let e=new M;if(this.dispatchEvent(e),e.defaultPrevented){this.open=!0;return}this.open=!1,E.delete(this),this.syncARIAAttributes(),document.removeEventListener("keydown",this.handleDocumentKeyDown),document.removeEventListener("pointerdown",this.handleDocumentPointerDown),document.removeEventListener("mousemove",this.handleGlobalMouseMove);let{keyframes:t,options:n}=v(this,"dropdown.hide",{dir:this.localize.dir()});await g(this.menu,t,n),await S(this),this.menu.hidden=!0,this.dispatchEvent(new P)}handleMenuClick(e){let t=e.target.closest("pc-dropdown-item");if(!(!t||t.disabled)){if(t.hasSubmenu){t.submenuOpen||(this.closeSiblingSubmenus(t),this.addToSubmenuStack(t),t.submenuOpen=!0),e.stopPropagation();return}this.makeSelection(t)}}async handleMenuSlotChange(){let e=this.getItems(!0);await Promise.all(e.map(s=>s.updateComplete)),this.syncItemSizes();let t=e.some(s=>s.type==="checkbox"),n=e.some(s=>s.hasSubmenu);e.forEach((s,r)=>{s.active=r===0,s.checkboxAdjacent=t,s.submenuAdjacent=n})}handleTriggerClick(){this.open=!this.open}handleSubmenuOpening(e){let t=e.detail.item;this.closeSiblingSubmenus(t),this.addToSubmenuStack(t),this.setupSubmenuPosition(t),this.processSubmenuItems(t)}setupSubmenuPosition(e){if(!e.submenuElement)return;this.cleanupSubmenuPosition(e);let t=L(e,e.submenuElement,()=>{this.positionSubmenu(e),this.updateSafeTriangleCoordinates(e)});this.submenuCleanups.set(e,t);let n=e.submenuElement.querySelector('slot[name="submenu"]');n&&(n.removeEventListener("slotchange",m.handleSubmenuSlotChange),n.addEventListener("slotchange",m.handleSubmenuSlotChange),m.handleSubmenuSlotChange({target:n}))}static handleSubmenuSlotChange(e){let t=e.target;if(!t)return;let n=t.assignedElements().filter(i=>i.localName==="pc-dropdown-item");if(n.length===0)return;let s=n.some(i=>i.hasSubmenu),r=n.some(i=>i.type==="checkbox");n.forEach(i=>{i.submenuAdjacent=s,i.checkboxAdjacent=r})}processSubmenuItems(e){if(!e.submenuElement)return;let t=this.getSubmenuItems(e,!0),n=t.some(r=>r.hasSubmenu),s=t.some(r=>r.type==="checkbox");t.forEach(r=>{r.submenuAdjacent=n,r.checkboxAdjacent=s})}cleanupSubmenuPosition(e){let t=this.submenuCleanups.get(e);t&&(t(),this.submenuCleanups.delete(e))}positionSubmenu(e){if(!e.submenuElement)return;let n=this.localize.dir()==="rtl"?"left-start":"right-start";O(e,e.submenuElement,{placement:n,middleware:[z({mainAxis:0,crossAxis:-5}),H({fallbackStrategy:"bestFit"}),Y({padding:8})]}).then(({x:s,y:r,placement:i})=>{e.submenuElement.setAttribute("data-placement",i),Object.assign(e.submenuElement.style,{left:`${s}px`,top:`${r}px`})})}updateSafeTriangleCoordinates(e){if(!e.submenuElement||!e.submenuOpen)return;if(document.activeElement?.matches(":focus-visible")){e.submenuElement.style.setProperty("--safe-triangle-visible","none");return}e.submenuElement.style.setProperty("--safe-triangle-visible","block");let n=e.submenuElement.getBoundingClientRect(),s=this.localize.dir()==="rtl";e.submenuElement.style.setProperty("--safe-triangle-submenu-start-x",`${s?n.right:n.left}px`),e.submenuElement.style.setProperty("--safe-triangle-submenu-start-y",`${n.top}px`),e.submenuElement.style.setProperty("--safe-triangle-submenu-end-x",`${s?n.right:n.left}px`),e.submenuElement.style.setProperty("--safe-triangle-submenu-end-y",`${n.bottom}px`)}makeSelection(e){let t=this.getTrigger();if(e.disabled)return;e.type==="checkbox"&&(e.checked=!e.checked);let n=new R({item:e});this.dispatchEvent(n),n.defaultPrevented||(this.open=!1,t?.focus({preventScroll:!0}))}async syncARIAAttributes(){let e=this.getTrigger(),t;e&&(e.localName==="pc-button"?(await customElements.whenDefined("pc-button"),await e.updateComplete,t=e.shadowRoot.querySelector('[part="base"]')):t=e,t.hasAttribute("id")||t.setAttribute("id",D("pc-dropdown-trigger-")),t.setAttribute("aria-haspopup","menu"),t.setAttribute("aria-expanded",this.open?"true":"false"),this.menu.setAttribute("aria-expanded","false"))}render(){let e=this.hasUpdated?this.popup.active:this.open;return w`
            <pc-popup
                placement=${this.placement}
                distance=${this.distance}
                skidding=${this.skidding}
                ?active=${e}
                flip-fallback-strategy="best-fit"
                shift-padding="10"
                auto-size="vertical"
                auto-size-padding="10"
                shift
                flip
            >
                <slot
                    name="trigger"
                    slot="anchor"
                    @click=${this.handleTriggerClick}
                    @slotchange=${this.syncARIAAttributes}
                ></slot>

                <div
                    part="menu"
                    id="menu"
                    role="menu"
                    tabindex="-1"
                    aria-orientation="vertical"
                    @click=${this.handleMenuClick}
                    @pc-submenu-opening=${this.handleSubmenuOpening}
                >
                    <slot @slotchange=${this.handleMenuSlotChange}></slot>
                </div>
            </pc-popup>
        `}};m.css=[x,j],c([b("slot:not([name])")],m.prototype,"defaultSlot",2),c([b("#menu")],m.prototype,"menu",2),c([b("pc-popup")],m.prototype,"popup",2),c([f({type:Boolean,reflect:!0})],m.prototype,"open",2),c([f({reflect:!0})],m.prototype,"size",2),c([f({reflect:!0})],m.prototype,"placement",2),c([f({type:Number})],m.prototype,"distance",2),c([f({type:Number})],m.prototype,"skidding",2),m=c([k("pc-dropdown")],m);export{m as a};
