import{a as c}from"./chunk.X4HZCQ2H.js";import{a as n}from"./chunk.OVU4POJI.js";import{a as p}from"./chunk.B3IRGDRW.js";import{a as r,b as i,e as l,g as s}from"./chunk.PLBYMK2K.js";import{d as a}from"./chunk.FKNAQN55.js";import{a as o}from"./chunk.H2EOXVSZ.js";import{a as d}from"./chunk.TBG3XWQL.js";import{b as t}from"./chunk.E6MOE4FE.js";var b=`:host {
    display: inline-block;
}

:host(:focus) {
    outline: transparent;
}

:host(:focus-visible) {
    outline: var(--pc-focus-ring);
    outline-offset: calc(
        -1 * var(--pc-focus-ring-width) - var(--pc-focus-ring-offset)
    );
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.tab {
    display: inline-flex;
    align-items: center;
    font-family: var(--pc-font-sans);
    font-size: var(--pc-font-size-s);
    font-weight: var(--pc-font-weight-semibold);
    border-radius: var(--pc-border-radius-m);
    color: var(--pc-color-neutral-on-quiet);
    padding: var(--pc-spacing-m);
    white-space: nowrap;
    user-select: none;
    -webkit-user-select: none;
    cursor: pointer;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    .tab:hover:not(.disabled, .active) {
        color: color-mix(
            in oklab,
            var(--pc-color-neutral-on-quiet),
            var(--pc-color-mix-hover)
        );
    }
}

.tab:active:not(.disabled, .active) {
    color: color-mix(
        in oklab,
        var(--pc-color-neutral-on-quiet),
        var(--pc-color-mix-active)
    );
}

.tab:focus-visible:not(.disabled, .active) {
    color: color-mix(
        in oklab,
        var(--pc-color-neutral-on-quiet),
        var(--pc-color-mix-hover)
    );
}

.tab.active:not(.disabled) {
    color: var(--pc-color-text-normal);
}

.tab.closable {
    padding-inline-end: var(--pc-spacing-s);
}

.tab.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.close-button {
    margin-inline-start: var(--pc-spacing-s);
}

.close-button::part(base) {
    padding: 0;
    inline-size: 100%;
    block-size: 100%;
    background-color: transparent;
    vertical-align: middle;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}

@media (forced-colors: active) {
    .tab.active:not(.disabled) {
        outline: var(--pc-border-width-s) var(--pc-border-style) transparent;
        outline-offset: -0.1875rem;
    }
}
`;var m=0,e=class extends s{constructor(){super(...arguments);this.localize=new d(this);this.attributeID=++m;this.componentID=`pc-tab-${this.attributeID}`;this.panel="";this.active=!1;this.closable=!1;this.disabled=!1;this.tabIndex=0}connectedCallback(){super.connectedCallback(),this.setAttribute("role","tab")}handleCloseClick(u){u.stopPropagation(),this.dispatchEvent(new p)}handleActiveChange(){this.setAttribute("aria-selected",this.active?"true":"false")}handleDisabledChange(){this.setAttribute("aria-disabled",this.disabled?"true":"false"),this.disabled&&!this.active&&(this.tabIndex=-1)}render(){return this.id=this.id.length>0?this.id:this.componentID,a`
            <div
                part="base"
                class=${n({tab:!0,active:this.active,closable:this.closable,disabled:this.disabled})}
            >
                <slot></slot>

                ${this.closable?a`
                          <pc-button
                              class="close-button"
                              size="small"
                              variant="plain"
                              tabindex="-1"
                              @click=${this.handleCloseClick}
                              exportparts="base:close-button-base"
                          >
                              <pc-icon
                                  library="system"
                                  icon-style="solid"
                                  name="xmark"
                                  label=${this.localize.term("close")}
                              ></pc-icon>
                          </pc-button>
                      `:""}
            </div>
        `}};e.css=b,e.dependencies={"pc-button":c},t([l(".tab")],e.prototype,"tab",2),t([i({reflect:!0})],e.prototype,"panel",2),t([i({type:Boolean,reflect:!0})],e.prototype,"active",2),t([i({type:Boolean,reflect:!0})],e.prototype,"closable",2),t([i({type:Boolean})],e.prototype,"disabled",2),t([i({type:Number,reflect:!0})],e.prototype,"tabIndex",2),t([o("active")],e.prototype,"handleActiveChange",1),t([o("disabled")],e.prototype,"handleDisabledChange",1),e=t([r("pc-tab")],e);export{e as a};
