import{a as o,g as i}from"./chunk.PLBYMK2K.js";import{d as a}from"./chunk.FKNAQN55.js";import{a as t}from"./chunk.TBG3XWQL.js";import{b as e}from"./chunk.E6MOE4FE.js";var l=`:host {
    --track-width: 0.125rem;
    --track-color: var(--pc-color-neutral-fill-normal);
    --indicator-color: var(--pc-color-primary-fill-loud);
    --speed: 2s;

    display: inline-flex;
    inline-size: 1em;
    block-size: 1em;
    flex: none;
}

.spinner {
    flex: 1 1 auto;
    inline-size: 100%;
    block-size: 100%;
    overflow: visible;
}

.track,
.indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
}

.track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
}

.indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
}

@keyframes spin {
    0% {
        rotate: 0deg;
        stroke-dasharray: 0% 314.159%;
    }

    50% {
        rotate: 450deg;
        stroke-dasharray: 157.08% 157.08%;
    }

    100% {
        rotate: 1080deg;
        stroke-dasharray: 0% 314.159%;
    }
}
`;var r=class extends i{constructor(){super(...arguments);this.localize=new t(this)}render(){return a`
            <svg
                class="spinner"
                part="base"
                role="progressbar"
                aria-label=${this.localize.term("loading")}
            >
                <circle class="track"></circle>
                <circle class="indicator"></circle>
            </svg>
        `}};r.css=l,r=e([o("pc-spinner")],r);export{r as a};
