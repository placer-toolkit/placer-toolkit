import{a as w}from"./chunk.OVU4POJI.js";import{a as L}from"./chunk.Y452TQZB.js";import{a as E}from"./chunk.OOPBLVP2.js";import{a as C}from"./chunk.OMC4FRTB.js";import{a as z}from"./chunk.GFCFF7RE.js";import{a as l}from"./chunk.RZZMGXAZ.js";import{a as x}from"./chunk.AGGS6MN5.js";import{a as h,b as g}from"./chunk.R2GXUKDX.js";import{a as u,b as n,e as v,g as y}from"./chunk.PLBYMK2K.js";import{d as p}from"./chunk.FKNAQN55.js";import{a as D}from"./chunk.RQ34LIU5.js";import{a as b}from"./chunk.H2EOXVSZ.js";import{a as c,c as r}from"./chunk.N5AZOOIZ.js";import{a as k}from"./chunk.TBG3XWQL.js";import{b as a}from"./chunk.E6MOE4FE.js";var T=`:host {
    --width: 31rem;
    --header-spacing: var(--pc-spacing-xl);
    --body-spacing: var(--pc-spacing-s) var(--pc-spacing-xl);
    --footer-spacing: var(--pc-spacing-s) var(--pc-spacing-xl)
        var(--pc-spacing-xl);

    display: none;
}

:host([open]) {
    display: block;
}

.dialog {
    display: flex;
    flex-direction: column;
    inset: 0;
    margin: auto;
    padding: 0;
    inline-size: var(--width);
    max-inline-size: calc(100% - var(--pc-spacing-xxl));
    max-block-size: calc(100% - var(--pc-spacing-xxl));
    background-color: var(--pc-color-surface-raised);
    color: inherit;
    border: none;
    border-radius: var(--pc-panel-border-radius);
    box-shadow: var(--pc-shadow-xl);
}

.dialog::backdrop {
    background-color: var(--pc-color-overlay-modal);
}

.dialog.show::backdrop {
    animation: dialog-backdrop-open 0.3s ease-out;
}

.dialog.hide::backdrop {
    animation: dialog-backdrop-close 0.2s ease-in;
}

.dialog:focus {
    outline: none;
}

.dialog.open {
    display: flex;
    opacity: 1;
}

.header {
    display: flex;
    gap: var(--pc-spacing-l);
    flex: 0 0 auto;
    flex-wrap: nowrap;
    padding: var(--header-spacing);
}

.title {
    align-self: center;
    flex: 1 1 auto;
    margin: 0;
    font-family: inherit;
    font-size: var(--pc-font-size-l);
    font-weight: var(--pc-font-weight-bold);
    line-height: var(--pc-line-height-dense);
}

.header-actions {
    display: flex;
    align-self: flex-start;
    justify-content: flex-end;
    gap: var(--pc-spacing-xs);
    flex-shrink: 0;
    flex-wrap: wrap;
}

.header-actions pc-button,
.header-actions ::slotted(pc-button) {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
}

.body {
    display: block;
    flex: 1 1 auto;
    padding: var(--body-spacing);
    overflow: auto;
    -webkit-overflow-scrolling: touch;
}

.footer {
    flex: 0 0 auto;
    padding: var(--footer-spacing);
    text-align: end;
}

.footer ::slotted(pc-button:not(:first-of-type)) {
    margin-inline-start: var(--pc-spacing-xs);
}

.dialog:not(.has-footer) .footer {
    display: none;
}

.dialog:not(:has(> .header)) .body {
    --body-spacing: var(--pc-spacing-xl) var(--pc-spacing-xl)
        var(--pc-spacing-s) var(--pc-spacing-xl);
}

.dialog:not(.has-footer) .body {
    --body-spacing: var(--pc-spacing-s) var(--pc-spacing-xl)
        var(--pc-spacing-xl) var(--pc-spacing-xl);
}

.dialog:not(:has(> .header), .has-footer) .body {
    --body-spacing: var(--pc-spacing-xl);
}

@keyframes dialog-backdrop-open {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes dialog-backdrop-close {
    0% {
        opacity: 1;
    }

    100% {
        opacity: 0;
    }
}

@media (forced-colors: active) {
    .dialog {
        border: 1px solid oklch(100% 0 0);
    }
}

@media screen and (max-width: 420px) {
    .dialog {
        max-block-size: 80dvh;
    }
}
`;document.addEventListener("click",f=>{let d=f.target.closest("[data-dialog]");if(d instanceof Element){let[e,o]=D(d.getAttribute("data-dialog")||"");if(e==="open"&&o?.length){let s=d.getRootNode().getElementById(o);s?.localName==="pc-dialog"?s.open=!0:console.warn(`A dialog with an id of \u201C${o}\u201D could not be found in this document.`)}}});document.addEventListener("pointerdown",()=>{});c("dialog.show",{keyframes:[{opacity:0,scale:.8},{opacity:1,scale:1}],options:{duration:300,easing:"cubic-bezier(0.215, 0.61, 0.355, 1)"}});c("dialog.hide",{keyframes:[{opacity:1,scale:1},{opacity:0,scale:.8}],options:{duration:200,easing:"cubic-bezier(0.55, 0.055, 0.675, 0.19)"}});c("dialog.denyClose",{keyframes:[{scale:1},{scale:1.02},{scale:1}],options:{duration:300,easing:"cubic-bezier(0.0, 0.7, 0.2, 1)"}});var t=class extends y{constructor(){super(...arguments);this.hasSlotController=new x(this,"footer");this.localize=new k(this);this.open=!1;this.label="";this.noHeader=!1;this.noLightDismiss=!1;this.handleDocumentKeyDown=e=>{e.key==="Escape"&&this.open&&(e.preventDefault(),e.stopPropagation(),this.requestClose(this.dialog))}}firstUpdated(){this.open&&(this.addOpenListeners(),this.dialog.showModal(),h(this))}disconnectedCallback(){super.disconnectedCallback(),g(this),this.removeOpenListeners()}async requestClose(e){let o=new C({source:e});if(this.dispatchEvent(o),o.defaultPrevented){this.open=!0;let m=r(this,"dialog.denyClose",{dir:this.localize.dir()});l(this.dialog,m.keyframes,m.options);return}this.removeOpenListeners(),this.dialog.classList.add("hide"),this.dialog.classList.remove("show");let i=r(this,"dialog.hide",{dir:this.localize.dir()});await l(this.dialog,i.keyframes,i.options),this.open=!1,this.dialog.close(),g(this);let s=this.originalTrigger;typeof s?.focus=="function"&&setTimeout(()=>s.focus()),this.dispatchEvent(new E)}addOpenListeners(){document.addEventListener("keydown",this.handleDocumentKeyDown)}removeOpenListeners(){document.removeEventListener("keydown",this.handleDocumentKeyDown)}handleDialogCancel(e){e.preventDefault(),!this.dialog.classList.contains("hide")&&e.target===this.dialog&&this.requestClose(this.dialog)}handleDialogClick(e){let i=e.target.closest('[data-dialog="close"]');i&&(e.stopPropagation(),this.requestClose(i))}async handleDialogPointerDown(e){if(e.target===this.dialog)if(!this.noLightDismiss)this.requestClose(this.dialog);else{let o=r(this,"dialog.denyClose",{dir:this.localize.dir()});l(this.dialog,o.keyframes,o.options)}}handleOpenChange(){this.open&&!this.dialog.open?this.show():!this.open&&this.dialog.open&&(this.open=!0,this.requestClose(this.dialog))}async show(){let e=new z;if(this.dispatchEvent(e),e.defaultPrevented){this.open=!1;return}this.addOpenListeners(),this.originalTrigger=document.activeElement,this.open=!0,this.dialog.showModal(),h(this),requestAnimationFrame(()=>{let i=this.querySelector("[autofocus]");i&&typeof i.focus=="function"?i.focus():this.dialog.focus()}),this.dialog.classList.add("show"),this.dialog.classList.remove("hide");let o=r(this,"dialog.show",{dir:this.localize.dir()});l(this.dialog,o.keyframes,o.options),this.dispatchEvent(new L)}render(){return p`
            <dialog
                part="dialog"
                class=${w({dialog:!0,open:this.open,"has-footer":this.hasSlotController.test("footer")})}
                @click=${this.handleDialogClick}
                @pointerdown=${this.handleDialogPointerDown}
                @cancel=${this.handleDialogCancel}
            >
                ${this.noHeader?"":p`
                          <header part="header" class="header">
                              <h2 class="title" part="title" id="title">
                                  <slot name="label">
                                      ${this.label.length>0?this.label:"\u200B"}
                                  </slot>
                              </h2>
                              <div part="header-actions" class="header-actions">
                                  <slot name="header-actions"></slot>
                                  <pc-button
                                      part="close-button"
                                      class="dialog-close"
                                      size="small"
                                      variant="plain"
                                      exportparts="base:close-button-base"
                                      @click=${e=>this.requestClose(e.target)}
                                  >
                                      <pc-icon
                                          library="system"
                                          icon-style="solid"
                                          name="xmark"
                                          label=${this.localize.term("close")}
                                      ></pc-icon>
                                  </pc-button>
                              </div>
                          </header>
                      `}

                <div part="body" class="body" tabindex="-1">
                    <slot></slot>
                </div>

                <footer part="footer" class="footer">
                    <slot name="footer"></slot>
                </footer>
            </dialog>
        `}};t.css=T,a([v(".dialog")],t.prototype,"dialog",2),a([n({type:Boolean,reflect:!0})],t.prototype,"open",2),a([n({reflect:!0})],t.prototype,"label",2),a([n({attribute:"no-header",type:Boolean,reflect:!0})],t.prototype,"noHeader",2),a([n({attribute:"no-light-dismiss",type:Boolean})],t.prototype,"noLightDismiss",2),a([b("open",{waitUntilFirstUpdate:!0})],t.prototype,"handleOpenChange",1),t=a([u("pc-dialog")],t);export{t as a};
