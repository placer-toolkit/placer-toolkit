import{a as v}from"./chunk.OVU4POJI.js";import{a as k}from"./chunk.MQGHP5IK.js";import{a as x}from"./chunk.AZ2IVZIA.js";import{c as m}from"./chunk.R2GXUKDX.js";import{a as g,b,c as u,d as y,e as h,g as T}from"./chunk.PLBYMK2K.js";import{d as p}from"./chunk.FKNAQN55.js";import{a as f}from"./chunk.H2EOXVSZ.js";import{a as w}from"./chunk.TBG3XWQL.js";import{b as o}from"./chunk.E6MOE4FE.js";var S=`:host {
    --indicator-color: var(--pc-color-primary-fill-loud);
    --track-width: 4px;

    display: block;
}

.tab-group {
    display: flex;
    border-radius: 0;
}

.tabs {
    display: flex;
    position: relative;
}

.indicator {
    position: absolute;
    transition:
        translate 0.4s cubic-bezier(0.2, 1, 0.3, 1),
        inline-size 0.4s cubic-bezier(0.2, 1, 0.3, 1);
}

.has-scroll-controls .navigation-container {
    position: relative;
    padding-inline: calc(var(--pc-spacing-xxxl) + var(--pc-spacing-xs));
}

.has-scroll-controls .scroll-button-start-hidden,
.has-scroll-controls .scroll-button-end-hidden {
    opacity: 0;
    pointer-events: none;
    visibility: hidden;
}

.navigation-container,
.navigation {
    outline: none;
}

.body {
    display: block;
}

.scroll-button {
    display: flex;
    position: absolute;
    align-items: center;
    justify-content: center;
    inset-block: 0;
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
    transition:
        opacity var(--pc-transition-fast) ease-in-out,
        visibility 0s ease-in-out var(--pc-transition-fast);
}

.scroll-button-start {
    inset-inline-start: 0;
}

.scroll-button-end {
    inset-inline-end: 0;
}

.is-rtl .scroll-button-start {
    inset-inline-start: auto;
    inset-inline-end: 0;
}

.is-rtl .scroll-button-end {
    inset-inline-start: 0;
    inset-inline-end: auto;
}

.top {
    flex-direction: column;
}

.top .navigation-container {
    order: 1;
}

.top .navigation {
    display: flex;
    overflow-x: auto;
    scrollbar-width: none;
}

.top .navigation::-webkit-scrollbar {
    inline-size: 0;
    block-size: 0;
}

.top .tabs {
    position: relative;
    flex-direction: row;
    flex: 1 1 auto;
}

.top .indicator {
    inset-block-end: 0;
    min-block-size: var(--track-width);
    background-color: var(--indicator-color);
    border-radius: var(--pc-border-radius-pill);
}

.top .body {
    order: 2;
}

.top ::slotted(pc-tab-panel) {
    padding-block: var(--pc-spacing-m);
}

.bottom {
    flex-direction: column;
}

.bottom .navigation-container {
    order: 2;
}

.bottom .navigation {
    display: flex;
    overflow-x: auto;
    scrollbar-width: none;
}

.bottom .tabs {
    position: relative;
    flex-direction: row;
    flex: 1 1 auto;
}

.bottom .indicator {
    inset-block-start: 0;
    min-block-size: var(--track-width);
    background-color: var(--indicator-color);
    border-radius: var(--pc-border-radius-pill);
}

.bottom .body {
    order: 1;
}

.bottom ::slotted(pc-tab-panel) {
    padding-block: var(--pc-spacing-m);
}

.start {
    flex-direction: row;
}

.start .navigation-container {
    order: 1;
}

.start .tabs {
    flex-direction: column;
    flex: 0 0 auto;
}

.start .indicator {
    inset-inline-end: calc(-1 * var(--track-width));
    min-inline-size: var(--track-width);
    background-color: var(--indicator-color);
    border-radius: var(--pc-border-radius-pill);
}

.start .body {
    flex: 1 1 auto;
    order: 2;
}

.start ::slotted(pc-tab-panel) {
    padding: 0 var(--pc-spacing-m);
}

.end {
    flex-direction: row;
}

.end .navigation-container {
    order: 2;
}

.end .tabs {
    flex-direction: column;
    flex: 0 0 auto;
}

.end .indicator {
    inset-inline-start: calc(-1 * var(--track-width));
    min-inline-size: var(--track-width);
    background-color: var(--indicator-color);
    border-radius: var(--pc-border-radius-pill);
}

.end.is-rtl .indicator {
    inset-inline-start: auto;
    inset-inline-end: 0;
}

.end .body {
    flex: 1 1 auto;
    order: 1;
}

.end ::slotted(pc-tab-panel) {
    padding-inline: var(--pc-spacing-m);
}
`;var s=class extends T{constructor(){super(...arguments);this.localize=new w(this);this.tabs=[];this.focusableTabs=[];this.panels=[];this.hasScrollControls=!1;this.shouldHideScrollStartButton=!1;this.shouldHideScrollEndButton=!1;this.placement="top";this.activation="auto";this.noScrollControls=!1;this.fixedScrollControls=!1;this.scrollOffset=1}connectedCallback(){let t=Promise.all([customElements.whenDefined("pc-tab"),customElements.whenDefined("pc-tab-panel")]);super.connectedCallback(),this.resizeObserver=new ResizeObserver(()=>{this.repositionIndicator(),this.updateScrollControls()}),this.mutationObserver=new MutationObserver(a=>{let i=a.filter(({target:e})=>{if(e===this)return!0;if(e.closest("pc-tab-group")!==this)return!1;let n=e.tagName.toLowerCase();return n==="pc-tab"||n==="pc-tab-panel"});if(i.length!==0){if(i.some(e=>!["aria-labelledby","aria-controls"].includes(e.attributeName))&&setTimeout(()=>this.setAriaLabels()),i.some(e=>e.attributeName==="disabled"))this.syncTabsAndPanels();else if(i.some(e=>e.attributeName==="active")){let n=i.filter(c=>c.attributeName==="active"&&c.target.tagName.toLowerCase()==="pc-tab").map(c=>c.target).find(c=>c.active);n&&this.setActiveTab(n)}}}),this.updateComplete.then(()=>{this.syncTabsAndPanels(),this.mutationObserver.observe(this,{attributes:!0,attributeFilter:["active","disabled","name","panel"],childList:!0,subtree:!0}),this.resizeObserver.observe(this.navigation),t.then(()=>{new IntersectionObserver((i,e)=>{i[0].intersectionRatio>0&&(this.setAriaLabels(),this.setActiveTab(this.getActiveTab()??this.tabs[0],{emitEvents:!1}),e.unobserve(i[0].target))}).observe(this.tabGroup)})})}disconnectedCallback(){super.disconnectedCallback(),this.mutationObserver?.disconnect(),this.navigation&&this.resizeObserver?.unobserve(this.navigation)}getAllTabs(){return this.shadowRoot.querySelector('slot[name="navigation"]').assignedElements()}getAllPanels(){return[...this.body.assignedElements()].filter(t=>t.tagName.toLowerCase()==="pc-tab-panel")}getActiveTab(){return this.tabs.find(t=>t.active)}handleClick(t){let i=t.target.closest("pc-tab");i?.closest("pc-tab-group")===this&&i!==null&&this.setActiveTab(i,{scrollBehavior:"smooth"})}handleKeyDown(t){let i=t.target.closest("pc-tab");if(i?.closest("pc-tab-group")===this&&(["Enter"," "].includes(t.key)&&i!==null&&(this.setActiveTab(i,{scrollBehavior:"smooth"}),t.preventDefault()),["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(t.key))){let n=this.tabs.find(l=>l.matches(":focus")),c=this.localize.dir()==="rtl",r=null;if(n?.tagName.toLowerCase()==="pc-tab"){if(t.key==="Home")r=this.focusableTabs[0];else if(t.key==="End")r=this.focusableTabs[this.focusableTabs.length-1];else if(["top","bottom"].includes(this.placement)&&t.key===(c?"ArrowRight":"ArrowLeft")||["start","end"].includes(this.placement)&&t.key==="ArrowUp"){let l=this.tabs.findIndex(d=>d===n);r=this.findNextFocusableTab(l,"backward")}else if(["top","bottom"].includes(this.placement)&&t.key===(c?"ArrowLeft":"ArrowRight")||["start","end"].includes(this.placement)&&t.key==="ArrowDown"){let l=this.tabs.findIndex(d=>d===n);r=this.findNextFocusableTab(l,"forward")}if(!r)return;r.tabIndex=0,r.focus({preventScroll:!0}),this.activation==="auto"?this.setActiveTab(r,{scrollBehavior:"smooth"}):this.tabs.forEach(l=>{l.tabIndex=l===r?0:-1}),["top","bottom"].includes(this.placement)&&m(r,this.navigation,"horizontal"),t.preventDefault()}}}handleScrollToStart(){this.navigation.scroll({left:this.localize.dir()==="rtl"?this.navigation.scrollLeft+this.navigation.clientWidth:this.navigation.scrollLeft-this.navigation.clientWidth,behavior:"smooth"})}handleScrollToEnd(){this.navigation.scroll({left:this.localize.dir()==="rtl"?this.navigation.scrollLeft-this.navigation.clientWidth:this.navigation.scrollLeft+this.navigation.clientWidth,behavior:"smooth"})}setActiveTab(t,a){if(a={emitEvents:!0,scrollBehavior:"auto",...a},t!==this.activeTab&&!t.disabled){let i=this.activeTab;this.activeTab=t,this.tabs.forEach(e=>{e.active=e===this.activeTab,e.tabIndex=e===this.activeTab?0:-1}),this.panels.forEach(e=>e.active=e.name===this.activeTab?.panel),this.syncIndicator(),["top","bottom"].includes(this.placement)&&m(this.activeTab,this.navigation,"horizontal",a.scrollBehavior),a.emitEvents&&(i&&this.dispatchEvent(new x({name:i.panel})),this.dispatchEvent(new k({name:this.activeTab.panel})))}}setAriaLabels(){this.tabs.forEach(t=>{let a=this.panels.find(i=>i.name===t.panel);a&&(t.setAttribute("aria-controls",a.getAttribute("id")),a.setAttribute("aria-labelledby",t.getAttribute("id")))})}repositionIndicator(){let t=this.getActiveTab();if(!t)return;let a=t.clientWidth,i=t.clientHeight,e=this.localize.dir()==="rtl",n=this.getAllTabs(),r=n.slice(0,n.indexOf(t)).reduce((l,d)=>({left:l.left+d.clientWidth,top:l.top+d.clientHeight}),{left:0,top:0});switch(this.placement){case"top":case"bottom":this.indicator.style.inlineSize=`${a}px`,this.indicator.style.blockSize="auto",this.indicator.style.translate=e?`${-1*r.left}px`:`${r.left}px`;break;case"start":case"end":this.indicator.style.inlineSize="auto",this.indicator.style.blockSize=`${i}px`,this.indicator.style.translate=`0 ${r.top}px`;break}}syncTabsAndPanels(){this.tabs=this.getAllTabs(),this.focusableTabs=this.tabs.filter(t=>!t.disabled),this.panels=this.getAllPanels(),this.syncIndicator(),this.updateComplete.then(()=>this.updateScrollControls())}findNextFocusableTab(t,a){let i=null,e=a==="forward"?1:-1,n=t+e;for(;t<this.tabs.length;){if(i=this.tabs[n]||null,i===null){a==="forward"?i=this.focusableTabs[0]:i=this.focusableTabs[this.focusableTabs.length-1];break}if(!i.disabled)break;n+=e}return i}updateScrollButtons(){this.hasScrollControls&&!this.fixedScrollControls&&(this.shouldHideScrollStartButton=this.scrollFromStart()<=this.scrollOffset,this.shouldHideScrollEndButton=this.isScrolledToEnd())}isScrolledToEnd(){return this.scrollFromStart()+this.navigation.clientWidth>=this.navigation.scrollWidth-this.scrollOffset}scrollFromStart(){return this.localize.dir()==="rtl"?-this.navigation.scrollLeft:this.navigation.scrollLeft}updateScrollControls(){this.noScrollControls?this.hasScrollControls=!1:this.hasScrollControls=["top","bottom"].includes(this.placement)&&this.navigation.scrollWidth>this.navigation.clientWidth+1,this.updateScrollButtons()}syncIndicator(){this.getActiveTab()?(this.indicator.style.display="block",this.repositionIndicator()):this.indicator.style.display="none"}show(t){let a=this.tabs.find(i=>i.panel===t);a&&this.setActiveTab(a,{scrollBehavior:"smooth"})}render(){let t=this.localize.dir()==="rtl";return p`
            <div
                part="base"
                class=${v({"tab-group":!0,top:this.placement==="top",bottom:this.placement==="bottom",start:this.placement==="start",end:this.placement==="end","is-rtl":t,"has-scroll-controls":this.hasScrollControls})}
                @click=${this.handleClick}
                @keydown=${this.handleKeyDown}
            >
                <div class="navigation-container" part="navigation">
                    ${this.hasScrollControls?p`
                              <pc-button
                                  part="scroll-button scroll-button-start"
                                  class=${v({"scroll-button":!0,"scroll-button-start":!0,"scroll-button-start-hidden":this.shouldHideScrollStartButton})}
                                  size="small"
                                  variant="plain"
                                  tabindex="-1"
                                  aria-hidden="true"
                                  @click=${this.handleScrollToStart}
                                  exportparts="base:scroll-button__base"
                              >
                                  <pc-icon
                                      library="system"
                                      icon-style="solid"
                                      name=${t?"chevron-right":"chevron-left"}
                                      label=${this.localize.term("scrollToStart")}
                                  ></pc-icon>
                              </pc-button>
                          `:""}

                    <div
                        class="navigation"
                        @scrollend=${this.updateScrollButtons}
                    >
                        <div part="tabs" class="tabs" role="tablist">
                            <div
                                class="indicator"
                                part="active-tab-indicator"
                            ></div>
                            <pc-resize-observer
                                @pc-resize=${this.syncIndicator}
                            >
                                <slot
                                    name="navigation"
                                    @slotchange=${this.syncTabsAndPanels}
                                ></slot>
                            </pc-resize-observer>
                        </div>
                    </div>

                    ${this.hasScrollControls?p`
                              <pc-button
                                  part="scroll-button scroll-button-end"
                                  class=${v({"scroll-button":!0,"scroll-button-end":!0,"scroll-button-end-hidden":this.shouldHideScrollEndButton})}
                                  size="small"
                                  variant="plain"
                                  tabindex="-1"
                                  aria-hidden="true"
                                  @click=${this.handleScrollToEnd}
                                  exportparts="base:scroll-button__base"
                              >
                                  <pc-icon
                                      library="system"
                                      icon-style="solid"
                                      name=${t?"chevron-left":"chevron-right"}
                                      label=${this.localize.term("scrollToEnd")}
                                  ></pc-icon>
                              </pc-button>
                          `:""}
                </div>

                <slot
                    class="body"
                    part="body"
                    @slotchange=${this.syncTabsAndPanels}
                ></slot>
            </div>
        `}};s.css=S,o([h(".tab-group")],s.prototype,"tabGroup",2),o([h(".body")],s.prototype,"body",2),o([h(".navigation")],s.prototype,"navigation",2),o([h(".indicator")],s.prototype,"indicator",2),o([u()],s.prototype,"hasScrollControls",2),o([u()],s.prototype,"shouldHideScrollStartButton",2),o([u()],s.prototype,"shouldHideScrollEndButton",2),o([b()],s.prototype,"placement",2),o([b()],s.prototype,"activation",2),o([b({attribute:"no-scroll-controls",type:Boolean})],s.prototype,"noScrollControls",2),o([b({attribute:"fixed-scroll-controls",type:Boolean})],s.prototype,"fixedScrollControls",2),o([y({passive:!0})],s.prototype,"updateScrollButtons",1),o([f("noScrollControls",{waitUntilFirstUpdate:!0})],s.prototype,"updateScrollControls",1),o([f("placement",{waitUntilFirstUpdate:!0})],s.prototype,"syncIndicator",1),s=o([g("pc-tab-group")],s);export{s as a};
