import{a as g}from"./chunk.OVU4POJI.js";import{a as h,b as u,c,e as d,g as b}from"./chunk.PLBYMK2K.js";import{d as p}from"./chunk.FKNAQN55.js";import{b as s}from"./chunk.E6MOE4FE.js";var m=`:host {
    display: inline-flex;
}

.button-group {
    display: flex;
    position: relative;
    flex-wrap: wrap;
    gap: var(--pc-spacing-xxxs);
    isolation: isolate;
}

@media (hover: hover) {
    .button-group > :hover,
    .button-group::slotted(:hover) {
        z-index: 1;
    }
}

.button-group > :focus,
.button-group::slotted(:focus),
.button-group > [aria-checked="true"],
.button-group::slotted([aria-checked="true"]),
.button-group > [checked],
.button-group::slotted([checked]) {
    z-index: 2 !important;
}

:host([orientation="vertical"]) .button-group {
    flex-direction: column;
}

.button-group.has-outlined {
    gap: 0;
}

.button-group.has-outlined ::slotted(:not(:first-child)) {
    margin-inline-start: calc(-1 * var(--pc-spacing-xxxs));
}
`;function n(l){let r="pc-button";return l.closest(r)??l.querySelector(r)}var e=class extends b{constructor(){super(...arguments);this.hasOutlined=!1;this.disableRole=!1;this.label="";this.orientation="horizontal"}updated(t){super.updated(t),t.has("orientation")&&(this.setAttribute("aria-orientation",this.orientation),this.updateClassNames())}handleFocus(t){n(t.target)?.classList.add("button-focus")}handleBlur(t){n(t.target)?.classList.remove("button-focus")}handleMouseOver(t){n(t.target)?.classList.add("button-hover")}handleMouseOut(t){n(t.target)?.classList.remove("button-hover")}handleSlotChange(){this.updateClassNames()}updateClassNames(){let t=[...this.defaultSlot.assignedElements({flatten:!0})];this.hasOutlined=!1,t.forEach(a=>{let i=t.indexOf(a),o=n(a);o&&(o.variant.split(" ").includes("outlined")&&(this.hasOutlined=!0),o.classList.add("pc-button-group-button"),o.classList.toggle("pc-button-group-horizontal",this.orientation==="horizontal"),o.classList.toggle("pc-button-group-vertical",this.orientation==="vertical"),o.classList.toggle("pc-button-group-button-first",i===0),o.classList.toggle("pc-button-group-button-inner",i>0&&i<t.length-1),o.classList.toggle("pc-button-group-button-last",i===t.length-1))})}render(){return p`
            <slot
                part="base"
                class=${g({"button-group":!0,"has-outlined":this.hasOutlined})}
                role=${this.disableRole?"presentation":"group"}
                aria-label=${this.label}
                aria-orientation=${this.orientation}
                @focusin=${this.handleFocus}
                @focusout=${this.handleBlur}
                @mouseover=${this.handleMouseOver}
                @mouseout=${this.handleMouseOut}
                @slotchange=${this.handleSlotChange}
            ></slot>
        `}};e.css=m,s([d("slot")],e.prototype,"defaultSlot",2),s([c()],e.prototype,"hasOutlined",2),s([c()],e.prototype,"disableRole",2),s([u()],e.prototype,"label",2),s([u({reflect:!0})],e.prototype,"orientation",2),e=s([h("pc-button-group")],e);export{e as a};
