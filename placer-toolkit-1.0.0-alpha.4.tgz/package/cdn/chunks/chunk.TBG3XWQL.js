import{a as t}from"./chunk.3MBXGS36.js";import{a as r,c as i}from"./chunk.ZPHZCJBG.js";var n=class extends i{};r(t);export{n as a};
