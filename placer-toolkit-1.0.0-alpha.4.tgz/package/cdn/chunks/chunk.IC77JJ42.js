import{a as v}from"./chunk.5PPF3EHL.js";import{a as b}from"./chunk.W5PM7F34.js";import{a as h}from"./chunk.RXMQHF36.js";import{a as m}from"./chunk.BSQP4EKW.js";import{a as l}from"./chunk.OVU4POJI.js";import{a as p}from"./chunk.S5DN2ZZE.js";import{a as u}from"./chunk.AGGS6MN5.js";import{a as c}from"./chunk.NOX5TXXZ.js";import{a as n,b as o,e as d}from"./chunk.PLBYMK2K.js";import{d as s}from"./chunk.FKNAQN55.js";import{a}from"./chunk.H2EOXVSZ.js";import{b as r}from"./chunk.E6MOE4FE.js";var f=`:host {
    --width: calc(var(--height) * 1.75);
    --height: var(--pc-form-control-toggle-size);
    --thumb-size: 0.75em;

    display: inline-flex;
    line-height: var(--pc-form-control-value-line-height);
}

label {
    display: flex;
    position: relative;
    align-items: center;
    color: var(--pc-form-control-value-color);
    font: inherit;
    vertical-align: middle;
    cursor: pointer;
}

.switch {
    display: flex;
    position: relative;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    inline-size: var(--width);
    block-size: var(--height);
    background-color: var(--pc-form-control-background-color);
    border: var(--pc-form-control-border-width)
        var(--pc-form-control-border-style) var(--pc-form-control-border-color);
    border-radius: var(--pc-border-radius-pill);
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    label:not(.disabled) .switch:hover {
        background-color: color-mix(
            in oklab,
            var(--pc-form-control-background-color),
            var(--pc-color-mix-hover)
        );
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-border-color),
            var(--pc-color-mix-hover)
        );
    }
}

label:not(.disabled) .switch:active {
    background-color: color-mix(
        in oklab,
        var(--pc-form-control-background-color),
        var(--pc-color-mix-active)
    );
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-border-color),
        var(--pc-color-mix-active)
    );
}

.switch .thumb {
    inline-size: var(--thumb-size);
    block-size: var(--thumb-size);
    aspect-ratio: 1 / 1;
    background-color: var(--pc-form-control-border-color);
    border-radius: var(--pc-border-radius-circle);
    translate: calc((var(--width) - var(--height)) / -2);
    transition:
        all var(--pc-transition-fast) ease-in-out,
        translate var(--pc-transition-medium) cubic-bezier(0.34, 1.35, 0.64, 1);
}

.input {
    position: absolute;
    margin: 0;
    padding: 0;
    opacity: 0;
    pointer-events: none;
}

label:not(.disabled) .input:focus-visible ~ .switch {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.checked:not(.disabled) .switch {
    background-color: var(--pc-form-control-activated-color);
    border-color: var(--pc-form-control-activated-color);
}

@media (hover: hover) {
    .checked:not(.disabled) .switch:hover {
        background-color: color-mix(
            in oklab,
            var(--pc-form-control-activated-color),
            var(--pc-color-mix-hover)
        );
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-activated-color),
            var(--pc-color-mix-hover)
        );
    }
}

.checked:not(.disabled) .switch:active {
    background-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-active)
    );
    border-color: color-mix(
        in oklab,
        var(--pc-form-control-activated-color),
        var(--pc-color-mix-active)
    );
}

.checked .switch .thumb {
    background-color: var(--pc-color-surface-default);
    translate: calc((var(--width) - var(--height)) / 2);
}

label:has(> :disabled) {
    opacity: 0.5;
    cursor: not-allowed;
}

[part~="label"] {
    display: inline-flex;
    line-height: var(--height);
    margin-inline-start: 0.5em;
    user-select: none;
    -webkit-user-select: none;
}

:host([required]) [part~="label"]::after {
    content: var(--pc-form-control-required-content);
    color: var(--pc-form-control-required-content-color);
    margin-inline-start: var(--pc-form-control-required-content-offset);
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}

@media (forced-colors: active) {
    :checked:enabled + .switch:hover .thumb,
    :checked + .switch .thumb {
        background-color: ButtonText;
    }
}
`;var e=class extends c{constructor(){super(...arguments);this.hasSlotController=new u(this,"hint");this.title="";this.name="";this._value=this.getAttribute("value")??null;this.size="medium";this.disabled=!1;this.checked=!1;this.defaultChecked=this.hasAttribute("checked");this.required=!1;this.hint=""}static get validators(){return[...super.validators,p()]}get value(){return this._value??"on"}set value(t){this._value=t}firstUpdated(t){super.firstUpdated(t),this.handleValueOrCheckedChange()}handleClick(){this.hasInteracted=!0,this.checked=!this.checked,this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))})}handleKeyDown(t){t.key==="Enter"&&(t.preventDefault(),this.checked=!this.checked,this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))}willUpdate(t){super.willUpdate(t),t.has("defaultChecked")&&(this.hasInteracted||(this.checked=this.defaultChecked)),(t.has("value")||t.has("checked"))&&this.handleValueOrCheckedChange()}handleValueOrCheckedChange(){this.setValue(this.checked?this.value:null,this._value),this.updateValidity()}handleDefaultCheckedChange(){!this.hasInteracted&&this.checked!==this.defaultChecked&&(this.checked=this.defaultChecked,this.handleValueOrCheckedChange())}handleStateChange(){this.hasUpdated&&(this.input.checked=this.checked),this.customStates.set("checked",this.checked),this.updateValidity()}handleDisabledChange(){this.updateValidity()}click(){this.input.click()}focus(t){this.input.focus(t)}blur(){this.input.blur()}setValue(t,i){if(!this.checked){this.internals.setFormValue(null,null);return}this.internals.setFormValue(t??"on",i)}formResetCallback(){this.checked=this.defaultChecked,super.formResetCallback(),this.handleValueOrCheckedChange()}render(){let t=this.hasSlotController.test("hint"),i=this.hint?!0:!!t;return s`
            <label
                part="base"
                class=${l({checked:this.checked,disabled:this.disabled})}
            >
                <input
                    class="input"
                    type="checkbox"
                    role="switch"
                    title=${this.title}
                    name=${this.name}
                    value=${h(this.value)}
                    .checked=${v(this.checked)}
                    .disabled=${this.disabled}
                    .required=${this.required}
                    aria-checked=${this.checked?"true":"false"}
                    aria-describedby="hint"
                    @click=${this.handleClick}
                    @keydown=${this.handleKeyDown}
                />

                <span part="control" class="switch">
                    <span part="thumb" class="thumb"></span>
                </span>

                <slot class="label" part="label"></slot>
            </label>

            <slot
                part="hint"
                class=${l({"has-hint":i})}
                id="hint"
                name="hint"
                aria-hidden=${i?"false":"true"}
            >
                ${this.hint}
            </slot>
        `}};e.shadowRootOptions={...c.shadowRootOptions,delegatesFocus:!0},e.css=[b,m,f],r([d('input[type="checkbox"]')],e.prototype,"input",2),r([o()],e.prototype,"title",2),r([o()],e.prototype,"name",2),r([o({reflect:!0})],e.prototype,"value",1),r([o({reflect:!0})],e.prototype,"size",2),r([o({type:Boolean})],e.prototype,"disabled",2),r([o({type:Boolean,reflect:!0})],e.prototype,"checked",2),r([o({type:Boolean,attribute:"checked",reflect:!0})],e.prototype,"defaultChecked",2),r([o({type:Boolean,reflect:!0})],e.prototype,"required",2),r([o()],e.prototype,"hint",2),r([a("defaultChecked")],e.prototype,"handleDefaultCheckedChange",1),r([a(["checked"])],e.prototype,"handleStateChange",1),r([a("disabled",{waitUntilFirstUpdate:!0})],e.prototype,"handleDisabledChange",1),e=r([n("pc-switch")],e);export{e as a};
