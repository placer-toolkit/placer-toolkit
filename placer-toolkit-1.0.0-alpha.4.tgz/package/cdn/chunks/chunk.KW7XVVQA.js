import{a as v}from"./chunk.OVU4POJI.js";import{a as u}from"./chunk.V52RFTK3.js";import{a as w}from"./chunk.KZLUYESF.js";import{a as f,b as r,c as m,e as n,g as y}from"./chunk.PLBYMK2K.js";import{d as b}from"./chunk.FKNAQN55.js";import{a as h,c as d}from"./chunk.N5AZOOIZ.js";import{a as g}from"./chunk.TBG3XWQL.js";import{b as o}from"./chunk.E6MOE4FE.js";var L=`:host {
    --error-color: var(--pc-color-danger-on-quiet);
    --success-color: var(--pc-color-success-on-quiet);
    display: inline-block;
}

.copy-button {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    background: transparent;
    border: none;
    border-radius: var(--pc-border-radius-m);
    font-size: inherit;
    color: inherit;
    padding: var(--pc-spacing-s);
    cursor: pointer;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    .copy-button:hover:not([disabled]) {
        background-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-normal),
            var(--pc-color-mix-hover)
        );
    }
}

.copy-button:active:not([disabled]) {
    background-color: color-mix(
        in oklab,
        var(--pc-color-neutral-fill-normal),
        var(--pc-color-mix-active)
    );
}

.copy-button:focus-visible:not([disabled]) {
    background-color: color-mix(
        in oklab,
        var(--pc-color-neutral-fill-normal),
        var(--pc-color-mix-hover)
    );
}

.state-success .copy-button {
    color: var(--success-color);
}

.state-error .copy-button {
    color: var(--error-color);
}

.copy-button:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.copy-button[disabled] {
    opacity: 0.5;
    cursor: not-allowed !important;
}

slot {
    display: inline-flex;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;h("copy.in",{keyframes:[{scale:"0.6",opacity:"0"},{scale:"1.1",opacity:"1"},{scale:"0.95",opacity:"1"},{scale:"1",opacity:"1"}],options:{duration:350,easing:"cubic-bezier(0.34, 1.56, 0.64, 1)"}});h("copy.out",{keyframes:[{scale:"1",opacity:"1"},{scale:"0.85",opacity:"0"}],options:{duration:200,easing:"cubic-bezier(0.75, 0, 0.9, 0.05)"}});var t=class extends y{constructor(){super(...arguments);this.localize=new g(this);this.isCopying=!1;this.status="rest";this.value="";this.from="";this.disabled=!1;this.copyLabel="";this.successLabel="";this.errorLabel="";this.feedbackDuration=1e3;this.tooltipPlacement="top"}async handleCopy(){if(this.disabled||this.isCopying)return;this.isCopying=!0;let e=this.value;if(this.from){let c=this.getRootNode(),l=this.from.includes("."),p=this.from.includes("[")&&this.from.includes("]"),a=this.from,i="";l?[a,i]=this.from.trim().split("."):p&&([a,i]=this.from.trim().replace(/\]$/,"").split("["));let s="getElementById"in c?c.getElementById(a):null;s?p?e=s.getAttribute(i)||"":l?e=s[i]||"":e=s.textContent||"":(this.showStatus("error"),this.dispatchEvent(new u))}if(!e)this.showStatus("error"),this.dispatchEvent(new u);else try{await navigator.clipboard.writeText(e),this.showStatus("success"),this.dispatchEvent(new w({value:e}))}catch{this.showStatus("error"),this.dispatchEvent(new u)}}async showStatus(e){let c=this.copyLabel||this.localize.term("copy"),l=this.successLabel||this.localize.term("copied"),p=this.errorLabel||this.localize.term("error"),a=e==="success"?this.successIcon:this.errorIcon,i=d(this,"copy.in",{dir:"ltr"}),s=d(this,"copy.out",{dir:"ltr"});this.tooltip.content=e==="success"?l:p,await this.copyIcon.animate(s.keyframes,s.options).finished,this.copyIcon.hidden=!0,this.status=e,a.hidden=!1,await a.animate(i.keyframes,i.options).finished,setTimeout(async()=>{await a.animate(s.keyframes,s.options).finished,a.hidden=!0,this.status="rest",this.copyIcon.hidden=!1,await this.copyIcon.animate(i.keyframes,i.options).finished,this.tooltip.content=c,this.isCopying=!1},this.feedbackDuration)}get currentStatus(){let e=this.copyLabel||this.localize.term("copy"),c=this.successLabel||this.localize.term("copied"),l=this.errorLabel||this.localize.term("error");switch(this.status){case"success":return c;case"error":return l;default:return e}}render(){let e=this.copyLabel||this.localize.term("copy");return b`
            <pc-tooltip
                class=${v({"copy-button-container":!0,"state-success":this.status==="success","state-error":this.status==="error"})}
                content=${e}
                placement=${this.tooltipPlacement}
                ?disabled=${this.disabled}
                exportparts="
                    base:tooltip-base,
                    base-popup:tooltip-base-popup,
                    base-arrow:tooltip-base-arrow,
                    body:tooltip-body
                "
            >
                <button
                    class="copy-button"
                    type="button"
                    part="button"
                    ?disabled=${this.disabled}
                    aria-label=${this.currentStatus}
                    @click=${this.handleCopy}
                >
                    <slot part="copy-icon" name="copy-icon">
                        <pc-icon
                            library="system"
                            icon-style="regular"
                            name="copy"
                        ></pc-icon>
                    </slot>
                    <slot part="success-icon" name="success-icon" hidden>
                        <pc-icon
                            library="system"
                            icon-style="solid"
                            name="check"
                        ></pc-icon>
                    </slot>
                    <slot part="error-icon" name="error-icon" hidden>
                        <pc-icon
                            library="system"
                            icon-style="solid"
                            name="xmark"
                        ></pc-icon>
                    </slot>
                </button>
            </pc-tooltip>
        `}};t.css=L,o([n('slot[name="copy-icon"]')],t.prototype,"copyIcon",2),o([n('slot[name="success-icon"]')],t.prototype,"successIcon",2),o([n('slot[name="error-icon"]')],t.prototype,"errorIcon",2),o([n("pc-tooltip")],t.prototype,"tooltip",2),o([m()],t.prototype,"isCopying",2),o([m()],t.prototype,"status",2),o([r()],t.prototype,"value",2),o([r()],t.prototype,"from",2),o([r({type:Boolean})],t.prototype,"disabled",2),o([r({attribute:"copy-label"})],t.prototype,"copyLabel",2),o([r({attribute:"success-label"})],t.prototype,"successLabel",2),o([r({attribute:"error-label"})],t.prototype,"errorLabel",2),o([r({attribute:"feedback-duration",type:Number})],t.prototype,"feedbackDuration",2),o([r({attribute:"tooltip-placement"})],t.prototype,"tooltipPlacement",2),t=o([f("pc-copy-button")],t);export{t as a};
