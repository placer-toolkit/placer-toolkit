import{a as l,b as c,c as a}from"./chunk.SMFJUIOR.js";import{e as i}from"./chunk.FKNAQN55.js";var u="important",d=" !"+u,h=c(class extends a{constructor(s){if(super(s),s.type!==l.ATTRIBUTE||s.name!=="style"||s.strings?.length>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(s){return Object.keys(s).reduce(((r,t)=>{let e=s[t];return e==null?r:r+`${t=t.includes("-")?t:t.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,"-$&").toLowerCase()}:${e};`}),"")}update(s,[r]){let{style:t}=s.element;if(this.ft===void 0)return this.ft=new Set(Object.keys(r)),this.render(r);for(let e of this.ft)r[e]==null&&(this.ft.delete(e),e.includes("-")?t.removeProperty(e):t[e]=null);for(let e in r){let n=r[e];if(n!=null){this.ft.add(e);let o=typeof n=="string"&&n.endsWith(d);e.includes("-")||o?t.setProperty(e,o?n.slice(0,-11):n,o?u:""):t[e]=n}}return i}});export{h as a};
/*! Bundled license information:

lit-html/directives/style-map.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
