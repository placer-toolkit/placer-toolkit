import{a as y}from"./chunk.5PPF3EHL.js";import{a as r}from"./chunk.RXMQHF36.js";import{a as x}from"./chunk.W5PM7F34.js";import{a as w}from"./chunk.BSQP4EKW.js";import{a as $}from"./chunk.YRR4IRLY.js";import{a as b}from"./chunk.OVU4POJI.js";import{a as g}from"./chunk.S5DN2ZZE.js";import{a as v}from"./chunk.AGGS6MN5.js";import{a as u}from"./chunk.NOX5TXXZ.js";import{a as h,b as o,c as d,e as f}from"./chunk.PLBYMK2K.js";import{d as l}from"./chunk.FKNAQN55.js";import{a as m}from"./chunk.H2EOXVSZ.js";import{a as C}from"./chunk.V65QAGBQ.js";import{a as k}from"./chunk.TBG3XWQL.js";import{b as t}from"./chunk.E6MOE4FE.js";var E=`:host {
    border-width: 0;
}

.text-field {
    display: flex;
    position: relative;
    align-items: stretch;
    justify-content: flex-start;
    flex: auto;
    inline-size: 100%;
    block-size: var(--pc-form-control-height);
    background-color: var(--pc-form-control-background-color);
    color: var(--pc-form-control-value-color);
    border: var(--pc-form-control-border-width)
        var(--pc-form-control-border-style) var(--pc-form-control-border-color);
    border-radius: var(--pc-form-control-border-radius);
    padding: 0 var(--pc-form-control-padding-inline);
    font-family: inherit;
    font-weight: var(--pc-form-control-value-font-weight);
    line-height: var(--pc-form-control-value-line-height);
    vertical-align: middle;
    overflow: hidden;
    cursor: text;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    .text-field:not(:has(:disabled), :focus-within):hover {
        border-color: color-mix(
            in oklab,
            var(--pc-form-control-border-color),
            var(--pc-color-mix-hover)
        );
    }
}

.text-field:focus-within {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.text-field:has(:disabled) {
    opacity: 0.5;
    cursor: not-allowed;
}

:host([filled]) .text-field {
    background-color: var(--pc-color-neutral-fill-quiet);
    border-color: var(--pc-color-neutral-fill-quiet);
}

@media (hover: hover) {
    :host([filled]) .text-field:not(:has(:disabled), :focus-within):hover {
        background-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-quiet),
            var(--pc-color-mix-hover)
        );
        border-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-quiet),
            var(--pc-color-mix-hover)
        );
    }
}

:host([pill]) .text-field {
    border-radius: var(--pc-border-radius-pill) !important;
}

.text-field input {
    margin: 0;
    padding: 0;
    block-size: 100%;
    border: none;
    outline: none;
    font: inherit;
    cursor: inherit;
    -webkit-appearance: none;
}

.text-field input:-webkit-autofill,
.text-field input:-webkit-autofill:hover,
.text-field input:-webkit-autofill:focus,
.text-field input:-webkit-autofill:active {
    background-color: transparent;
    -webkit-background-clip: text;
    -webkit-text-fill-color: inherit;
}

.text-field:has(:autofill),
.text-field:has(:-webkit-autofill) {
    background-color: var(--pc-color-primary-fill-quiet) !important;
}

input {
    background-color: transparent;
    color: inherit;
    min-inline-size: 0;
    block-size: calc(var(--pc-form-control-height) - var(--border-width) * 1.5);
    padding-block: 0;
    flex: 1 1 auto;
}

input:autofill,
input:autofill:hover,
input:autofill:focus,
input:autofill:active {
    box-shadow: none;
    caret-color: var(--pc-form-control-value-color);
}

input::placeholder {
    color: var(--pc-form-control-placeholder-color);
    user-select: none;
    -webkit-user-select: none;
}

input::-webkit-search-decoration,
input::-webkit-search-cancel-button,
input::-webkit-search-results-button,
input::-webkit-search-results-decoration {
    -webkit-appearance: none;
}

input:focus {
    outline: none;
}

.prefix,
.suffix {
    display: inline-flex;
    align-items: center;
    flex: 0 0 auto;
    cursor: default;
}

.prefix::slotted(pc-icon),
.suffix::slotted(pc-icon) {
    color: var(--pc-color-neutral-on-quiet);
}

.prefix::slotted(*) {
    margin-inline-end: var(--pc-form-control-padding-inline);
}

.suffix::slotted(*) {
    margin-inline-start: var(--pc-form-control-padding-inline);
}

.clear,
.password-toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: inherit;
    color: var(--pc-color-neutral-on-quiet);
    border: none;
    background: none;
    padding: 0;
    cursor: pointer;
    transition: color var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    .clear:hover,
    .password-toggle:hover {
        color: color-mix(
            in oklab,
            var(--pc-color-neutral-on-quiet),
            var(--pc-color-mix-hover)
        );
    }
}

.clear:active,
.password-toggle:active {
    color: color-mix(
        in oklab,
        var(--pc-color-neutral-on-quiet),
        var(--pc-color-mix-active)
    );
}

.clear:focus,
.password-toggle:focus {
    outline: none;
}

::-ms-reveal {
    display: none;
}

:host([no-spin-buttons]) input[type="number"] {
    -moz-appearance: textfield;
}

:host([no-spin-buttons]) input[type="number"]::-webkit-outer-spin-button,
:host([no-spin-buttons]) input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    display: none;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var e=class extends u{constructor(){super(...arguments);this.assumeInteractionOn=["input","blur"];this.hasSlotController=new v(this,"label","hint");this.localize=new k(this);this.title="";this.type="text";this.name="";this._value=null;this.defaultValue=this.getAttribute("value")||null;this.size="medium";this.filled=!1;this.pill=!1;this.label="";this.hint="";this.clearable=!1;this.disabled=!1;this.placeholder="";this.readonly=!1;this.passwordToggle=!1;this.passwordVisible=!1;this.noSpinButtons=!1;this.required=!1;this.autocapitalize="none";this.autocorrect=!1;this.enterkeyhint="enter";this.spellcheck=!0;this.inputmode="text"}static get validators(){return[...super.validators,g()]}get value(){return this.valueHasChanged?this._value:this._value??this.defaultValue}set value(i){this._value!==i&&(this.valueHasChanged=!0,this._value=i)}handleChange(i){this.value=this.input.value,this.relayNativeEvent(i,{bubbles:!0,composed:!0})}handleInput(){this.value=this.input.value}handleClearClick(i){i.preventDefault(),this.value!==""&&(this.value="",this.updateComplete.then(()=>{this.dispatchEvent(new $),this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})),this.input.focus()}handleKeyDown(i){C(i,this)}handlePasswordToggle(){this.passwordVisible=!this.passwordVisible}handleStepChange(){this.input.step=String(this.step),this.updateValidity()}focus(i){this.input.focus(i)}blur(){this.input.blur()}select(){this.input.select()}setSelectionRange(i,a,n="none"){this.input.setSelectionRange(i,a,n)}setRangeText(i,a,n,s="preserve"){let p=a??this.input.selectionStart,c=n??this.input.selectionEnd;this.input.setRangeText(i,p,c,s),this.value!==this.input.value&&(this.value=this.input.value)}showPicker(){"showPicker"in HTMLInputElement.prototype&&this.input.showPicker()}stepUp(){this.input.stepUp(),this.value!==this.input.value&&(this.value=this.input.value)}stepDown(){this.input.stepDown(),this.value!==this.input.value&&(this.value=this.input.value)}formResetCallback(){this.value=this.defaultValue,super.formResetCallback()}render(){let i=this.hasSlotController.test("label"),a=this.hasSlotController.test("hint"),n=this.label?!0:!!i,s=this.hint?!0:!!a,c=this.clearable&&!this.disabled&&!this.readonly&&(typeof this.value=="number"||this.value&&this.value.length>0);return l`
            <div
                part="form-control"
                class="form-control form-control-has-label"
            >
                <label
                    part="label"
                    class="label"
                    for="input"
                    aria-hidden=${n?"false":"true"}
                >
                    <slot name="label">${this.label}</slot>
                </label>

                <div part="input" class="text-field">
                    <slot class="prefix" part="prefix" name="prefix"></slot>

                    <input
                        part="base"
                        class="control"
                        id="input"
                        type=${this.type==="password"&&this.passwordVisible?"text":this.type}
                        title=${this.title}
                        name=${r(this.name)}
                        ?disabled=${this.disabled}
                        ?readonly=${this.readonly}
                        ?required=${this.required}
                        placeholder=${r(this.placeholder)}
                        min=${r(this.min)}
                        minlength=${r(this.minlength)}
                        max=${r(this.max)}
                        maxlength=${r(this.maxlength)}
                        step=${r(this.step)}
                        .value=${y(this.value)}
                        autocapitalize=${r(this.autocapitalize)}
                        autocomplete=${r(this.autocomplete)}
                        autocorrect=${r(this.autocorrect)}
                        ?autofocus=${this.autofocus}
                        spellcheck=${this.spellcheck}
                        pattern=${r(this.pattern)}
                        enterkeyhint=${r(this.enterkeyhint)}
                        inputmode=${r(this.inputmode)}
                        aria-describedby="hint"
                        @change=${this.handleChange}
                        @input=${this.handleInput}
                        @keydown=${this.handleKeyDown}
                    />

                    ${c?l`
                              <button
                                  class="clear"
                                  part="clear-button"
                                  type="button"
                                  aria-label=${this.localize.term("clearEntry")}
                                  @click=${this.handleClearClick}
                                  tabindex="-1"
                              >
                                  <slot name="clear-icon">
                                      <pc-icon
                                          library="system"
                                          icon-style="regular"
                                          name="circle-xmark"
                                      ></pc-icon>
                                  </slot>
                              </button>
                          `:""}
                    ${this.passwordToggle&&!this.disabled?l`
                              <button
                                  class="password-toggle"
                                  part="password-toggle-button"
                                  type="button"
                                  aria-label=${this.localize.term(this.passwordVisible?"hidePassword":"showPassword")}
                                  @click=${this.handlePasswordToggle}
                                  tabindex="-1"
                              >
                                  ${this.passwordVisible?l`
                                            <slot name="hide-password-icon">
                                                <pc-icon
                                                    library="system"
                                                    icon-style="regular"
                                                    name="eye"
                                                ></pc-icon>
                                            </slot>
                                        `:l`
                                            <slot name="show-password-icon">
                                                <pc-icon
                                                    library="system"
                                                    icon-style="regular"
                                                    name="eye-slash"
                                                ></pc-icon>
                                            </slot>
                                        `}
                              </button>
                          `:""}

                    <slot class="suffix" part="suffix" name="suffix"></slot>
                </div>

                <slot
                    class=${b({"has-hint":s})}
                    part="hint"
                    id="hint"
                    name="hint"
                    aria-hidden=${s?"false":"true"}
                >
                    ${this.hint}
                </slot>
            </div>
        `}};e.css=[x,w,E],e.shadowRootOptions={...u.shadowRootOptions,delegatesFocus:!0},t([f(".control")],e.prototype,"input",2),t([o()],e.prototype,"title",2),t([o({reflect:!0})],e.prototype,"type",2),t([o()],e.prototype,"name",2),t([d()],e.prototype,"value",1),t([o({attribute:"value",reflect:!0})],e.prototype,"defaultValue",2),t([o({reflect:!0})],e.prototype,"size",2),t([o({type:Boolean,reflect:!0})],e.prototype,"filled",2),t([o({type:Boolean,reflect:!0})],e.prototype,"pill",2),t([o()],e.prototype,"label",2),t([o()],e.prototype,"hint",2),t([o({type:Boolean})],e.prototype,"clearable",2),t([o({type:Boolean})],e.prototype,"disabled",2),t([o()],e.prototype,"placeholder",2),t([o({type:Boolean,reflect:!0})],e.prototype,"readonly",2),t([o({attribute:"password-toggle",type:Boolean})],e.prototype,"passwordToggle",2),t([o({attribute:"password-visible",type:Boolean})],e.prototype,"passwordVisible",2),t([o({attribute:"no-spin-buttons",type:Boolean})],e.prototype,"noSpinButtons",2),t([o({type:Boolean,reflect:!0})],e.prototype,"required",2),t([o()],e.prototype,"pattern",2),t([o()],e.prototype,"minlength",2),t([o()],e.prototype,"maxlength",2),t([o()],e.prototype,"min",2),t([o()],e.prototype,"max",2),t([o()],e.prototype,"step",2),t([o()],e.prototype,"autocapitalize",2),t([o({type:Boolean,converter:{fromAttribute:i=>!(!i||i==="off"),toAttribute:i=>i?"on":"off"}})],e.prototype,"autocorrect",2),t([o()],e.prototype,"autocomplete",2),t([o({type:Boolean})],e.prototype,"autofocus",2),t([o()],e.prototype,"enterkeyhint",2),t([o({type:Boolean,converter:{fromAttribute:i=>!(!i||i==="off"),toAttribute:i=>i?"on":"off"}})],e.prototype,"spellcheck",2),t([o()],e.prototype,"inputmode",2),t([m("step",{waitUntilFirstUpdate:!0})],e.prototype,"handleStepChange",1),e=t([h("pc-input")],e);export{e as a};
