var e=class extends Event{constructor(){super("pc-reposition",{bubbles:!0,cancelable:!1,composed:!0})}};export{e as a};
