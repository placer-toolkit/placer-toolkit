import{a as c,b as a,c as d,d as h,e as p,g as u}from"./chunk.PLBYMK2K.js";import{d as l}from"./chunk.FKNAQN55.js";import{a as w}from"./chunk.TBG3XWQL.js";import{b as i}from"./chunk.E6MOE4FE.js";var v=`:host {
    --shadow-color: var(--pc-color-surface-default);
    --shadow-size: 2rem;

    /* These custom properties shouldn\u2019t be accessed out of this scope. */
    --start-shadow-opacity: 0;
    --end-shadow-opacity: 0;

    display: block;
    position: relative;
    max-inline-size: 100%;
    isolation: isolate;
}

:host([orientation="vertical"]) {
    display: flex;
    flex-direction: column;
    block-size: 100%;
}

#content {
    border-radius: inherit;
    scroll-behavior: smooth;
    scrollbar-width: thin;
    scrollbar-color: var(--pc-color-neutral-border-normal) transparent;
    -webkit-text-size-adjust: 100%;
    z-index: 1;
}

#content:focus {
    outline: none;
}

#content:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

:host([no-scrollbar]) #content {
    scrollbar-width: none;
}

:host([orientation="horizontal"]) #content {
    overflow-x: auto;
    overflow-y: hidden;
}

:host([orientation="vertical"]) #content {
    flex: 1 1 auto;
    min-block-size: 0;
    overflow-x: hidden;
    overflow-y: auto;
}

:host([orientation="horizontal"]) {
    #start-shadow,
    #end-shadow {
        position: absolute;
        inset-block: 0;
        inline-size: var(--shadow-size);
        pointer-events: none;
        z-index: 2;
    }

    #start-shadow {
        opacity: var(--start-shadow-opacity);

        &:dir(ltr) {
            inset-inline-start: 0;
            background-image: linear-gradient(
                to right,
                var(--shadow-color),
                transparent 100%
            );
        }

        &:dir(rtl) {
            inset-inline-end: 0;
            background-image: linear-gradient(
                to left,
                var(--shadow-color),
                transparent 100%
            );
        }
    }

    #end-shadow {
        opacity: var(--end-shadow-opacity);

        &:dir(ltr) {
            inset-inline-end: 0;
            background-image: linear-gradient(
                to left,
                var(--shadow-color),
                transparent 100%
            );
        }

        &:dir(rtl) {
            inset-inline-start: 0;
            background-image: linear-gradient(
                to right,
                var(--shadow-color),
                transparent 100%
            );
        }
    }
}

:host([orientation="vertical"]) {
    #start-shadow,
    #end-shadow {
        position: absolute;
        inset-inline: 0;
        block-size: var(--shadow-size);
        pointer-events: none;
        z-index: 2;
    }

    #start-shadow {
        inset-block-start: 0;
        background-image: linear-gradient(
            to bottom,
            var(--shadow-color),
            transparent 100%
        );
        opacity: var(--start-shadow-opacity);
    }

    #end-shadow {
        inset-block-end: 0;
        background-image: linear-gradient(
            to top,
            var(--shadow-color),
            transparent 100%
        );
        opacity: var(--end-shadow-opacity);
    }
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var t=class extends u{constructor(){super(...arguments);this.localize=new w(this);this.resizeObserver=new ResizeObserver(()=>this.updateScroll());this.canScroll=!1;this.orientation="horizontal";this.noScrollbar=!1;this.noShadow=!1}connectedCallback(){super.connectedCallback(),this.resizeObserver.observe(this)}disconnectedCallback(){super.disconnectedCallback(),this.resizeObserver.disconnect()}handleKeyDown(e){e.key==="Home"&&(e.preventDefault(),this.content.scrollTo({left:this.orientation==="horizontal"?0:void 0,top:this.orientation==="vertical"?0:void 0})),e.key==="End"&&(e.preventDefault(),this.content.scrollTo({left:this.orientation==="horizontal"?this.content.scrollWidth:void 0,top:this.orientation==="vertical"?this.content.scrollHeight:void 0}))}handleSlotChange(){this.updateScroll()}updateScroll(){if(this.orientation==="horizontal"){let e=Math.ceil(this.content.clientWidth),n=Math.abs(Math.ceil(this.content.scrollLeft)),o=Math.ceil(this.content.scrollWidth)-e;this.canScroll=o>0;let r=Math.min(1,n/(o*.05)),s=Math.min(1,(o-n)/(o*.05));this.style.setProperty("--start-shadow-opacity",String(r||0)),this.style.setProperty("--end-shadow-opacity",String(s||0))}else{let e=Math.ceil(this.content.clientHeight),n=Math.abs(Math.ceil(this.content.scrollTop)),o=Math.ceil(this.content.scrollHeight)-e;this.canScroll=o>0;let r=Math.min(1,n/(o*.05)),s=Math.min(1,(o-n)/(o*.05));this.style.setProperty("--start-shadow-opacity",String(r||0)),this.style.setProperty("--end-shadow-opacity",String(s||0))}}render(){return l`
            ${this.noShadow?"":l`
                      <div
                          id="start-shadow"
                          part="start-shadow"
                          aria-hidden="true"
                      ></div>
                      <div
                          id="end-shadow"
                          part="end-shadow"
                          aria-hidden="true"
                      ></div>
                  `}

            <div
                id="content"
                part="content"
                role="region"
                aria-label=${this.localize.term("scrollableRegion")}
                aria-orientation=${this.orientation}
                tabindex=${this.canScroll?"0":"-1"}
                @keydown=${this.handleKeyDown}
                @scroll=${this.updateScroll}
            >
                <slot @slotchange=${this.handleSlotChange}></slot>
            </div>
        `}};t.css=v,i([p("#content")],t.prototype,"content",2),i([d()],t.prototype,"canScroll",2),i([a({reflect:!0})],t.prototype,"orientation",2),i([a({attribute:"no-scrollbar",type:Boolean,reflect:!0})],t.prototype,"noScrollbar",2),i([a({attribute:"no-shadow",type:Boolean,reflect:!0})],t.prototype,"noShadow",2),i([h({passive:!0})],t.prototype,"updateScroll",1),t=i([c("pc-scroller")],t);export{t as a};
