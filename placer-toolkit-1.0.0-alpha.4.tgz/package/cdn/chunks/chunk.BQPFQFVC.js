var e=class extends Event{constructor(n){super("pc-submenu-opening",{bubbles:!0,cancelable:!1,composed:!0}),this.detail=n}};export{e as a};
