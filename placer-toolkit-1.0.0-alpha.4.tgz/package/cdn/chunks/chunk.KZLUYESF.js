var e=class extends Event{constructor(r){super("pc-copy",{bubbles:!0,cancelable:!1,composed:!0}),this.detail=r}};export{e as a};
