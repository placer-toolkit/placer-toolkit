import{a as v}from"./chunk.BQPFQFVC.js";import{a as r,d as l}from"./chunk.RZZMGXAZ.js";import{a as b}from"./chunk.AGGS6MN5.js";import{a as m,b as a,c as d,e as h,g as p}from"./chunk.PLBYMK2K.js";import{d as n}from"./chunk.FKNAQN55.js";import{a as u,c}from"./chunk.N5AZOOIZ.js";import{a as f}from"./chunk.TBG3XWQL.js";import{b as i}from"./chunk.E6MOE4FE.js";var g=`:host {
    display: flex;
    position: relative;
    align-items: center;
    padding-block: 0.5em;
    padding-inline: 1em;
    color: var(--pc-color-text-normal);
    border-radius: var(--pc-border-radius-m);
    line-height: var(--pc-line-height-denser);
    isolation: isolate;
    cursor: pointer;
    transition: all var(--pc-transition-fast) ease-in-out;
}

@media (hover: hover) {
    :host(:hover:not(:state(disabled))) {
        background-color: color-mix(
            in oklab,
            var(--pc-color-neutral-fill-normal),
            var(--pc-color-mix-hover)
        );
        color: color-mix(
            in oklab,
            var(--pc-color-neutral-on-normal),
            var(--pc-color-mix-hover)
        );
    }
}

:host(:active:not(:state(disabled), :state(has-submenu))) {
    background-color: color-mix(
        in oklab,
        var(--pc-color-neutral-fill-normal),
        var(--pc-color-mix-active)
    );
    color: color-mix(
        in oklab,
        var(--pc-color-neutral-on-normal),
        var(--pc-color-mix-active)
    );
}

:host(:focus-visible) {
    background-color: var(--pc-color-neutral-fill-normal);
    outline: var(--pc-focus-ring);
    z-index: 1;
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

:host(:state(disabled)) {
    opacity: 0.5;
    cursor: not-allowed;
}

:host([appearance="danger"]),
:host([appearance="danger"]) #details {
    color: var(--pc-color-danger-on-quiet);
}

@media (hover: hover) {
    :host([appearance="danger"]:hover:not(:state(disabled))) {
        background-color: color-mix(
            in oklab,
            var(--pc-color-danger-fill-normal),
            var(--pc-color-mix-hover)
        );
        color: color-mix(
            in oklab,
            var(--pc-color-danger-on-normal),
            var(--pc-color-mix-hover)
        );
    }
}

:host([appearance="danger"]:active:not(:state(disabled), :state(has-submenu))) {
    background-color: color-mix(
        in oklab,
        var(--pc-color-danger-fill-normal),
        var(--pc-color-mix-active)
    );
    color: color-mix(
        in oklab,
        var(--pc-color-danger-on-normal),
        var(--pc-color-mix-active)
    );
}

:host([appearance="danger"]:focus-visible) {
    background-color: var(--pc-color-danger-fill-normal);
    color: var(--pc-color-danger-on-normal);
}

:host([checkbox-adjacent]) {
    padding-inline-start: 2em;
}

:host([submenu-adjacent]:not(:state(has-submenu))) #details {
    padding-inline-end: 0;
}

:host(:state(has-submenu)[submenu-adjacent]) #details {
    padding-inline-end: 1.75em;
}

#check {
    margin-inline-start: -1.5em;
    margin-inline-end: 0.5em;
    font-size: var(--pc-font-size-smaller);
    visibility: hidden;
}

:host(:state(checked)) #check {
    visibility: visible;
}

#icon ::slotted(*) {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    margin-inline-end: 0.75em !important;
    font-size: var(--pc-font-size-smaller);
}

#label {
    flex: 1 1 auto;
    min-inline-size: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
}

#details {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    flex: 0 0 auto;
    color: var(--pc-color-text-quiet);
    font-size: var(--pc-font-size-smaller) !important;
}

#details ::slotted(*) {
    margin-inline-start: 2em !important;
}

#submenu-indicator {
    position: absolute;
    inset-inline-end: 1em;
    color: var(--pc-color-neutral-on-quiet);
    font-size: var(--pc-font-size-smaller);
}

:host(:dir(rtl)) #submenu-indicator {
    transform: scaleX(-1);
}

#submenu {
    display: flex;
    flex-direction: column;
    position: absolute;
    top: 0;
    left: 0;
    margin: 0;
    padding: 0.25em;
    inline-size: max-content;
    background-color: var(--pc-color-surface-raised);
    color: var(--pc-color-text-normal);
    border: var(--pc-border-width-s) var(--pc-border-style)
        var(--pc-color-surface-border);
    border-radius: calc(var(--pc-border-radius-m) + 0.25em);
    text-align: start;
    user-select: none;
    box-shadow: var(--pc-shadow-m);
    z-index: 10;
}

#submenu[popover] {
    inset: auto;
    margin: 0;
    padding: 0.25em;
    border-radius: calc(var(--pc-border-radius-m) + 0.25em);
    overflow: visible;
}

#submenu[data-placement^="top"] {
    transform-origin: bottom;
}

#submenu[data-placement^="bottom"] {
    transform-origin: top;
}

#submenu[data-placement^="left"] {
    transform-origin: right;
}

#submenu[data-placement^="right"] {
    transform-origin: left;
}

#submenu[data-placement="left-start"] {
    transform-origin: right top;
}

#submenu[data-placement="left-end"] {
    transform-origin: right bottom;
}

#submenu[data-placement="right-start"] {
    transform-origin: left top;
}

#submenu[data-placement="right-end"] {
    transform-origin: left bottom;
}

#submenu::before {
    content: "";
    display: none;
    position: fixed;
    inset: 0;
    background-color: transparent;
    clip-path: polygon(
        var(--safe-triangle-cursor-x, 0) var(--safe-triangle-cursor-y, 0),
        var(--safe-triangle-submenu-start-x, 0)
            var(--safe-triangle-submenu-start-y, 0),
        var(--safe-triangle-submenu-end-x, 0)
            var(--safe-triangle-submenu-end-y, 0)
    );
    pointer-events: auto;
    z-index: 9;
}

#submenu[data-visible]::before {
    display: block;
}

::slotted(pc-dropdown-item) {
    font-size: inherit;
}

::slotted(pc-divider) {
    --spacing: 0.25em;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;u("submenu.show",{keyframes:[{opacity:0,scale:.9},{opacity:1,scale:1}],options:{duration:300,easing:"cubic-bezier(0.2, 0.8, 0.2, 1)",fill:"both"}});u("submenu.hide",{keyframes:[{opacity:1,scale:1},{opacity:0,scale:.9}],options:{duration:200,easing:"cubic-bezier(0.4, 0.2, 0.6, 0.1)",fill:"both"}});var e=class extends p{constructor(){super(...arguments);this.hasSlotController=new b(this,"[default]","prefix","suffix");this.localize=new f(this);this.hasSubmenu=!1;this.active=!1;this.appearance="default";this.size="medium";this.checkboxAdjacent=!1;this.submenuAdjacent=!1;this.type="normal";this.checked=!1;this.disabled=!1;this.submenuOpen=!1;this.handleSlotChange=()=>{this.hasSubmenu=this.hasSlotController.test("submenu"),this.updateHasSubmenuState(),this.hasSubmenu?(this.setAttribute("aria-haspopup","menu"),this.setAttribute("aria-expanded",this.submenuOpen?"true":"false")):(this.removeAttribute("aria-haspopup"),this.removeAttribute("aria-expanded"))}}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseenter",this.handleMouseEnter.bind(this)),this.shadowRoot.addEventListener("slotchange",this.handleSlotChange)}disconnectedCallback(){super.disconnectedCallback(),this.closeSubmenu(),this.removeEventListener("mouseenter",this.handleMouseEnter),this.shadowRoot.removeEventListener("slotchange",this.handleSlotChange)}firstUpdated(){this.setAttribute("tabindex","-1"),this.hasSubmenu=this.hasSlotController.test("submenu"),this.updateHasSubmenuState()}updated(t){t.has("active")&&(this.setAttribute("tabindex",this.active?"0":"-1"),this.customStates.set("active",this.active)),t.has("checked")&&(this.type==="checkbox"?this.setAttribute("aria-checked",this.checked?"true":"false"):this.removeAttribute("aria-checked"),this.customStates.set("checked",this.checked)),t.has("disabled")&&(this.setAttribute("aria-disabled",this.disabled?"true":"false"),this.customStates.set("disabled",this.disabled)),t.has("type")&&(this.type==="checkbox"?(this.setAttribute("role","menuitemcheckbox"),this.setAttribute("aria-checked",this.checked?"true":"false")):(this.setAttribute("role","menuitem"),this.removeAttribute("aria-checked"))),t.has("submenuOpen")&&(this.customStates.set("submenu-open",this.submenuOpen),this.submenuOpen?this.openSubmenu():this.closeSubmenu())}updateHasSubmenuState(){this.customStates.set("has-submenu",this.hasSubmenu)}async openSubmenu(){if(!this.hasSubmenu||!this.submenuElement)return;this.notifyParentOfOpening(),this.submenuElement.showPopover(),this.submenuElement.hidden=!1,this.submenuElement.setAttribute("data-visible",""),this.submenuOpen=!0,this.setAttribute("aria-expanded","true");let{keyframes:t,options:o}=c(this,"submenu.show",{dir:this.localize.dir()});await r(this.submenuElement,t,o),await l(this),setTimeout(()=>{let s=this.getSubmenuItems();s.length>0&&(s.forEach((x,y)=>x.active=y===0),s[0].focus({preventScroll:!0}))},0)}notifyParentOfOpening(){this.dispatchEvent(new v({item:this}));let t=this.parentElement;t&&[...t.children].filter(s=>s!==this&&s.localName==="pc-dropdown-item"&&s.getAttribute("slot")===this.getAttribute("slot")&&s.submenuOpen).forEach(s=>{s.submenuOpen=!1})}async closeSubmenu(){if(!(!this.hasSubmenu||!this.submenuElement)&&(this.submenuOpen=!1,this.setAttribute("aria-expanded","false"),!this.submenuElement.hidden)){let{keyframes:t,options:o}=c(this,"submenu.hide",{dir:this.localize.dir()});await r(this.submenuElement,t,o),await l(this),this.submenuElement.hidden=!0,this.submenuElement.removeAttribute("data-visible"),this.submenuElement.hidePopover()}}getSubmenuItems(){return[...this.children].filter(t=>t.localName==="pc-dropdown-item"&&t.getAttribute("slot")==="submenu"&&!t.hasAttribute("disabled"))}handleMouseEnter(){this.hasSubmenu&&!this.disabled&&(this.notifyParentOfOpening(),this.submenuOpen=!0)}render(){return n`
            ${this.type==="checkbox"?n`
                      <pc-icon
                          library="system"
                          icon-style="solid"
                          name="check"
                          part="checkmark"
                          id="check"
                          exportparts="svg:checkmark-svg"
                      ></pc-icon>
                  `:""}

            <span id="icon" part="icon">
                <slot name="icon"></slot>
            </span>

            <span id="label" part="label">
                <slot></slot>
            </span>

            <span id="details" part="details">
                <slot name="details"></slot>
            </span>

            ${this.hasSubmenu?n`
                      <pc-icon
                          library="system"
                          icon-style="solid"
                          name="chevron-right"
                          part="submenu-icon"
                          id="submenu-indicator"
                          exportparts="svg:submenu-icon-svg"
                      ></pc-icon>
                  `:""}
            ${this.hasSubmenu?n`
                      <div
                          id="submenu"
                          part="submenu"
                          role="menu"
                          popover="manual"
                          tabindex="-1"
                          aria-orientation="vertical"
                          hidden
                      >
                          <slot name="submenu"></slot>
                      </div>
                  `:""}
        `}};e.css=g,i([h("#submenu")],e.prototype,"submenuElement",2),i([d()],e.prototype,"hasSubmenu",2),i([a({type:Boolean})],e.prototype,"active",2),i([a({reflect:!0})],e.prototype,"appearance",2),i([a({reflect:!0})],e.prototype,"size",2),i([a({attribute:"checkbox-adjacent",type:Boolean,reflect:!0})],e.prototype,"checkboxAdjacent",2),i([a({attribute:"submenu-adjacent",type:Boolean,reflect:!0})],e.prototype,"submenuAdjacent",2),i([a()],e.prototype,"value",2),i([a({reflect:!0})],e.prototype,"type",2),i([a({type:Boolean})],e.prototype,"checked",2),i([a({type:Boolean})],e.prototype,"disabled",2),i([a({type:Boolean,reflect:!0})],e.prototype,"submenuOpen",2),e=i([m("pc-dropdown-item")],e);export{e as a};
