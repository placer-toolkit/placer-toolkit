import{a as L,b as A,c as y,d as O,e as H,f as M,g as V,h as k,i as j,j as F}from"./chunk.4OSOIAPZ.js";import{a as S}from"./chunk.OVU4POJI.js";import{a as T}from"./chunk.GSH4CZ6Y.js";import{a as R,b as r,e as x,g as C}from"./chunk.PLBYMK2K.js";import{d as E}from"./chunk.FKNAQN55.js";import{a as N}from"./chunk.TBG3XWQL.js";import{b as o}from"./chunk.E6MOE4FE.js";function Y(a){return D(a)}function B(a){return a.assignedSlot?a.assignedSlot:a.parentNode instanceof ShadowRoot?a.parentNode.host:a.parentNode}function D(a){for(let n=a;n;n=B(n))if(n instanceof Element&&getComputedStyle(n).display==="none")return null;for(let n=B(a);n;n=B(n)){if(!(n instanceof Element))continue;let t=getComputedStyle(n);if(t.display!=="contents"&&(t.position!=="static"||L(t)||n.tagName==="BODY"))return n}return null}var X=`/*! Popup is a low\u2010level utility built specifically for positioning elements. Do not mistake it for a tooltip or similar because it does not facilitate an accessible experience! Almost every correct usage of it will involve building other components. It should rarely, if ever, occur directly in your HTML. */

:host {
    --arrow-color: var(--pc-color-neutral-fill-normal);
    --arrow-size: var(--pc-tooltip-arrow-size);

    /* These properties are computed to account for the arrow\u2019s dimensions
       after being rotated 45\xB0. The diagonal size of the arrow\u2019s container
       after rotating is sin(45\xB0). */
    --arrow-size-diagonal: calc(var(--arrow-size) * sin(45deg));
    --arrow-padding-offset: calc(
        var(--arrow-size-diagonal) - var(--arrow-size)
    );

    display: contents;
}

.popup {
    position: absolute;
    isolation: isolate;
    max-inline-size: var(--auto-size-available-width, none);
    max-block-size: var(--auto-size-available-height, none);
    will-change: transform, top, left;

    /* Reset user agent styles for the popover attribute. */
    :where(&) {
        inset: unset;
        margin: unset;
        padding: unset;
        inline-size: unset;
        block-size: unset;
        /* inline-size and block-size do not affect the width and height
           properties. This is redefined to be sure it is also unset. */
        width: unset;
        height: unset;
        background: unset;
        border: unset;
        overflow: unset;
    }
}

.fixed {
    position: fixed;
}

.popup:not(.active) {
    display: none;
}

.arrow {
    position: absolute;
    inline-size: calc(var(--arrow-size-diagonal) * 2);
    block-size: calc(var(--arrow-size-diagonal) * 2);
    background-color: var(--arrow-color);
    rotate: 45deg;
    z-index: 3;
}

:host([data-current-placement~="left"]) .arrow {
    rotate: -45deg;
}

:host([data-current-placement~="right"]) .arrow {
    rotate: 135deg;
}

:host([data-current-placement~="bottom"]) .arrow {
    rotate: 225deg;
}

.hover-bridge:not(.hover-bridge-visible) {
    display: none;
}

.hover-bridge {
    position: fixed;
    inset: 0;
    clip-path: polygon(
        var(--hover-bridge-top-left-x, 0) var(--hover-bridge-top-left-y, 0),
        var(--hover-bridge-top-right-x, 0) var(--hover-bridge-top-right-y, 0),
        var(--hover-bridge-bottom-right-x, 0)
            var(--hover-bridge-bottom-right-y, 0),
        var(--hover-bridge-bottom-left-x, 0)
            var(--hover-bridge-bottom-left-y, 0)
    );
    z-index: 899;
}
`;function q(a){return a!==null&&typeof a=="object"&&"getBoundingClientRect"in a&&("contextElement"in a?a instanceof Element:!0)}var v=globalThis?.HTMLElement?.prototype.hasOwnProperty("popover"),e=class extends C{constructor(){super(...arguments);this.localize=new N(this);this.active=!1;this.placement="top";this.boundary="viewport";this.distance=0;this.skidding=0;this.arrow=!1;this.arrowPlacement="anchor";this.arrowPadding=10;this.flip=!1;this.flipFallbackPlacements="";this.flipFallbackStrategy="best-fit";this.flipPadding=0;this.shift=!1;this.shiftPadding=0;this.autoSizePadding=0;this.hoverBridge=!1;this.updateHoverBridge=()=>{if(this.hoverBridge&&this.anchorElement){let t=this.anchorElement.getBoundingClientRect(),i=this.popup.getBoundingClientRect(),w=this.placement.includes("top")||this.placement.includes("bottom"),s=0,l=0,c=0,f=0,d=0,u=0,h=0,p=0;w?t.top<i.top?(s=t.left,l=t.bottom,c=t.right,f=t.bottom,d=i.left,u=i.top,h=i.right,p=i.top):(s=i.left,l=i.bottom,c=i.right,f=i.bottom,d=t.left,u=t.top,h=t.right,p=t.top):t.left<i.left?(s=t.right,l=t.top,c=i.left,f=i.top,d=t.right,u=t.bottom,h=i.left,p=i.bottom):(s=i.right,l=i.top,c=t.left,f=t.top,d=i.right,u=i.bottom,h=t.left,p=t.bottom),this.style.setProperty("--hover-bridge-top-left-x",`${s}px`),this.style.setProperty("--hover-bridge-top-left-y",`${l}px`),this.style.setProperty("--hover-bridge-top-right-x",`${c}px`),this.style.setProperty("--hover-bridge-top-right-y",`${f}px`),this.style.setProperty("--hover-bridge-bottom-left-x",`${d}px`),this.style.setProperty("--hover-bridge-bottom-left-y",`${u}px`),this.style.setProperty("--hover-bridge-bottom-right-x",`${h}px`),this.style.setProperty("--hover-bridge-bottom-right-y",`${p}px`)}}}async connectedCallback(){super.connectedCallback(),await this.updateComplete,this.start()}disconnectedCallback(){super.disconnectedCallback(),this.stop()}async updated(t){super.updated(t),t.has("active")&&(this.active?this.start():this.stop()),t.has("anchor")&&this.handleAnchorChange(),this.active&&(await this.updateComplete,this.reposition())}async handleAnchorChange(){if(await this.stop(),this.anchor&&typeof this.anchor=="string"){let t=this.getRootNode();this.anchorElement=t.getElementById(this.anchor)}else this.anchor instanceof Element||q(this.anchor)?this.anchorElement=this.anchor:this.anchorElement=this.querySelector('[slot="anchor"]');this.anchorElement instanceof HTMLSlotElement&&(this.anchorElement=this.anchorElement.assignedElements({flatten:!0})[0]),this.anchorElement&&this.start()}start(){!this.anchorElement||!this.active||(this.popup.showPopover?.(),this.cleanup=O(this.anchorElement,this.popup,()=>{this.reposition()}))}async stop(){return new Promise(t=>{this.popup.hidePopover?.(),this.cleanup?(this.cleanup(),this.cleanup=void 0,this.removeAttribute("data-current-placement"),this.style.removeProperty("--auto-size-available-width"),this.style.removeProperty("--auto-size-available-height"),requestAnimationFrame(()=>t())):t()})}reposition(){if(!this.active||!this.anchorElement)return;let t=[H({mainAxis:this.distance,crossAxis:this.skidding})];this.sync?t.push(k({apply:({rects:s})=>{let l=this.sync==="width"||this.sync==="both",c=this.sync==="height"||this.sync==="both";this.popup.style.inlineSize=l?`${s.reference.width}px`:"",this.popup.style.blockSize=c?`${s.reference.height}px`:""}})):(this.popup.style.inlineSize="",this.popup.style.blockSize="");let i;v&&!q(this.anchor)&&this.boundary==="scroll"&&(i=A(this.anchorElement).filter(s=>s instanceof Element)),this.flip&&t.push(V({boundary:this.flipBoundary||i,fallbackPlacements:this.flipFallbackPlacements,fallbackStrategy:this.flipFallbackStrategy==="best-fit"?"bestFit":"initialPlacement",padding:this.flipPadding})),this.shift&&t.push(M({boundary:this.shiftBoundary||i,padding:this.shiftPadding})),this.autoSize?t.push(k({boundary:this.autoSizeBoundary||i,padding:this.autoSizePadding,apply:({availableWidth:s,availableHeight:l})=>{this.autoSize==="vertical"||this.autoSize==="both"?this.style.setProperty("--auto-size-available-height",`${l}px`):this.style.removeProperty("--auto-size-available-height"),this.autoSize==="horizontal"||this.autoSize==="both"?this.style.setProperty("--auto-size-available-width",`${s}px`):this.style.removeProperty("--auto-size-available-width")}})):(this.style.removeProperty("--auto-size-available-width"),this.style.removeProperty("--auto-size-available-height")),this.arrow&&t.push(j({element:this.arrowElement,padding:this.arrowPadding}));let w=v?s=>y.getOffsetParent(s,Y):y.getOffsetParent;F(this.anchorElement,this.popup,{placement:this.placement,middleware:t,strategy:v?"absolute":"fixed",platform:{...y,getOffsetParent:w}}).then(({x:s,y:l,middlewareData:c,placement:f})=>{let d=this.localize.dir()==="rtl",u={top:"bottom",right:"left",bottom:"top",left:"right"}[f.split("-")[0]];if(this.setAttribute("data-current-placement",f),Object.assign(this.popup.style,{left:`${s}px`,top:`${l}px`}),this.arrow){let h=c.arrow.x,p=c.arrow.y,b="",z="",$="",m="";if(this.arrowPlacement==="start"){let g=typeof h=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:"";b=typeof p=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:"",z=d?g:"",m=d?"":g}else if(this.arrowPlacement==="end"){let g=typeof h=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:"";z=d?"":g,m=d?g:"",$=typeof p=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:""}else this.arrowPlacement==="center"?(m=typeof h=="number"?"calc(50% - var(--arrow-size-diagonal))":"",b=typeof p=="number"?"calc(50% - var(--arrow-size-diagonal))":""):(m=typeof h=="number"?`${h}px`:"",b=typeof p=="number"?`${p}px`:"");Object.assign(this.arrowElement.style,{top:b,right:z,bottom:$,left:m,[u]:"calc(var(--arrow-size-diagonal) * -1)"})}}),requestAnimationFrame(()=>this.updateHoverBridge()),this.dispatchEvent(new T)}render(){return E`
            <slot name="anchor" @slotchange=${this.handleAnchorChange}></slot>

            <span
                part="hover-bridge"
                class=${S({"hover-bridge":!0,"hover-bridge-visible":this.hoverBridge&&this.active})}
            ></span>

            <div
                part="popup"
                popover="manual"
                class=${S({popup:!0,active:this.active,fixed:!v,"has-arrow":this.arrow})}
            >
                <slot></slot>
                ${this.arrow?E`
                          <div
                              part="arrow"
                              class="arrow"
                              role="presentation"
                          ></div>
                      `:""}
            </div>
        `}};e.css=X,o([x(".popup")],e.prototype,"popup",2),o([x(".arrow")],e.prototype,"arrowElement",2),o([r()],e.prototype,"anchor",2),o([r({type:Boolean,reflect:!0})],e.prototype,"active",2),o([r({reflect:!0})],e.prototype,"placement",2),o([r()],e.prototype,"boundary",2),o([r({type:Number})],e.prototype,"distance",2),o([r({type:Number})],e.prototype,"skidding",2),o([r({type:Boolean})],e.prototype,"arrow",2),o([r({attribute:"arrow-placement"})],e.prototype,"arrowPlacement",2),o([r({attribute:"arrow-padding",type:Number})],e.prototype,"arrowPadding",2),o([r({type:Boolean})],e.prototype,"flip",2),o([r({attribute:"flip-fallback-placements",converter:{fromAttribute:t=>t.split(" ").map(i=>i.trim()).filter(i=>i!==""),toAttribute:t=>t.join(" ")}})],e.prototype,"flipFallbackPlacements",2),o([r({attribute:"flip-fallback-strategy"})],e.prototype,"flipFallbackStrategy",2),o([r({type:Object})],e.prototype,"flipBoundary",2),o([r({attribute:"flip-padding",type:Number})],e.prototype,"flipPadding",2),o([r({type:Boolean})],e.prototype,"shift",2),o([r({type:Object})],e.prototype,"shiftBoundary",2),o([r({attribute:"shift-padding",type:Number})],e.prototype,"shiftPadding",2),o([r({attribute:"auto-size"})],e.prototype,"autoSize",2),o([r()],e.prototype,"sync",2),o([r({type:Object})],e.prototype,"autoSizeBoundary",2),o([r({attribute:"auto-size-padding",type:Number})],e.prototype,"autoSizePadding",2),o([r({attribute:"hover-bridge",type:Boolean})],e.prototype,"hoverBridge",2),e=o([R("pc-popup")],e);export{e as a};
//! Popup is a low‐level utility built specifically for positioning elements. Do not mistake it for a tooltip or similar because it does not facilitate an accessible experience! Almost every correct usage of it will involve building other components. It should rarely, if ever, occur directly in your HTML.
