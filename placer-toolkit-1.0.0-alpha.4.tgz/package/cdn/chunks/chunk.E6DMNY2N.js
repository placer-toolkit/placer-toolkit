import{a as v}from"./chunk.GG6CNHGL.js";import{a as R}from"./chunk.W5PM7F34.js";import{a as M}from"./chunk.BSQP4EKW.js";import{a as T}from"./chunk.OVU4POJI.js";import{a as D}from"./chunk.YPTKAITV.js";import{a as h}from"./chunk.ZS4GILCB.js";import{b as V}from"./chunk.ZLITPNV3.js";import{a as y}from"./chunk.AGGS6MN5.js";import{a as $}from"./chunk.NOX5TXXZ.js";import{a as k,b as r,c as w,e as c}from"./chunk.PLBYMK2K.js";import{d}from"./chunk.FKNAQN55.js";import{a as F}from"./chunk.V65QAGBQ.js";import{a as z}from"./chunk.TBG3XWQL.js";import{b as a}from"./chunk.E6MOE4FE.js";var E=`:host {
    --track-size: 0.5em;
    --thumb-width: 1.4em;
    --thumb-height: 1.4em;
    --marker-width: 0.1875em;
    --marker-height: 0.1875em;
}

:host([orientation="vertical"]) {
    inline-size: auto;
}

.label:has(~ .vertical) {
    display: block;
    order: 2;
    max-inline-size: none;
    text-align: center;
}

.description:has(~ .vertical) {
    order: 3;
    text-align: center;
}

.label:has(*:not(:empty)) ~ .slider {
    &.horizontal {
        margin-block-start: 0.5em;
    }

    &.vertical {
        margin-block-end: 0.5em;
    }
}

.slider {
    touch-action: none;

    &:focus {
        outline: none;
    }

    &:focus-visible:not(.disabled) .thumb,
    &:focus-visible:not(.disabled) .thumb-min,
    &:focus-visible:not(.disabled) .thumb-max {
        outline: var(--pc-focus-ring);
        animation: focus-ring-animation var(--pc-transition-medium)
            cubic-bezier(0.33, 1, 0.68, 1);
    }
}

.track {
    position: relative;
    background-color: var(--pc-color-neutral-border-normal);
    border-radius: var(--pc-border-radius-pill);
    isolation: isolate;
}

.horizontal .track {
    block-size: var(--track-size);
}

.vertical .track {
    order: 1;
    inline-size: var(--track-size);
    block-size: 200px;
}

.disabled .track {
    opacity: 0.5;
    cursor: not-allowed;
}

.indicator {
    position: absolute;
    inset-inline-start: min(var(--start), var(--end));
    inset-inline-end: calc(100% - max(var(--start), var(--end)));
    background-color: var(--pc-form-control-activated-color);
    border-radius: inherit;
}

.horizontal .indicator {
    inset-block-start: 0;
    block-size: 100%;
}

.vertical .indicator {
    inset-block-start: calc(100% - var(--end));
    inset-block-end: var(--start);
    inset-inline: 0;
    inline-size: 100%;
}

.thumb,
.thumb-min,
.thumb-max {
    position: absolute;
    inline-size: var(--thumb-width);
    block-size: var(--thumb-height);
    border: var(--pc-border-width-m) var(--pc-border-style)
        var(--pc-color-surface-default);
    background-color: var(--pc-form-control-activated-color);
    border-radius: var(--pc-border-radius-circle);
    z-index: 3;
    cursor: pointer;
}

.disabled .thumb,
.disabled .thumb-min,
.disabled .thumb-max {
    cursor: inherit;
}

.horizontal .thumb,
.horizontal .thumb-min,
.horizontal .thumb-max {
    inset-block-start: calc(50% - var(--thumb-height) / 2);
    inset-inline-start: calc(var(--position) - var(--thumb-width) / 2);
    inset-inline-end: auto;
}

.vertical .thumb,
.vertical .thumb-min,
.vertical .thumb-max {
    inset-block-end: calc(var(--position) - var(--thumb-height) / 2);
    inset-inline-start: calc(50% - var(--thumb-width) / 2);
}

:host([range]) {
    .thumb-min:focus-visible,
    .thumb-max:focus-visible {
        outline: var(--pc-focus-ring);
        z-index: 4;
        animation: focus-ring-animation var(--pc-transition-medium)
            cubic-bezier(0.33, 1, 0.68, 1);
    }
}

.markers {
    pointer-events: none;
}

.marker {
    position: absolute;
    inline-size: var(--marker-width);
    block-size: var(--marker-height);
    background-color: var(--pc-color-surface-default);
    border-radius: var(--pc-border-radius-circle);
    z-index: 2;
}

.marker:first-of-type,
.marker:last-of-type {
    display: none;
}

.horizontal .marker {
    top: calc(50% - var(--marker-height) / 2);
    left: calc(var(--position) - var(--marker-width) / 2);
}

.vertical .marker {
    top: calc(var(--position) - var(--marker-height) / 2);
    left: calc(50% - var(--marker-width) / 2);
}

/* Marker labels */
.references {
    position: relative;

    slot {
        display: flex;
        justify-content: space-between;
        block-size: 100%;
    }

    ::slotted(*) {
        color: var(--pc-color-text-quiet);
        font-size: var(--pc-font-size-smaller);
        line-height: 1;
    }
}

.horizontal {
    .references {
        margin-block-start: 0.5em;
    }
}

.vertical {
    display: flex;
    margin-inline: auto;

    .track {
        order: 1;
    }

    .references {
        order: 2;
        margin-inline-start: 0.75em;
        inline-size: min-content;

        slot {
            flex-direction: column;
        }
    }
}

.vertical .references slot {
    flex-direction: column;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var e=class extends ${constructor(){super(...arguments);this.draggableThumbMin=null;this.draggableThumbMax=null;this.hasSlotController=new y(this,"hint","label");this.localize=new z(this);this.activeThumb=null;this.lastTrackPosition=null;this.label="";this.hint="";this.minValue=0;this.maxValue=50;this.defaultValue=this.getAttribute("value")==null?this.minValue:Number(this.getAttribute("value"));this._value=this.defaultValue;this.range=!1;this.disabled=!1;this.readonly=!1;this.orientation="horizontal";this.size="medium";this.min=0;this.max=100;this.step=1;this.tooltipDistance=8;this.tooltipPlacement="top";this.withMarkers=!1;this.hasTooltip=!1}static get validators(){return[...super.validators,D()]}get focusableAnchor(){return this.isRange?this.thumbMin||this.slider:this.slider}get validationTarget(){return this.focusableAnchor}get value(){return this.valueHasChanged?this._value:this._value??this.defaultValue}set value(t){t=Number(t)??this.minValue,this._value!==t&&(this.valueHasChanged=!0,this._value=t)}get isRange(){return this.range}firstUpdated(){this.isRange?(this.draggableThumbMin=new V(this.thumbMin,{start:()=>{this.activeThumb="min",this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.valueWhenDraggingStarted=this.minValue,this.customStates.set("dragging",!0),this.showRangeTooltips()},move:(t,i)=>{this.setThumbValueFromCoordinates(t,i,"min")},stop:()=>{this.minValue!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideRangeTooltips(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0,this.activeThumb=null}}),this.draggableThumbMax=new V(this.thumbMax,{start:()=>{this.activeThumb="max",this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.valueWhenDraggingStarted=this.maxValue,this.customStates.set("dragging",!0),this.showRangeTooltips()},move:(t,i)=>{this.setThumbValueFromCoordinates(t,i,"max")},stop:()=>{this.maxValue!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideRangeTooltips(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0,this.activeThumb=null}}),this.draggableTrack=new V(this.track,{start:(t,i)=>{if(this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.activeThumb)this.valueWhenDraggingStarted=this.activeThumb==="min"?this.minValue:this.maxValue;else{let l=this.getValueFromCoordinates(t,i),s=Math.abs(l-this.minValue),n=Math.abs(l-this.maxValue);if(s===n)if(l>this.maxValue)this.activeThumb="max";else if(l<this.minValue)this.activeThumb="min";else{let p=this.localize.dir()==="rtl",u=this.orientation==="vertical",m=u?i:t,b=this.lastTrackPosition||m;this.lastTrackPosition=m;let g=m>b!==p&&!u||m<b&&u;this.activeThumb=g?"max":"min"}else this.activeThumb=s<=n?"min":"max";this.valueWhenDraggingStarted=this.activeThumb==="min"?this.minValue:this.maxValue}this.customStates.set("dragging",!0),this.setThumbValueFromCoordinates(t,i,this.activeThumb),this.showRangeTooltips()},stop:()=>{this.activeThumb&&(this.activeThumb==="min"?this.minValue:this.maxValue)!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideRangeTooltips(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0,this.activeThumb=null}})):this.draggableTrack=new V(this.slider,{start:(t,i)=>{this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.valueWhenDraggingStarted=this.value,this.customStates.set("dragging",!0),this.setValueFromCoordinates(t,i),this.showTooltip()},move:(t,i)=>{this.setValueFromCoordinates(t,i)},stop:()=>{this.value!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideTooltip(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0}})}updated(t){if(t.has("range")&&this.requestUpdate(),this.isRange?(t.has("minValue")||t.has("maxValue"))&&(this.minValue=h(this.minValue,this.min,this.maxValue),this.maxValue=h(this.maxValue,this.minValue,this.max),this.updateFormValue()):t.has("value")&&(this.value=h(this.value,this.min,this.max),this.setValue(String(this.value))),(t.has("min")||t.has("max"))&&(this.isRange?(this.minValue=h(this.minValue,this.min,this.max),this.maxValue=h(this.maxValue,this.min,this.max)):this.value=h(this.value,this.min,this.max)),t.has("disabled")&&this.customStates.set("disabled",this.disabled),t.has("disabled")||t.has("readonly")){let i=!(this.disabled||this.readonly);this.isRange&&(this.draggableThumbMin&&this.draggableThumbMin.toggle(i),this.draggableThumbMax&&this.draggableThumbMax.toggle(i)),this.draggableTrack&&this.draggableTrack.toggle(i)}super.updated(t)}formDisabledCallback(t){this.disabled=t}formResetCallback(){this.isRange?(this.minValue=parseFloat(this.getAttribute("min-value")??String(this.min)),this.maxValue=parseFloat(this.getAttribute("max-value")??String(this.max))):this.value=parseFloat(this.getAttribute("value")??String(this.min)),this.hasInteracted=!1,super.formResetCallback()}clampAndRoundToStep(t){let i=(String(this.step).split(".")[1]||"").replace(/0+$/g,"").length,l=Number(this.step),s=Number(this.min),n=Number(this.max);return t=Math.round(t/l)*l,t=h(t,s,n),parseFloat(t.toFixed(i))}getPercentageFromValue(t){return(t-this.min)/(this.max-this.min)*100}getValueFromCoordinates(t,i){let l=this.localize.dir()==="rtl",s=this.orientation==="vertical",{top:n,right:p,bottom:u,left:m,height:b,width:g}=this.trackBoundingClientRect,f=s?i:t,o=s?{start:n,end:u,size:b}:{start:m,end:p,size:g},C=(s||l?o.end-f:f-o.start)/o.size;return this.clampAndRoundToStep(this.min+(this.max-this.min)*C)}handleFocus(t){let i=t.target;this.isRange?(i===this.thumbMin?this.activeThumb="min":i===this.thumbMax&&(this.activeThumb="max"),this.showRangeTooltips()):this.showTooltip(),this.customStates.set("focused",!0),this.dispatchEvent(new FocusEvent("focus",{bubbles:!0,composed:!0}))}handleBlur(){this.isRange?requestAnimationFrame(()=>{let t=this.shadowRoot?.activeElement;t===this.thumbMin||t===this.thumbMax||this.hideRangeTooltips()}):this.hideTooltip(),this.customStates.set("focused",!1),this.dispatchEvent(new FocusEvent("blur",{bubbles:!0,composed:!0}))}handleKeyDown(t){let i=this.localize.dir()==="rtl",l=t.target;if(this.disabled||this.readonly||this.isRange&&(l===this.thumbMin?this.activeThumb="min":l===this.thumbMax&&(this.activeThumb="max"),!this.activeThumb))return;let s=this.isRange?this.activeThumb==="min"?this.minValue:this.maxValue:this.value,n=s;switch(t.key){case"ArrowUp":case(i?"ArrowLeft":"ArrowRight"):t.preventDefault(),n=this.clampAndRoundToStep(s+this.step);break;case"ArrowDown":case(i?"ArrowRight":"ArrowLeft"):t.preventDefault(),n=this.clampAndRoundToStep(s-this.step);break;case"Home":t.preventDefault(),n=this.isRange&&this.activeThumb==="min"?this.min:this.isRange?this.minValue:this.min;break;case"End":t.preventDefault(),n=this.isRange&&this.activeThumb==="max"?this.max:this.isRange?this.maxValue:this.max;break;case"PageUp":t.preventDefault();let p=Math.max(s+(this.max-this.min)/10,s+this.step);n=this.clampAndRoundToStep(p);break;case"PageDown":t.preventDefault();let u=Math.min(s-(this.max-this.min)/10,s-this.step);n=this.clampAndRoundToStep(u);break;case"Enter":F(t,this);return}n!==s&&(this.isRange?(this.activeThumb==="min"?n>this.maxValue?(this.maxValue=n,this.minValue=n):this.minValue=Math.max(this.min,n):n<this.minValue?(this.minValue=n,this.maxValue=n):this.maxValue=Math.min(this.max,n),this.updateFormValue()):this.value=h(n,this.min,this.max),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0)}handleLabelPointerDown(t){t.preventDefault(),this.disabled||(this.isRange?this.thumbMin?.focus():this.slider.focus())}setValueFromCoordinates(t,i){let l=this.value;this.value=this.getValueFromCoordinates(t,i),this.value!==l&&this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}setThumbValueFromCoordinates(t,i,l){let s=this.getValueFromCoordinates(t,i),n=l==="min"?this.minValue:this.maxValue;l==="min"?s>this.maxValue?(this.maxValue=s,this.minValue=s):this.minValue=Math.max(this.min,s):s<this.minValue?(this.minValue=s,this.maxValue=s):this.maxValue=Math.min(this.max,s),n!==(l==="min"?this.minValue:this.maxValue)&&(this.updateFormValue(),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))}showTooltip(){this.hasTooltip&&this.tooltip&&(this.tooltip.open=!0)}hideTooltip(){this.hasTooltip&&this.tooltip&&(this.tooltip.open=!1)}showRangeTooltips(){this.hasTooltip&&(this.activeThumb==="min"?(this.tooltipMin&&(this.tooltipMin.open=!0),this.tooltipMax&&(this.tooltipMax.open=!1)):this.activeThumb==="max"&&(this.tooltipMax&&(this.tooltipMax.open=!0),this.tooltipMin&&(this.tooltipMin.open=!1)))}hideRangeTooltips(){this.hasTooltip&&(this.tooltipMin&&(this.tooltipMin.open=!1),this.tooltipMax&&(this.tooltipMax.open=!1))}updateFormValue(){if(this.isRange){let t=new FormData;t.append(this.name||"",String(this.minValue)),t.append(this.name||"",String(this.maxValue)),this.setValue(t)}}focus(){this.isRange?this.thumbMin?.focus():this.slider.focus()}blur(){this.isRange?document.activeElement===this.thumbMin?this.thumbMin.blur():document.activeElement===this.thumbMax&&this.thumbMax.blur():this.slider.blur()}stepDown(){if(this.isRange){let t=this.clampAndRoundToStep(this.minValue-this.step);this.minValue=h(t,this.min,this.maxValue),this.updateFormValue()}else{let t=this.clampAndRoundToStep(this.value-this.step);this.value=t}}stepUp(){if(this.isRange){let t=this.clampAndRoundToStep(this.maxValue+this.step);this.maxValue=h(t,this.minValue,this.max),this.updateFormValue()}else{let t=this.clampAndRoundToStep(this.value+this.step);this.value=t}}render(){let t=this.hasSlotController.test("label"),i=this.hasSlotController.test("hint"),l=this.label?!0:!!t,s=this.hint?!0:!!i,n=this.hasSlotController.test("reference"),p=T({slider:!0,small:this.size==="small",medium:this.size==="medium",large:this.size==="large",horizontal:this.orientation==="horizontal",vertical:this.orientation==="vertical",disabled:this.disabled}),u=[];if(this.withMarkers)for(let o=this.min;o<=this.max;o+=this.step)u.push(this.getPercentageFromValue(o));let m=d`
            <label
                part="label"
                class=${T({label:!0,"has-label":l})}
                id="label"
                for=${this.isRange?"thumb-min":"text-box"}
                @pointerdown=${this.handleLabelPointerDown}
            >
                <slot name="label">${this.label}</slot>
            </label>
        `,b=d`
            <slot
                part="hint"
                class=${T({hint:!0,"has-hint":s})}
                id="hint"
                name="hint"
            >
                ${this.hint}
            </slot>
        `,g=this.withMarkers?d`
                  <div part="markers" class="markers">
                      ${u.map(o=>d`
                              <span
                                  part="marker"
                                  class="marker"
                                  style=${v({"--position":`${o}%`})}
                              ></span>
                          `)}
                  </div>
              `:"",f=n?d`
                  <div part="references" class="references" aria-hidden="true">
                      <slot name="reference"></slot>
                  </div>
              `:"";if(this.isRange){let o=h(this.getPercentageFromValue(this.minValue),0,100),x=h(this.getPercentageFromValue(this.maxValue),0,100);return d`
                ${m}

                <div part="slider" class="slider" class=${p}>
                    <div part="track" class="track">
                        <div
                            part="indicator"
                            class="indicator"
                            style=${v({"--start":`${Math.min(o,x)}%`,"--end":`${Math.max(o,x)}%`})}
                        ></div>

                        ${g}

                        <pc-tooltip
                            part="tooltip tooltip-min"
                            content=${this.valueFormatter?this.valueFormatter(this.minValue):this.localize.number(this.minValue)}
                            trigger="manual"
                            distance=${this.tooltipDistance}
                            placement=${this.tooltipPlacement}
                            activation="manual"
                            dir=${this.localize.dir()}
                            exportparts="
                                base:tooltip-base,
                                body:tooltip-body,
                                arrow:tooltip-arrow
                            "
                        >
                            <span
                                part="thumb thumb-min"
                                class="thumb-min"
                                style=${v({"--position":`${o}%`})}
                                role="slider"
                                tabindex=${this.disabled?-1:0}
                                aria-valuemin=${this.min}
                                aria-valuemax=${this.max}
                                aria-valuenow=${this.minValue}
                                aria-valuetext=${this.valueFormatter?this.valueFormatter(this.minValue):this.localize.number(this.minValue)}
                                aria-label=${this.label?this.localize.term("minimumValueDescriptive",this.label):this.localize.term("minimumValue")}
                                aria-orientation=${this.orientation}
                                aria-disabled=${this.disabled}
                                aria-readonly=${this.readonly}
                                @focus=${this.handleFocus}
                                @blur=${this.handleBlur}
                                @keydown=${this.handleKeyDown}
                            ></span>
                        </pc-tooltip>

                        <pc-tooltip
                            part="tooltip tooltip-max"
                            trigger="manual"
                            content=${this.valueFormatter?this.valueFormatter(this.maxValue):this.localize.number(this.maxValue)}
                            distance=${this.tooltipDistance}
                            placement=${this.tooltipPlacement}
                            activation="manual"
                            dir=${this.localize.dir()}
                            exportparts="
                                base:tooltip-base,
                                body:tooltip-body,
                                arrow:tooltip-arrow
                            "
                        >
                            <span
                                part="thumb thumb-max"
                                class="thumb-max"
                                style=${v({"--position":`${x}%`})}
                                role="slider"
                                aria-valuemin=${this.min}
                                aria-valuenow=${this.maxValue}
                                aria-valuetext=${typeof this.valueFormatter=="function"?this.valueFormatter(this.maxValue):this.localize.number(this.maxValue)}
                                aria-valuemax=${this.max}
                                aria-label=${this.label?this.localize.term("maximumValueDescriptive",this.label):this.localize.term("maximumValue")}
                                aria-orientation=${this.orientation}
                                aria-disabled=${this.disabled?"true":"false"}
                                aria-readonly=${this.readonly?"true":"false"}
                                tabindex=${this.disabled?-1:0}
                                @focus=${this.handleFocus}
                                @blur=${this.handleBlur}
                                @keydown=${this.handleKeyDown}
                            ></span>
                        </pc-tooltip>
                    </div>

                    ${f} ${b}
                </div>
            `}else{let o=h(this.getPercentageFromValue(this.value),0,100),x=h(this.getPercentageFromValue(typeof this.indicatorOffset=="number"?this.indicatorOffset:this.min),0,100);return d`
                ${m}

                <div
                    part="slider"
                    class=${p}
                    role="slider"
                    tabindex=${this.disabled?-1:0}
                    aria-disabled=${this.disabled?"true":"false"}
                    aria-readonly=${this.disabled?"true":"false"}
                    aria-orientation=${this.orientation}
                    aria-valuemin=${this.min}
                    aria-valuenow=${this.value}
                    aria-valuetext=${typeof this.valueFormatter=="function"?this.valueFormatter(this.value):this.localize.number(this.value)}
                    aria-valuemax=${this.max}
                    aria-labelledby="label"
                    aria-describedby="hint"
                    @focus=${this.handleFocus}
                    @blur=${this.handleBlur}
                    @keydown=${this.handleKeyDown}
                >
                    <div part="track" class="track">
                        <div
                            part="indicator"
                            class="indicator"
                            style=${v({"--start":`${x}%`,"--end":`${o}%`})}
                        ></div>

                        ${g}

                        <pc-tooltip
                            part="tooltip"
                            class="tooltip"
                            content=${this.valueFormatter?this.valueFormatter(this.value):this.localize.number(this.value)}
                            trigger="manual"
                            distance=${this.tooltipDistance}
                            placement=${this.tooltipPlacement}
                            activation="manual"
                            dir=${this.localize.dir()}
                            exportparts="
                                base:tooltip__base,
                                body:tooltip__body,
                                arrow:tooltip__arrow
                            "
                        >
                            <span
                                part="thumb"
                                class="thumb"
                                style=${v({"--position":`${o}%`})}
                            ></span>
                        </pc-tooltip>
                    </div>

                    ${f} ${b}
                </div>
            `}}};e.formAssociated=!0,e.observeSlots=!0,e.css=[M,R,E],a([c('[part~="slider"]')],e.prototype,"slider",2),a([c('[part~="thumb"]')],e.prototype,"thumb",2),a([c('[part~="thumb-min"]')],e.prototype,"thumbMin",2),a([c('[part~="thumb-max"]')],e.prototype,"thumbMax",2),a([c('[part~="track"]')],e.prototype,"track",2),a([c('[part~="tooltip-min"]')],e.prototype,"tooltipMin",2),a([c('[part~="tooltip-max"]')],e.prototype,"tooltipMax",2),a([c('[part~="tooltip"]')],e.prototype,"tooltip",2),a([r()],e.prototype,"label",2),a([r({attribute:"hint"})],e.prototype,"hint",2),a([r({reflect:!0})],e.prototype,"name",2),a([r({type:Number,attribute:"min-value"})],e.prototype,"minValue",2),a([r({type:Number,attribute:"max-value"})],e.prototype,"maxValue",2),a([r({attribute:"value",reflect:!0,type:Number})],e.prototype,"defaultValue",2),a([w()],e.prototype,"value",1),a([r({type:Boolean,reflect:!0})],e.prototype,"range",2),a([r({type:Boolean})],e.prototype,"disabled",2),a([r({type:Boolean,reflect:!0})],e.prototype,"readonly",2),a([r({reflect:!0})],e.prototype,"orientation",2),a([r({reflect:!0})],e.prototype,"size",2),a([r({attribute:"indicator-offset",type:Number})],e.prototype,"indicatorOffset",2),a([r({type:Number})],e.prototype,"min",2),a([r({type:Number})],e.prototype,"max",2),a([r({type:Number})],e.prototype,"step",2),a([r({type:Boolean})],e.prototype,"autofocus",2),a([r({attribute:"tooltip-distance",type:Number})],e.prototype,"tooltipDistance",2),a([r({attribute:"tooltip-placement",reflect:!0})],e.prototype,"tooltipPlacement",2),a([r({attribute:"with-markers",type:Boolean})],e.prototype,"withMarkers",2),a([r({attribute:"has-tooltip",type:Boolean})],e.prototype,"hasTooltip",2),a([r({attribute:!1})],e.prototype,"valueFormatter",2),e=a([k("pc-slider")],e);export{e as a};
