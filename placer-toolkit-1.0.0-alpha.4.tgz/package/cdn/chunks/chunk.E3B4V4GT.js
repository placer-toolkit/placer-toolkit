import{a as y}from"./chunk.OVU4POJI.js";import{a as b}from"./chunk.Y452TQZB.js";import{a as w}from"./chunk.OOPBLVP2.js";import{a as E}from"./chunk.OMC4FRTB.js";import{a as k}from"./chunk.GFCFF7RE.js";import{a as p,b as h,d}from"./chunk.RZZMGXAZ.js";import{a as u}from"./chunk.OOQOIJSK.js";import{a as f,b as i,e as r,g as v}from"./chunk.PLBYMK2K.js";import{d as m}from"./chunk.FKNAQN55.js";import{a}from"./chunk.H2EOXVSZ.js";import{a as l,c}from"./chunk.N5AZOOIZ.js";import{a as g}from"./chunk.TBG3XWQL.js";import{b as e}from"./chunk.E6MOE4FE.js";var C=`:host {
    --max-width: 30ch;
    --hide-delay: 0s;
    --show-delay: 0.15s;

    display: contents;
}

.tooltip {
    --arrow-size: var(--pc-tooltip-arrow-size);
    --arrow-color: var(--pc-tooltip-background-color);
    box-shadow: var(--pc-shadow-xs);
}

.tooltip::part(popup) {
    z-index: 1000;
}

.tooltip[data-current-placement^="top"]::part(popup) {
    transform-origin: bottom;
}

.tooltip[data-current-placement^="bottom"]::part(popup) {
    transform-origin: top;
}

.tooltip[data-current-placement^="left"]::part(popup) {
    transform-origin: right;
}

.tooltip[data-current-placement^="right"]::part(popup) {
    transform-origin: left;
}

.body {
    display: block;
    inline-size: max-content;
    max-inline-size: var(--max-width);
    padding: var(--pc-tooltip-padding);
    background-color: var(--pc-tooltip-background-color);
    color: var(--pc-tooltip-color);
    border-radius: var(--pc-tooltip-border-radius);
    font-family: var(--pc-tooltip-font-family);
    font-size: var(--pc-tooltip-font-size);
    font-weight: var(--pc-tooltip-font-weight);
    line-height: var(--pc-tooltip-line-height);
    text-align: center;
    white-space: normal;
    pointer-events: none;
    user-select: none;
    -webkit-user-select: none;
    box-shadow: var(--pc-shadow-xs);
}
`;l("tooltip.show",{keyframes:[{opacity:0,scale:.8},{opacity:1,scale:1.05},{opacity:1,scale:1}],options:{duration:220,easing:"ease-out"}});l("tooltip.hide",{keyframes:[{opacity:1,scale:1},{opacity:0,scale:.9}],options:{duration:140,easing:"cubic-bezier(0.4, 0, 1, 1)"}});var t=class extends v{constructor(){super();this.localize=new g(this);this.content="";this.placement="top";this.disabled=!1;this.distance=8;this.open=!1;this.skidding=0;this.trigger="hover focus";this.handleClick=()=>{this.hasTrigger("click")&&(this.open?this.hide():this.show())};this.handleFocus=()=>{this.hasTrigger("focus")&&this.show()};this.handleBlur=()=>{this.hasTrigger("focus")&&this.hide()};this.handleDocumentKeyDown=o=>{o.key==="Escape"&&(o.stopPropagation(),this.hide())};this.handleMouseOver=()=>{if(this.hasTrigger("hover")){let o=h(getComputedStyle(this).getPropertyValue("--show-delay"));clearTimeout(this.hoverTimeout),this.hoverTimeout=window.setTimeout(()=>this.show(),o)}};this.handleMouseOut=()=>{if(this.hasTrigger("hover")){let o=h(getComputedStyle(this).getPropertyValue("--hide-delay"));clearTimeout(this.hoverTimeout),this.hoverTimeout=window.setTimeout(()=>this.hide(),o)}};this.addEventListener("click",this.handleClick),this.addEventListener("focus",this.handleFocus,!0),this.addEventListener("blur",this.handleBlur,!0),this.addEventListener("mouseover",this.handleMouseOver),this.addEventListener("mouseout",this.handleMouseOut)}disconnectedCallback(){super.disconnectedCallback(),this.closeWatcher?.destroy(),document.removeEventListener("keydown",this.handleDocumentKeyDown)}firstUpdated(){this.body.hidden=!this.open,this.open&&(this.popup.active=!0,this.popup.reposition())}hasTrigger(o){return this.trigger.split(" ").includes(o)}async handleOpenChange(){if(this.open){if(this.disabled)return;let o=new k;if(this.dispatchEvent(o),o.defaultPrevented){this.open=!1;return}"CloseWatcher"in window?(this.closeWatcher?.destroy(),this.closeWatcher=new CloseWatcher,this.closeWatcher.onclose=()=>{this.hide()}):document.addEventListener("keydown",this.handleDocumentKeyDown),await d(this.body),this.body.hidden=!1,this.popup.active=!0;let{keyframes:s,options:n}=c(this,"tooltip.show",{dir:this.localize.dir()});await p(this.popup.popup,s,n),this.popup.reposition(),this.dispatchEvent(new b)}else{let o=new E;if(this.dispatchEvent(o),o.defaultPrevented){this.open=!0;return}this.closeWatcher?.destroy(),document.removeEventListener("keydown",this.handleDocumentKeyDown),await d(this.body);let{keyframes:s,options:n}=c(this,"tooltip.hide",{dir:this.localize.dir()});await p(this.popup.popup,s,n),this.popup.active=!1,this.body.hidden=!0,this.dispatchEvent(new w)}}async handleOptionsChange(){this.hasUpdated&&(await this.updateComplete,this.popup.reposition())}handleDisabledChange(){this.disabled&&this.open&&this.hide()}async show(){if(!this.open)return this.open=!0,u(this,"pc-after-show")}async hide(){if(this.open)return this.open=!1,u(this,"pc-after-hide")}render(){return m`
            <pc-popup
                part="base"
                class=${y({tooltip:!0,open:this.open})}
                placement=${this.placement}
                distance=${this.distance}
                skidding=${this.skidding}
                flip=""
                shift=""
                arrow=""
                hover-bridge=""
                exportparts="popup:base-popup, arrow:base__arrow"
            >
                <slot slot="anchor" aria-describedby="tooltip"></slot>

                <div
                    part="body"
                    class="body"
                    id="tooltip"
                    role="tooltip"
                    aria-live=${this.open?"polite":"off"}
                >
                    <slot name="content">${this.content}</slot>
                </div>
            </pc-popup>
        `}};t.css=C,e([r("slot:not([name])")],t.prototype,"defaultSlot",2),e([r(".body")],t.prototype,"body",2),e([r("pc-popup")],t.prototype,"popup",2),e([i()],t.prototype,"content",2),e([i()],t.prototype,"placement",2),e([i({type:Boolean})],t.prototype,"disabled",2),e([i({type:Number})],t.prototype,"distance",2),e([i({type:Boolean,reflect:!0})],t.prototype,"open",2),e([i({type:Number})],t.prototype,"skidding",2),e([i()],t.prototype,"trigger",2),e([a("open",{waitUntilFirstUpdate:!0})],t.prototype,"handleOpenChange",1),e([a(["content","distance","placement","skidding"])],t.prototype,"handleOptionsChange",1),e([a("disabled")],t.prototype,"handleDisabledChange",1),t=e([f("pc-tooltip")],t);export{t as a};
