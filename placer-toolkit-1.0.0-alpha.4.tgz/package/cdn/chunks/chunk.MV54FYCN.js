var e="";function o(t){e=t}function i(){if(!e){let t=document.querySelector("[data-fa-kit-code]");t&&o(t.getAttribute("data-fa-kit-code")||"")}return e}export{o as a,i as b};
