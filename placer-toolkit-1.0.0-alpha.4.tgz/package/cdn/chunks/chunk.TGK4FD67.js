import{a as x}from"./chunk.GG6CNHGL.js";import{a as tt}from"./chunk.W5PM7F34.js";import{a as T}from"./chunk.RXMQHF36.js";import{a as _}from"./chunk.BSQP4EKW.js";import{a as M}from"./chunk.OVU4POJI.js";import{a as it}from"./chunk.Y452TQZB.js";import{a as rt}from"./chunk.OOPBLVP2.js";import{a as st}from"./chunk.OMC4FRTB.js";import{a as at}from"./chunk.GFCFF7RE.js";import{a as L}from"./chunk.RZZMGXAZ.js";import{a as P}from"./chunk.43BYYM5E.js";import{a as g}from"./chunk.ZS4GILCB.js";import{a as N}from"./chunk.OOQOIJSK.js";import{a as R}from"./chunk.ZLITPNV3.js";import{a as Q}from"./chunk.AGGS6MN5.js";import{a as F}from"./chunk.NOX5TXXZ.js";import{a as J}from"./chunk.UPTMZCQ7.js";import{a as W,b as d,c as w,d as Z,e as $}from"./chunk.PLBYMK2K.js";import{d as y}from"./chunk.FKNAQN55.js";import{a as H}from"./chunk.H2EOXVSZ.js";import{a as B,c as K}from"./chunk.N5AZOOIZ.js";import{a as et}from"./chunk.TBG3XWQL.js";import{b as l}from"./chunk.E6MOE4FE.js";function c(r,e){bt(r)&&(r="100%");let t=gt(r);return r=e===360?r:Math.min(e,Math.max(0,parseFloat(r))),t&&(r=parseInt(String(r*e),10)/100),Math.abs(r-e)<1e-6?1:(e===360?r=(r<0?r%e+e:r%e)/parseFloat(String(e)):r=r%e/parseFloat(String(e)),r)}function D(r){return Math.min(1,Math.max(0,r))}function bt(r){return typeof r=="string"&&r.indexOf(".")!==-1&&parseFloat(r)===1}function gt(r){return typeof r=="string"&&r.indexOf("%")!==-1}function C(r){return r=parseFloat(r),(isNaN(r)||r<0||r>1)&&(r=1),r}function A(r){return Number(r)<=1?`${Number(r)*100}%`:r}function k(r){return r.length===1?"0"+r:String(r)}function nt(r,e,t){return{r:c(r,255)*255,g:c(e,255)*255,b:c(t,255)*255}}function O(r,e,t){r=c(r,255),e=c(e,255),t=c(t,255);let i=Math.max(r,e,t),s=Math.min(r,e,t),a=0,n=0,o=(i+s)/2;if(i===s)n=0,a=0;else{let p=i-s;switch(n=o>.5?p/(2-i-s):p/(i+s),i){case r:a=(e-t)/p+(e<t?6:0);break;case e:a=(t-r)/p+2;break;case t:a=(r-e)/p+4;break;default:break}a/=6}return{h:a,s:n,l:o}}function q(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+(e-r)*(6*t):t<1/2?e:t<2/3?r+(e-r)*(2/3-t)*6:r}function ot(r,e,t){let i,s,a;if(r=c(r,360),e=c(e,100),t=c(t,100),e===0)s=t,a=t,i=t;else{let n=t<.5?t*(1+e):t+e-t*e,o=2*t-n;i=q(o,n,r+1/3),s=q(o,n,r),a=q(o,n,r-1/3)}return{r:i*255,g:s*255,b:a*255}}function U(r,e,t){r=c(r,255),e=c(e,255),t=c(t,255);let i=Math.max(r,e,t),s=Math.min(r,e,t),a=0,n=i,o=i-s,p=i===0?0:o/i;if(i===s)a=0;else{switch(i){case r:a=(e-t)/o+(e<t?6:0);break;case e:a=(t-r)/o+2;break;case t:a=(r-e)/o+4;break;default:break}a/=6}return{h:a,s:p,v:n}}function ht(r,e,t){r=c(r,360)*6,e=c(e,100),t=c(t,100);let i=Math.floor(r),s=r-i,a=t*(1-e),n=t*(1-s*e),o=t*(1-(1-s)*e),p=i%6,b=[t,n,a,a,o,t][p],u=[o,t,t,n,a,a][p],S=[a,a,o,t,t,n][p];return{r:b*255,g:u*255,b:S*255}}function Y(r,e,t,i){let s=[k(Math.round(r).toString(16)),k(Math.round(e).toString(16)),k(Math.round(t).toString(16))];return i&&s[0].startsWith(s[0].charAt(1))&&s[1].startsWith(s[1].charAt(1))&&s[2].startsWith(s[2].charAt(1))?s[0].charAt(0)+s[1].charAt(0)+s[2].charAt(0):s.join("")}function lt(r,e,t,i,s){let a=[k(Math.round(r).toString(16)),k(Math.round(e).toString(16)),k(Math.round(t).toString(16)),k(mt(i))];return s&&a[0].startsWith(a[0].charAt(1))&&a[1].startsWith(a[1].charAt(1))&&a[2].startsWith(a[2].charAt(1))&&a[3].startsWith(a[3].charAt(1))?a[0].charAt(0)+a[1].charAt(0)+a[2].charAt(0)+a[3].charAt(0):a.join("")}function ut(r,e,t,i){let s=r/100,a=e/100,n=t/100,o=i/100,p=255*(1-s)*(1-o),b=255*(1-a)*(1-o),u=255*(1-n)*(1-o);return{r:p,g:b,b:u}}function j(r,e,t){let i=1-r/255,s=1-e/255,a=1-t/255,n=Math.min(i,s,a);return n===1?(i=0,s=0,a=0):(i=(i-n)/(1-n)*100,s=(s-n)/(1-n)*100,a=(a-n)/(1-n)*100),n*=100,{c:Math.round(i),m:Math.round(s),y:Math.round(a),k:Math.round(n)}}function mt(r){return Math.round(parseFloat(r)*255).toString(16)}function G(r){return f(r)/255}function f(r){return parseInt(r,16)}function pt(r){return{r:r>>16,g:(r&65280)>>8,b:r&255}}var z={aliceblue:"#f0f8ff",antiquewhite:"#faebd7",aqua:"#00ffff",aquamarine:"#7fffd4",azure:"#f0ffff",beige:"#f5f5dc",bisque:"#ffe4c4",black:"#000000",blanchedalmond:"#ffebcd",blue:"#0000ff",blueviolet:"#8a2be2",brown:"#a52a2a",burlywood:"#deb887",cadetblue:"#5f9ea0",chartreuse:"#7fff00",chocolate:"#d2691e",coral:"#ff7f50",cornflowerblue:"#6495ed",cornsilk:"#fff8dc",crimson:"#dc143c",cyan:"#00ffff",darkblue:"#00008b",darkcyan:"#008b8b",darkgoldenrod:"#b8860b",darkgray:"#a9a9a9",darkgreen:"#006400",darkgrey:"#a9a9a9",darkkhaki:"#bdb76b",darkmagenta:"#8b008b",darkolivegreen:"#556b2f",darkorange:"#ff8c00",darkorchid:"#9932cc",darkred:"#8b0000",darksalmon:"#e9967a",darkseagreen:"#8fbc8f",darkslateblue:"#483d8b",darkslategray:"#2f4f4f",darkslategrey:"#2f4f4f",darkturquoise:"#00ced1",darkviolet:"#9400d3",deeppink:"#ff1493",deepskyblue:"#00bfff",dimgray:"#696969",dimgrey:"#696969",dodgerblue:"#1e90ff",firebrick:"#b22222",floralwhite:"#fffaf0",forestgreen:"#228b22",fuchsia:"#ff00ff",gainsboro:"#dcdcdc",ghostwhite:"#f8f8ff",goldenrod:"#daa520",gold:"#ffd700",gray:"#808080",green:"#008000",greenyellow:"#adff2f",grey:"#808080",honeydew:"#f0fff0",hotpink:"#ff69b4",indianred:"#cd5c5c",indigo:"#4b0082",ivory:"#fffff0",khaki:"#f0e68c",lavenderblush:"#fff0f5",lavender:"#e6e6fa",lawngreen:"#7cfc00",lemonchiffon:"#fffacd",lightblue:"#add8e6",lightcoral:"#f08080",lightcyan:"#e0ffff",lightgoldenrodyellow:"#fafad2",lightgray:"#d3d3d3",lightgreen:"#90ee90",lightgrey:"#d3d3d3",lightpink:"#ffb6c1",lightsalmon:"#ffa07a",lightseagreen:"#20b2aa",lightskyblue:"#87cefa",lightslategray:"#778899",lightslategrey:"#778899",lightsteelblue:"#b0c4de",lightyellow:"#ffffe0",lime:"#00ff00",limegreen:"#32cd32",linen:"#faf0e6",magenta:"#ff00ff",maroon:"#800000",mediumaquamarine:"#66cdaa",mediumblue:"#0000cd",mediumorchid:"#ba55d3",mediumpurple:"#9370db",mediumseagreen:"#3cb371",mediumslateblue:"#7b68ee",mediumspringgreen:"#00fa9a",mediumturquoise:"#48d1cc",mediumvioletred:"#c71585",midnightblue:"#191970",mintcream:"#f5fffa",mistyrose:"#ffe4e1",moccasin:"#ffe4b5",navajowhite:"#ffdead",navy:"#000080",oldlace:"#fdf5e6",olive:"#808000",olivedrab:"#6b8e23",orange:"#ffa500",orangered:"#ff4500",orchid:"#da70d6",palegoldenrod:"#eee8aa",palegreen:"#98fb98",paleturquoise:"#afeeee",palevioletred:"#db7093",papayawhip:"#ffefd5",peachpuff:"#ffdab9",peru:"#cd853f",pink:"#ffc0cb",plum:"#dda0dd",powderblue:"#b0e0e6",purple:"#800080",rebeccapurple:"#663399",red:"#ff0000",rosybrown:"#bc8f8f",royalblue:"#4169e1",saddlebrown:"#8b4513",salmon:"#fa8072",sandybrown:"#f4a460",seagreen:"#2e8b57",seashell:"#fff5ee",sienna:"#a0522d",silver:"#c0c0c0",skyblue:"#87ceeb",slateblue:"#6a5acd",slategray:"#708090",slategrey:"#708090",snow:"#fffafa",springgreen:"#00ff7f",steelblue:"#4682b4",tan:"#d2b48c",teal:"#008080",thistle:"#d8bfd8",tomato:"#ff6347",turquoise:"#40e0d0",violet:"#ee82ee",wheat:"#f5deb3",white:"#ffffff",whitesmoke:"#f5f5f5",yellow:"#ffff00",yellowgreen:"#9acd32"};function ct(r){let e={r:0,g:0,b:0},t=1,i=null,s=null,a=null,n=!1,o=!1;return typeof r=="string"&&(r=wt(r)),typeof r=="object"&&(m(r.r)&&m(r.g)&&m(r.b)?(e=nt(r.r,r.g,r.b),n=!0,o=String(r.r).substr(-1)==="%"?"prgb":"rgb"):m(r.h)&&m(r.s)&&m(r.v)?(i=A(r.s),s=A(r.v),e=ht(r.h,i,s),n=!0,o="hsv"):m(r.h)&&m(r.s)&&m(r.l)?(i=A(r.s),a=A(r.l),e=ot(r.h,i,a),n=!0,o="hsl"):m(r.c)&&m(r.m)&&m(r.y)&&m(r.k)&&(e=ut(r.c,r.m,r.y,r.k),n=!0,o="cmyk"),Object.prototype.hasOwnProperty.call(r,"a")&&(t=r.a)),t=C(t),{ok:n,format:r.format||o,r:Math.min(255,Math.max(e.r,0)),g:Math.min(255,Math.max(e.g,0)),b:Math.min(255,Math.max(e.b,0)),a:t}}var vt="[-\\+]?\\d+%?",yt="[-\\+]?\\d*\\.\\d+%?",E="(?:"+yt+")|(?:"+vt+")",X="[\\s|\\(]+("+E+")[,|\\s]+("+E+")[,|\\s]+("+E+")\\s*\\)?",I="[\\s|\\(]+("+E+")[,|\\s]+("+E+")[,|\\s]+("+E+")[,|\\s]+("+E+")\\s*\\)?",v={CSS_UNIT:new RegExp(E),rgb:new RegExp("rgb"+X),rgba:new RegExp("rgba"+I),hsl:new RegExp("hsl"+X),hsla:new RegExp("hsla"+I),hsv:new RegExp("hsv"+X),hsva:new RegExp("hsva"+I),cmyk:new RegExp("cmyk"+I),hex3:/^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,hex6:/^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,hex4:/^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,hex8:/^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/};function wt(r){if(r=r.trim().toLowerCase(),r.length===0)return!1;let e=!1;if(z[r])r=z[r],e=!0;else if(r==="transparent")return{r:0,g:0,b:0,a:0,format:"name"};let t=v.rgb.exec(r);return t?{r:t[1],g:t[2],b:t[3]}:(t=v.rgba.exec(r),t?{r:t[1],g:t[2],b:t[3],a:t[4]}:(t=v.hsl.exec(r),t?{h:t[1],s:t[2],l:t[3]}:(t=v.hsla.exec(r),t?{h:t[1],s:t[2],l:t[3],a:t[4]}:(t=v.hsv.exec(r),t?{h:t[1],s:t[2],v:t[3]}:(t=v.hsva.exec(r),t?{h:t[1],s:t[2],v:t[3],a:t[4]}:(t=v.cmyk.exec(r),t?{c:t[1],m:t[2],y:t[3],k:t[4]}:(t=v.hex8.exec(r),t?{r:f(t[1]),g:f(t[2]),b:f(t[3]),a:G(t[4]),format:e?"name":"hex8"}:(t=v.hex6.exec(r),t?{r:f(t[1]),g:f(t[2]),b:f(t[3]),format:e?"name":"hex"}:(t=v.hex4.exec(r),t?{r:f(t[1]+t[1]),g:f(t[2]+t[2]),b:f(t[3]+t[3]),a:G(t[4]+t[4]),format:e?"name":"hex8"}:(t=v.hex3.exec(r),t?{r:f(t[1]+t[1]),g:f(t[2]+t[2]),b:f(t[3]+t[3]),format:e?"name":"hex"}:!1))))))))))}function m(r){return typeof r=="number"?!Number.isNaN(r):v.CSS_UNIT.test(r)}var V=class r{constructor(e="",t={}){if(e instanceof r)return e;typeof e=="number"&&(e=pt(e)),this.originalInput=e;let i=ct(e);this.originalInput=e,this.r=i.r,this.g=i.g,this.b=i.b,this.a=i.a,this.roundA=Math.round(100*this.a)/100,this.format=t.format??i.format,this.gradientType=t.gradientType,this.r<1&&(this.r=Math.round(this.r)),this.g<1&&(this.g=Math.round(this.g)),this.b<1&&(this.b=Math.round(this.b)),this.isValid=i.ok}isDark(){return this.getBrightness()<128}isLight(){return!this.isDark()}getBrightness(){let e=this.toRgb();return(e.r*299+e.g*587+e.b*114)/1e3}getLuminance(){let e=this.toRgb(),t,i,s,a=e.r/255,n=e.g/255,o=e.b/255;return a<=.03928?t=a/12.92:t=Math.pow((a+.055)/1.055,2.4),n<=.03928?i=n/12.92:i=Math.pow((n+.055)/1.055,2.4),o<=.03928?s=o/12.92:s=Math.pow((o+.055)/1.055,2.4),.2126*t+.7152*i+.0722*s}getAlpha(){return this.a}setAlpha(e){return this.a=C(e),this.roundA=Math.round(100*this.a)/100,this}isMonochrome(){let{s:e}=this.toHsl();return e===0}toHsv(){let e=U(this.r,this.g,this.b);return{h:e.h*360,s:e.s,v:e.v,a:this.a}}toHsvString(){let e=U(this.r,this.g,this.b),t=Math.round(e.h*360),i=Math.round(e.s*100),s=Math.round(e.v*100);return this.a===1?`hsv(${t}, ${i}%, ${s}%)`:`hsva(${t}, ${i}%, ${s}%, ${this.roundA})`}toHsl(){let e=O(this.r,this.g,this.b);return{h:e.h*360,s:e.s,l:e.l,a:this.a}}toHslString(){let e=O(this.r,this.g,this.b),t=Math.round(e.h*360),i=Math.round(e.s*100),s=Math.round(e.l*100);return this.a===1?`hsl(${t}, ${i}%, ${s}%)`:`hsla(${t}, ${i}%, ${s}%, ${this.roundA})`}toHex(e=!1){return Y(this.r,this.g,this.b,e)}toHexString(e=!1){return"#"+this.toHex(e)}toHex8(e=!1){return lt(this.r,this.g,this.b,this.a,e)}toHex8String(e=!1){return"#"+this.toHex8(e)}toHexShortString(e=!1){return this.a===1?this.toHexString(e):this.toHex8String(e)}toRgb(){return{r:Math.round(this.r),g:Math.round(this.g),b:Math.round(this.b),a:this.a}}toRgbString(){let e=Math.round(this.r),t=Math.round(this.g),i=Math.round(this.b);return this.a===1?`rgb(${e}, ${t}, ${i})`:`rgba(${e}, ${t}, ${i}, ${this.roundA})`}toPercentageRgb(){let e=t=>`${Math.round(c(t,255)*100)}%`;return{r:e(this.r),g:e(this.g),b:e(this.b),a:this.a}}toPercentageRgbString(){let e=t=>Math.round(c(t,255)*100);return this.a===1?`rgb(${e(this.r)}%, ${e(this.g)}%, ${e(this.b)}%)`:`rgba(${e(this.r)}%, ${e(this.g)}%, ${e(this.b)}%, ${this.roundA})`}toCmyk(){return{...j(this.r,this.g,this.b)}}toCmykString(){let{c:e,m:t,y:i,k:s}=j(this.r,this.g,this.b);return`cmyk(${e}, ${t}, ${i}, ${s})`}toName(){if(this.a===0)return"transparent";if(this.a<1)return!1;let e="#"+Y(this.r,this.g,this.b,!1);for(let[t,i]of Object.entries(z))if(e===i)return t;return!1}toString(e){let t=!!e;e=e??this.format;let i=!1,s=this.a<1&&this.a>=0;return!t&&s&&(e.startsWith("hex")||e==="name")?e==="name"&&this.a===0?this.toName():this.toRgbString():(e==="rgb"&&(i=this.toRgbString()),e==="prgb"&&(i=this.toPercentageRgbString()),(e==="hex"||e==="hex6")&&(i=this.toHexString()),e==="hex3"&&(i=this.toHexString(!0)),e==="hex4"&&(i=this.toHex8String(!0)),e==="hex8"&&(i=this.toHex8String()),e==="name"&&(i=this.toName()),e==="hsl"&&(i=this.toHslString()),e==="hsv"&&(i=this.toHsvString()),e==="cmyk"&&(i=this.toCmykString()),i||this.toHexString())}toNumber(){return(Math.round(this.r)<<16)+(Math.round(this.g)<<8)+Math.round(this.b)}clone(){return new r(this.toString())}lighten(e=10){let t=this.toHsl();return t.l+=e/100,t.l=D(t.l),new r(t)}brighten(e=10){let t=this.toRgb();return t.r=Math.max(0,Math.min(255,t.r-Math.round(255*-(e/100)))),t.g=Math.max(0,Math.min(255,t.g-Math.round(255*-(e/100)))),t.b=Math.max(0,Math.min(255,t.b-Math.round(255*-(e/100)))),new r(t)}darken(e=10){let t=this.toHsl();return t.l-=e/100,t.l=D(t.l),new r(t)}tint(e=10){return this.mix("white",e)}shade(e=10){return this.mix("black",e)}desaturate(e=10){let t=this.toHsl();return t.s-=e/100,t.s=D(t.s),new r(t)}saturate(e=10){let t=this.toHsl();return t.s+=e/100,t.s=D(t.s),new r(t)}greyscale(){return this.desaturate(100)}spin(e){let t=this.toHsl(),i=(t.h+e)%360;return t.h=i<0?360+i:i,new r(t)}mix(e,t=50){let i=this.toRgb(),s=new r(e).toRgb(),a=t/100,n={r:(s.r-i.r)*a+i.r,g:(s.g-i.g)*a+i.g,b:(s.b-i.b)*a+i.b,a:(s.a-i.a)*a+i.a};return new r(n)}analogous(e=6,t=30){let i=this.toHsl(),s=360/t,a=[this];for(i.h=(i.h-(s*e>>1)+720)%360;--e;)i.h=(i.h+s)%360,a.push(new r(i));return a}complement(){let e=this.toHsl();return e.h=(e.h+180)%360,new r(e)}monochromatic(e=6){let t=this.toHsv(),{h:i}=t,{s}=t,{v:a}=t,n=[],o=1/e;for(;e--;)n.push(new r({h:i,s,v:a})),a=(a+o)%1;return n}splitcomplement(){let e=this.toHsl(),{h:t}=e;return[this,new r({h:(t+72)%360,s:e.s,l:e.l}),new r({h:(t+216)%360,s:e.s,l:e.l})]}onBackground(e){let t=this.toRgb(),i=new r(e).toRgb(),s=t.a+i.a*(1-t.a);return new r({r:(t.r*t.a+i.r*i.a*(1-t.a))/s,g:(t.g*t.a+i.g*i.a*(1-t.a))/s,b:(t.b*t.a+i.b*i.a*(1-t.a))/s,a:s})}triad(){return this.polyad(3)}tetrad(){return this.polyad(4)}polyad(e){let t=this.toHsl(),{h:i}=t,s=[this],a=360/e;for(let n=1;n<e;n++)s.push(new r({h:(i+n*a)%360,s:t.s,l:t.l}));return s}equals(e){let t=new r(e);return this.format==="cmyk"||t.format==="cmyk"?this.toCmykString()===t.toCmykString():this.toRgbString()===t.toRgbString()}};var dt=`:host {
    --grid-width: 17em;
    --grid-height: 12em;
    --grid-handle-size: 1.25em;
    --slider-height: 1em;
    --slider-thumb-size: calc(var(--slider-height) + 0.25em);
    --swatch-size: 1.5em;
}

.color-picker {
    inline-size: var(--grid-width);
    background-color: var(--pc-color-surface-raised);
    color: var(--pc-color-text-normal);
    border: var(--pc-border-width-s) var(--pc-border-style)
        var(--pc-color-surface-border);
    border-radius: var(--pc-border-radius-l);
    font-family: var(--pc-font-sans);
    font-size: inherit;
    font-weight: var(--pc-font-weight-normal);
    user-select: none;
    -webkit-user-select: none;
}

.color-picker.inline {
    border: var(--pc-border-width-s) var(--pc-border-style)
        var(--pc-color-surface-border);
}

.color-picker.inline:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.color-picker.inline .label,
.color-picker.inline .label * {
    display: inline;
    position: absolute !important;
    margin: -1px !important;
    padding: 0 !important;
    inline-size: 1px !important;
    block-size: 1px !important;
    width: 1px !important;
    height: 1px !important;
    clip-path: inset(50%) !important;
    border: none !important;
    overflow: hidden !important;
    white-space: nowrap !important;
}

.grid {
    position: relative;
    block-size: var(--grid-height);
    background-image:
        linear-gradient(to bottom, rgb(0 0 0 / 0%) 0%, rgb(0 0 0 / 100%) 100%),
        linear-gradient(
            to right,
            rgb(255 255 255 / 100%) 0%,
            rgb(255 255 255 / 0%) 100%
        );
    border-start-start-radius: var(--pc-border-radius-l);
    border-start-end-radius: var(--pc-border-radius-l);
    cursor: crosshair;
    forced-color-adjust: none;
}

.grid-handle {
    position: absolute;
    margin-top: calc(var(--grid-handle-size) / -2);
    margin-left: calc(var(--grid-handle-size) / -2);
    inline-size: var(--grid-handle-size);
    block-size: var(--grid-handle-size);
    border: var(--pc-border-width-m) var(--pc-border-style)
        var(--pc-color-neutral-95);
    border-radius: var(--pc-border-radius-circle);
    box-shadow: 0 0 0 var(--pc-border-width-s)
        color-mix(in oklab, var(--pc-color-neutral-05) 25%, transparent);
    z-index: 1;
    transition: scale var(--pc-transition-fast) ease-in-out;
}

.grid-handle.dragging {
    scale: 1.5;
    cursor: none;
}

.grid-handle:focus-visible {
    outline: var(--pc-focus-ring);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.controls {
    display: flex;
    align-items: center;
    padding: var(--pc-spacing-m);
}

.sliders {
    flex: 1 1 auto;
}

.slider {
    position: relative;
    block-size: var(--slider-height);
    border-radius: var(--pc-border-radius-pill);
    box-shadow: inset 0 0 0 var(--pc-border-style)
        color-mix(in oklab, var(--pc-color-neutral-05) 20%, transparent);
    forced-color-adjust: none;
}

.slider:not(:last-of-type) {
    margin-block-end: var(--pc-spacing-s);
}

.slider .slider-thumb {
    position: absolute;
    top: calc(50% - var(--slider-thumb-size) / 2);
    margin-left: calc(var(--slider-thumb-size) / -2);
    inline-size: var(--slider-thumb-size);
    block-size: var(--slider-thumb-size);
    background-color: var(--pc-color-neutral-95);
    border-radius: var(--pc-border-radius-circle);
    box-shadow: color-mix(
        in oklab,
        var(--pc-color-neutral-05) 25%,
        transparent
    );
}

.slider .slider-thumb:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.hue-slider {
    background-image: linear-gradient(
        to right,
        hsl(0 100% 50%) 0%,
        hsl(60 100% 50%) 16.7%,
        hsl(120 100% 50%) 33.3%,
        hsl(180 100% 50%) 50%,
        hsl(240 100% 50%) 66.7%,
        hsl(300 100% 50%) 83.3%,
        hsl(360 100% 50%) 100%
    );
}

.alpha-slider .alpha-gradient {
    position: absolute;
    top: 0;
    left: 0;
    inline-size: 100%;
    block-size: 100%;
    border-radius: inherit;
}

.preview {
    display: inline-flex;
    position: relative;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    margin-inline-start: var(--pc-spacing-m);
    inline-size: 2.25rem;
    block-size: 2.25rem;
    background-color: transparent;
    border: none;
    border-radius: var(--pc-border-radius-circle);
    forced-color-adjust: none;
}

.preview::before {
    content: "";
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    inline-size: 100%;
    block-size: 100%;
    background-color: var(--preview-color);
    border-radius: inherit;
    box-shadow: inset 0 0 0 var(--pc-border-width-s)
        color-mix(in oklab, var(--pc-color-neutral-05) 20%, transparent);
}

.user-input {
    display: flex;
    padding-inline: var(--pc-spacing-m);
    padding-block-start: 0;
    padding-block-end: var(--pc-spacing-m);
}

.user-input pc-input {
    flex: 1 1 auto;
    min-inline-size: 0;
}

.user-input pc-input::part(input) {
    padding-inline-end: var(--pc-spacing-xxs);
    background-color: var(--pc-color-surface-raised);
    overflow: visible;
}

/* Bug: This does not remove the focus ring for some reason. */
.user-input pc-input:has(> pc-copy-button:focus-visible)::part(form-control) {
    outline: none;
}

.user-input pc-input pc-copy-button {
    margin-inline-start: var(--pc-spacing-xs);
}

.user-input pc-input.empty::part(input) {
    padding-inline-end: var(--pc-form-control-padding-inline);
}

.user-input pc-input.empty pc-copy-button {
    display: none;
}

.user-input pc-copy-button::part(button) {
    aspect-ratio: 1 / 1;
    background-color: transparent;
    color: var(--pc-color-text-normal);
}

.user-input pc-copy-button::part(success-icon) {
    color: var(--pc-color-success-on-quiet);
}

.user-input pc-copy-button::part(error-icon) {
    color: var(--pc-color-danger-on-quiet);
}

@media (hover: hover) {
    .user-input pc-copy-button::part(button):hover {
        color: color-mix(
            in oklab,
            var(--pc-color-text-normal),
            var(--pc-color-mix-hover)
        );
    }
}

.user-input pc-copy-button::part(button):active {
    color: color-mix(
        in oklab,
        var(--pc-color-text-normal),
        var(--pc-color-mix-active)
    );
}

.user-input pc-button-group {
    margin-inline-start: var(--pc-spacing-s);
}

.user-input pc-button:first-of-type {
    min-inline-size: 3.25em;
    max-inline-size: 3.25em;
}

.swatches {
    display: grid;
    justify-items: center;
    grid-template-columns: repeat(8, 1fr);
    gap: var(--pc-spacing-s);
    padding: var(--pc-spacing-m);
    border-block-start: var(--pc-border-width-s) var(--pc-border-style)
        var(--pc-color-surface-border);
}

.swatches .swatch {
    position: relative;
    inline-size: var(--swatch-size);
    block-size: var(--swatch-size);
    border-radius: var(--pc-border-radius-circle);
    forced-color-adjust: none;
}

.swatches .swatch:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.swatches .swatch .swatch-color {
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    inline-size: 100%;
    block-size: 100%;
    border: var(--pc-border-width-s) var(--pc-border-style)
        color-mix(in oklab, var(--pc-color-neutral-05) 20%, transparent);
    box-shadow: inset 0 0 0 var(--pc-border-width-s)
        color-mix(in oklab, var(--pc-color-neutral-05) 20%, transparent);
    border-radius: inherit;
    cursor: pointer;
}

.pixel-background {
    background-image: conic-gradient(
        var(--pc-color-neutral-fill-normal) 25%,
        transparent 0 50%,
        var(--pc-color-neutral-fill-normal) 0 75%,
        transparent 0
    );
    background-size: 0.5rem 0.5rem;
    background-position:
        0 0,
        0 0,
        -0.25rem -0.25rem,
        0.25rem 0.25rem;
}

.color-picker.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.color-picker.disabled .grid,
.color-picker.disabled .grid-handle,
.color-picker.disabled .sliders .slider,
.color-picker.disabled .sliders .slider .slider-thumb,
.color-picker.disabled .preview,
.color-picker.disabled .swatches .swatch,
.color-picker.disabled .swatches .swatch .swatch-color {
    pointer-events: none;
}

.color-popup::part(popup) {
    max-block-size: none;
    overflow: visible;
}

.popup-trigger {
    display: inline-block;
    position: relative;
    inline-size: var(--pc-form-control-height);
    block-size: var(--pc-form-control-height);
    background-color: transparent;
    border: none;
    border-radius: var(--pc-border-radius-m);
    font-size: inherit;
    cursor: pointer;
    forced-color-adjust: none;
}

.popup-trigger::before {
    content: "";
    position: absolute;
    inset-block-start: 0;
    inset-inline-end: 0;
    inline-size: 100%;
    block-size: 100%;
    border-radius: inherit;
    background-color: currentColor;
    box-shadow:
        inset 0 0 0 var(--pc-border-width-m) var(--pc-color-surface-border),
        inset 0 0 0 var(--pc-border-width-xl) var(--pc-color-surface-default);
}

.popup-trigger.empty::before {
    background-color: transparent;
}

.popup-trigger:focus-visible {
    outline: none;
}

.popup-trigger:focus-visible:not([disabled]) {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.popup-trigger[disabled] {
    opacity: 0.5;
    cursor: not-allowed;
}

.color-popup[data-current-placement^="top"]::part(popup) {
    transform-origin: bottom;
}

.color-popup[data-current-placement^="bottom"]::part(popup) {
    transform-origin: top;
}

.color-popup[data-current-placement^="left"]::part(popup) {
    transform-origin: right;
}

.color-popup[data-current-placement^="right"]::part(popup) {
    transform-origin: left;
}

.color-popup[data-current-placement="left-start"]::part(popup) {
    transform-origin: right top;
}

.color-popup[data-current-placement="left-end"]::part(popup) {
    transform-origin: right bottom;
}

.color-popup[data-current-placement="right-start"]::part(popup) {
    transform-origin: left top;
}

.color-popup[data-current-placement="right-end"]::part(popup) {
    transform-origin: left bottom;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;B("colorPicker.show",{keyframes:[{offset:0,opacity:0,transform:"scaleY(0.35) scaleX(0.95) translateY(-10px) rotate(1deg)"},{offset:.25,opacity:1,transform:"scaleY(1.03) scaleX(1.005) translateY(2px) rotate(-0.5deg)"},{offset:.5,transform:"scaleY(0.995) scaleX(0.999) translateY(-0.5px) rotate(0.1deg)"},{offset:.75,transform:"scaleY(1.002) scaleX(1.0005) translateY(0.2px) rotate(-0.05deg)"},{offset:1,opacity:1,transform:"scaleY(1) scaleX(1) translateY(0) rotate(0deg)"}],options:{duration:1e3,easing:"cubic-bezier(0.2, 0.8, 0.2, 1)",fill:"forwards"}});B("colorPicker.hide",{keyframes:[{offset:0,opacity:1,transform:"scaleY(1) scaleX(1) translateY(0) rotate(0deg)"},{offset:.15,transform:"scaleY(1.005) scaleX(1.001) translateY(0.5px) rotate(-0.002deg)"},{offset:.4,transform:"scaleY(0.99) scaleX(0.998) translateY(-1px) rotate(0.008deg)"},{offset:.75,transform:"scaleY(0.6) scaleX(0.9) translateY(10px) rotate(0.007deg)"},{offset:1,opacity:0,transform:"scaleY(0.3) scaleX(0.8) translateY(25px) rotate(0.01deg)"}],options:{duration:400,easing:"cubic-bezier(0.6, 0.05, 0.8, 0.2)",fill:"forwards"}});var h=class extends F{constructor(){super();this.hasSlotController=new Q(this,"label","hint");this.localize=new et(this);this.isSafeValue=!1;this.hasFocus=!1;this.hasEyeDropper=!1;this.isDraggingGridHandle=!1;this.isEmpty=!1;this.inputValue="";this.hue=0;this.saturation=100;this.brightness=100;this.alpha=100;this._value=null;this.defaultValue=this.getAttribute("value")||null;this.label="";this.hint="";this.format="hex";this.inline=!1;this.size="medium";this.noFormatToggle=!1;this.name="";this.disabled=!1;this.open=!1;this.opacity=!1;this.uppercase=!1;this.swatches="";this.required=!1;this.handleFocusIn=()=>{this.hasFocus=!0};this.handleFocusOut=()=>{this.hasFocus=!1};this.reportValidityAfterShow=()=>{this.removeEventListener("invalid",this.emitInvalid),this.reportValidity(),this.addEventListener("invalid",this.emitInvalid)};this.handleKeyDown=t=>{this.open&&t.key==="Escape"&&(t.stopPropagation(),this.hide(),this.focus())};this.handleDocumentKeyDown=t=>{if(t.key==="Escape"&&this.open){t.stopPropagation(),this.focus(),this.hide();return}t.key==="Tab"&&setTimeout(()=>{let i=this.getRootNode()instanceof ShadowRoot?document.activeElement?.shadowRoot?.activeElement:document.activeElement;(!this||i?.closest(this.tagName.toLowerCase())!==this)&&this.hide()})};this.handleDocumentMouseDown=t=>{let s=t.composedPath().some(a=>a instanceof Element&&(a.closest(".color-picker")||a===this.trigger));this&&!s&&this.hide()};this.addEventListener("focusin",this.handleFocusIn),this.addEventListener("focusout",this.handleFocusOut)}static get validators(){let t=[P()];return[...super.validators,...t]}get validationTarget(){return this.popup?.active?this.input:this.trigger}get value(){return this.valueHasChanged?this._value:this._value??this.defaultValue}set value(t){this._value!==t&&(this.valueHasChanged=!0,this._value=t)}handleFormatToggle(){let t=["hex","rgb","hsl","hsv"],i=(t.indexOf(this.format)+1)%t.length;this.format=t[i],this.setColor(this.value||""),this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}handleAlphaDrag(t){let i=this.shadowRoot.querySelector(".alpha-slider"),s=i.querySelector(".slider-thumb"),{width:a}=i.getBoundingClientRect(),n=this.value,o=this.value;s.focus(),t.preventDefault(),R(i,{onMove:p=>{this.alpha=g(p/a*100,0,100),this.syncValues(),this.value!==o&&(o=this.value,this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))},onStop:()=>{this.value!==n&&(n=this.value,this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}))},initialEvent:t})}handleHueDrag(t){let i=this.shadowRoot.querySelector(".hue-slider"),s=i.querySelector(".slider-thumb"),{width:a}=i.getBoundingClientRect(),n=this.value,o=this.value;s.focus(),t.preventDefault(),R(i,{onMove:p=>{this.hue=g(p/a*360,0,360),this.syncValues(),this.value!==o&&(o=this.value,this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))},onStop:()=>{this.value!==n&&(n=this.value,this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}))},initialEvent:t})}handleGridDrag(t){let i=this.shadowRoot.querySelector(".grid"),s=i.querySelector(".grid-handle"),{width:a,height:n}=i.getBoundingClientRect(),o=this.value,p=this.value;s.focus(),t.preventDefault(),this.isDraggingGridHandle=!0,R(i,{onMove:(b,u)=>{this.saturation=g(b/a*100,0,100),this.brightness=g(100-u/n*100,0,100),this.syncValues(),this.value!==p&&(p=this.value,this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))},onStop:()=>{this.isDraggingGridHandle=!1,this.value!==o&&(o=this.value,this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}))},initialEvent:t})}handleAlphaKeyDown(t){let i=t.shiftKey?10:1,s=this.value;t.key==="ArrowLeft"&&(t.preventDefault(),this.alpha=g(this.alpha-i,0,100),this.syncValues()),t.key==="ArrowRight"&&(t.preventDefault(),this.alpha=g(this.alpha+i,0,100),this.syncValues()),t.key==="Home"&&(t.preventDefault(),this.alpha=0,this.syncValues()),t.key==="End"&&(t.preventDefault(),this.alpha=100,this.syncValues()),this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}handleHueKeyDown(t){let i=t.shiftKey?10:1,s=this.value;t.key==="ArrowLeft"&&(t.preventDefault(),this.hue=g(this.hue-i,0,360),this.syncValues()),t.key==="ArrowRight"&&(t.preventDefault(),this.hue=g(this.hue+i,0,360),this.syncValues()),t.key==="Home"&&(t.preventDefault(),this.hue=0,this.syncValues()),t.key==="End"&&(t.preventDefault(),this.hue=360,this.syncValues()),this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}handleGridKeyDown(t){let i=t.shiftKey?10:1,s=this.value;t.key==="ArrowLeft"&&(t.preventDefault(),this.saturation=g(this.saturation-i,0,100),this.syncValues()),t.key==="ArrowRight"&&(t.preventDefault(),this.saturation=g(this.saturation+i,0,100),this.syncValues()),t.key==="ArrowUp"&&(t.preventDefault(),this.brightness=g(this.brightness+i,0,100),this.syncValues()),t.key==="ArrowDown"&&(t.preventDefault(),this.brightness=g(this.brightness-i,0,100),this.syncValues()),this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}handleInputChange(t){let i=t.target,s=this.value;t.stopPropagation(),this.input.value?(this.setColor(i.value),i.value=this.value||""):this.value="",this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}handleInputInput(t){this.updateValidity(),t.stopPropagation()}handleInputKeyDown(t){if(t.key==="Enter"){let i=this.value;this.input.value?(this.setColor(this.input.value),this.input.value=this.value||"",this.value!==i&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}),setTimeout(()=>this.input.select())):this.hue=0}}handleTouchMove(t){t.preventDefault()}parseColor(t){if(!t||t.trim()==="")return null;let i=new V(t);if(!i.isValid)return null;let s=i.toHsl(),a={h:s.h,s:s.s*100,l:s.l*100,a:s.a},n=i.toRgb(),o=i.toHexString(),p=i.toHex8String(),b=i.toHsv(),u={h:b.h,s:b.s*100,v:b.v*100,a:b.a};return{hsl:{h:a.h,s:a.s,l:a.l,string:this.setLetterCase(`hsl(${Math.round(a.h)} ${Math.round(a.s)}% ${Math.round(a.l)}%)`)},hsla:{h:a.h,s:a.s,l:a.l,a:a.a,string:this.setLetterCase(`hsl(${Math.round(a.h)} ${Math.round(a.s)}% ${Math.round(a.l)}% / ${Math.round(a.a*100)}%)`)},hsv:{h:u.h,s:u.s,v:u.v,string:this.setLetterCase(`hsv(${Math.round(u.h)} ${Math.round(u.s)}% ${Math.round(u.v)}%)`)},hsva:{h:u.h,s:u.s,v:u.v,a:u.a,string:this.setLetterCase(`hsv(${Math.round(u.h)} ${Math.round(u.s)}% ${Math.round(u.v)}% / ${Math.round(u.a*100)}%)`)},rgb:{r:n.r,g:n.g,b:n.b,string:this.setLetterCase(`rgb(${Math.round(n.r)} ${Math.round(n.g)} ${Math.round(n.b)})`)},rgba:{r:n.r,g:n.g,b:n.b,a:n.a,string:this.setLetterCase(`rgb(${Math.round(n.r)} ${Math.round(n.g)} ${Math.round(n.b)} / ${Math.round(n.a*100)}%)`)},hex:this.setLetterCase(o),hexa:this.setLetterCase(p)}}setColor(t){let i=this.parseColor(t);return i===null?!1:(this.hue=i.hsva.h,this.saturation=i.hsva.s,this.brightness=i.hsva.v,this.alpha=this.opacity?i.hsva.a*100:100,this.syncValues(),!0)}setLetterCase(t){return typeof t!="string"?"":this.uppercase?t.toUpperCase():t.toLowerCase()}async syncValues(){let t=this.parseColor(`hsva(${this.hue}, ${this.saturation}%, ${this.brightness}%, ${this.alpha/100})`);t!==null&&(this.format==="hsl"?this.inputValue=this.alpha<100?t.hsla.string:t.hsl.string:this.format==="rgb"?this.inputValue=this.alpha<100?t.rgba.string:t.rgb.string:this.format==="hsv"?this.inputValue=this.alpha<100?t.hsva.string:t.hsv.string:this.inputValue=this.alpha<100?t.hexa:t.hex,this.isSafeValue=!0,this.value=this.inputValue,await this.updateComplete,this.isSafeValue=!1)}handleEyeDropper(){if(!this.hasEyeDropper)return;new EyeDropper().open().then(i=>{let s=this.value;this.setColor(i.sRGBHex),this.value!==s&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}).catch()}selectSwatch(t){let i=this.value;this.disabled||(this.setColor(t),this.value!==i&&this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))}getHexString(t,i,s,a=100){let n=new V(`hsva(${t}, ${i}%, ${s}%, ${a/100})`);return n.isValid?n.toHex8String():""}stopNestedEventPropagation(t){t.stopImmediatePropagation()}handleFormatChange(){this.syncValues()}handleOpacityChange(){this.alpha=100}willUpdate(t){super.willUpdate(t),t.has("value")&&this.handleValueChange(t.get("value")||"",this.value||"")}handleValueChange(t,i){if(this.isEmpty=!i,i||(this.hue=0,this.saturation=0,this.brightness=100,this.alpha=100),!this.isSafeValue){let s=this.parseColor(i);s!==null?(this.inputValue=this.value||"",this.hue=s.hsva.h,this.saturation=s.hsva.s,this.brightness=s.hsva.v,this.alpha=s.hsva.a*100,this.syncValues()):this.inputValue=t??""}this.requestUpdate()}focus(t){this.inline?this.base.focus(t):this.trigger.focus(t)}blur(){let t=this.inline?this.base:this.trigger;this.hasFocus&&(t.focus({preventScroll:!0}),t.blur()),this.popup?.active&&this.hide()}getFormattedValue(t="hex"){let i=this.parseColor(`hsv(${this.hue} ${this.saturation}% ${this.brightness}% / ${this.alpha}%)`);if(i===null)return"";switch(t){case"hex":return i.hex;case"hexa":return i.hexa;case"rgb":return i.rgb.string;case"rgba":return i.rgba.string;case"hsl":return i.hsl.string;case"hsla":return i.hsla.string;case"hsv":return i.hsv.string;case"hsva":return i.hsva.string;default:return""}}reportValidity(){return!this.inline&&!this.validity.valid&&!this.open?(this.show(),this.addEventListener("pc-after-show",()=>this.reportValidityAfterShow,{once:!0}),this.disabled||this.dispatchEvent(new J),!1):super.reportValidity()}formResetCallback(){this.value=this.defaultValue,super.formResetCallback()}firstUpdated(t){super.firstUpdated(t),this.hasEyeDropper="EyeDropper"in window}handleTriggerClick(){this.open?this.hide():(this.show(),this.focus())}async handleTriggerKeyDown(t){if([" ","Enter"].includes(t.key)){t.preventDefault(),this.handleTriggerClick();return}}handleTriggerKeyUp(t){t.key===" "&&t.preventDefault()}updateAccessibleTrigger(){let t=this.trigger;t&&(t.setAttribute("aria-haspopup","true"),t.setAttribute("aria-expanded",this.open?"true":"false"))}async show(){if(!this.open)return this.open=!0,N(this,"pc-after-show")}async hide(){if(this.open)return this.open=!1,N(this,"pc-after-hide")}addOpenListeners(){this.base.addEventListener("keydown",this.handleKeyDown),document.addEventListener("keydown",this.handleDocumentKeyDown),document.addEventListener("mousedown",this.handleDocumentMouseDown)}removeOpenListeners(){this.base&&this.base.removeEventListener("keydown",this.handleKeyDown),document.removeEventListener("keydown",this.handleDocumentKeyDown),document.removeEventListener("mousedown",this.handleDocumentMouseDown)}async handleOpenChange(){if(this.disabled){this.open=!1;return}if(this.updateAccessibleTrigger(),this.open){this.dispatchEvent(new at),this.addOpenListeners(),await this.updateComplete,this.base.hidden=!1,this.popup.active=!0;let t=K(this,"colorPicker.show",{dir:this.localize.dir()});L(this.popup.popup,t.keyframes,t.options),this.dispatchEvent(new it)}else{this.dispatchEvent(new st),this.removeOpenListeners();let t=K(this,"colorPicker.hide",{dir:this.localize.dir()});await L(this.popup.popup,t.keyframes,t.options),this.base.hidden=!0,this.popup.active=!1,this.dispatchEvent(new rt)}}render(){let t=this.hasSlotController.test("label"),i=this.hasSlotController.test("hint"),s=this.label?!0:!!t,a=this.hint?!0:!!i,n=this.saturation,o=100-this.brightness,p=Array.isArray(this.swatches)?this.swatches:this.swatches.split(";").filter(u=>u.trim()!==""),b=y`
            <div
                part="base"
                class=${M({"color-picker":!0,inline:this.inline,disabled:this.disabled,focused:this.hasFocus})}
                aria-disabled=${this.disabled?"true":"false"}
                aria-labelledby="label"
                tabindex=${this.inline?"0":"-1"}
            >
                ${this.inline?y`
                          <slot class="label" name="label">
                              ${this.label}
                          </slot>
                      `:null}

                <div
                    part="grid"
                    class="grid"
                    style=${x({backgroundColor:this.getHexString(this.hue,100,100)})}
                    @pointerdown=${this.handleGridDrag}
                    @touchmove=${this.handleTouchMove}
                >
                    <span
                        part="grid-handle"
                        class=${M({"grid-handle":!0,dragging:this.isDraggingGridHandle})}
                        style=${x({top:`${o}%`,left:`${n}%`,backgroundColor:this.getHexString(this.hue,this.saturation,this.brightness,this.alpha)})}
                        role="application"
                        aria-label="HSV"
                        tabindex=${T(this.disabled?void 0:"0")}
                        @keydown=${this.handleGridKeyDown}
                    ></span>
                </div>

                <div class="controls">
                    <div class="sliders">
                        <div
                            part="slider hue-slider"
                            class="slider hue-slider"
                            @pointerdown=${this.handleHueDrag}
                            @touchmove=${this.handleTouchMove}
                        >
                            <span
                                part="slider-thumb hue-slider-thumb"
                                class="slider-thumb"
                                style=${x({left:`${this.hue===0?0:100/(360/this.hue)}%`})}
                                role="slider"
                                aria-label=${this.localize.term("hue")}
                                aria-orientation="horizontal"
                                aria-valuemin="0"
                                aria-valuemax="360"
                                aria-valuenow=${`${Math.round(this.hue)}`}
                                tabindex=${T(this.disabled?void 0:"0")}
                                @keydown=${this.handleHueKeyDown}
                            ></span>
                        </div>

                        ${this.opacity?y`
                                  <div
                                      part="slider opacity-slider"
                                      class="slider alpha-slider pixel-background"
                                      @pointerdown=${this.handleAlphaDrag}
                                      @touchmove=${this.handleTouchMove}
                                  >
                                      <div
                                          class="alpha-gradient"
                                          style=${x({backgroundImage:`
                                                  linear-gradient(
                                                      to right,
                                                      ${this.getHexString(this.hue,this.saturation,this.brightness,0)} 0%,
                                                      ${this.getHexString(this.hue,this.saturation,this.brightness,100)} 100%
                                                  )
                                              `})}
                                      ></div>
                                      <span
                                          part="slider-thumb opacity-slider-thumb"
                                          class="slider-thumb"
                                          style=${x({left:`${this.alpha}%`})}
                                          role="slider"
                                          aria-label=${this.localize.term("opacity")}
                                          aria-orientation="horizontal"
                                          aria-valuemin="0"
                                          aria-valuemax="100"
                                          aria-valuenow=${Math.round(this.alpha)}
                                          tabindex=${T(this.disabled?void 0:"0")}
                                          @keydown=${this.handleAlphaKeyDown}
                                      ></span>
                                  </div>
                              `:""}
                    </div>
                    <div
                        part="preview"
                        class="preview pixel-background"
                        style=${x({"--preview-color":this.getHexString(this.hue,this.saturation,this.brightness,this.alpha)})}
                    ></div>
                </div>

                <div class="user-input" aria-live="polite">
                    <pc-input
                        part="input"
                        class=${M({empty:this.isEmpty})}
                        type="text"
                        id="color-input"
                        name=${this.name}
                        size="small"
                        autocomplete="off"
                        autocorrect="off"
                        autocapitalize="off"
                        spellcheck="false"
                        value=${this.isEmpty?"":this.inputValue}
                        ?required=${this.required}
                        ?disabled=${this.disabled}
                        aria-label=${this.localize.term("currentValue")}
                        @keydown=${this.handleInputKeyDown}
                        @change=${this.handleInputChange}
                        @input=${this.handleInputInput}
                        @focus=${this.stopNestedEventPropagation}
                        @blur=${this.stopNestedEventPropagation}
                    >
                        ${this.isEmpty?null:y`
                                  <pc-copy-button
                                      part="copy-button"
                                      class="copy-button"
                                      from="color-input.value"
                                      slot="suffix"
                                      exportparts="button:copy-button-button"
                                  ></pc-copy-button>
                              `}
                    </pc-input>

                    <pc-button-group>
                        ${this.noFormatToggle?"":y`
                                  <pc-button
                                      part="format-button"
                                      size="small"
                                      variant="outlined"
                                      aria-label=${this.localize.term("toggleColorFormat")}
                                      exportparts="
                                          base:format-button-base,
                                          prefix:format-button-prefix,
                                          label:format-button-label,
                                          suffix:format-button-suffix
                                      "
                                      @click=${this.handleFormatToggle}
                                      @pc-focus=${this.stopNestedEventPropagation}
                                      @pc-blur=${this.stopNestedEventPropagation}
                                  >
                                      ${this.setLetterCase(this.format)}
                                  </pc-button>
                              `}
                        ${this.hasEyeDropper?y`
                                  <pc-button
                                      part="eyedropper-button"
                                      size="small"
                                      variant="outlined"
                                      exportparts="
                                          base:eyedropper-button-base,
                                          prefix:eyedropper-button-prefix,
                                          label:eyedropper-button-label,
                                          suffix:eyedropper-button-suffix,
                                      "
                                      @click=${this.handleEyeDropper}
                                      @pc-focus=${this.stopNestedEventPropagation}
                                      @pc-blur=${this.stopNestedEventPropagation}
                                  >
                                      <pc-icon
                                          library="system"
                                          icon-style="solid"
                                          name="eye-dropper"
                                          label=${this.localize.term("pickAColorFromTheScreen")}
                                      ></pc-icon>
                                  </pc-button>
                              `:""}
                    </pc-button-group>
                </div>

                ${p.length>0?y`
                          <div part="swatches" class="swatches">
                              ${p.map(u=>{let S=this.parseColor(u);return S?y`
                                      <div
                                          part="swatch"
                                          class="swatch pixel-background"
                                          tabindex=${T(this.disabled?void 0:"0")}
                                          role="button"
                                          aria-label=${u}
                                          @click=${()=>this.selectSwatch(u)}
                                          @keydown=${ft=>!this.disabled&&ft.key==="Enter"&&this.setColor(S.hexa)}
                                      >
                                          <div
                                              class="swatch-color"
                                              style=${x({backgroundColor:S.hexa})}
                                          ></div>
                                      </div>
                                  `:(console.error(`Unable to parse this swatch colour: ${u}`,this),"")})}
                          </div>
                      `:""}
                ${this.inline?y`
                          <slot class="pc-visually-hidden" name="hint">
                              ${this.hint}
                          </slot>
                      `:""}
            </div>
        `;return this.inline?b:y`
            <label
                part="label"
                class="label"
                id="label"
                aria-hidden=${s?"false":"true"}
            >
                <slot name="label">${this.label}</slot>
            </label>
            <pc-popup
                class="color-popup"
                part="popup"
                placement="bottom-start"
                distance="0"
                skidding="0"
                flip
                flip-fallback-strategy="best-fit"
                shift
                shift-padding="10"
                aria-disabled=${this.disabled?"true":"false"}
            >
                <button
                    type="button"
                    part="trigger"
                    slot="anchor"
                    class=${M({"popup-trigger":!0,empty:this.isEmpty,focused:this.hasFocus,"pixel-background":!0})}
                    style=${x({color:this.getHexString(this.hue,this.saturation,this.brightness,this.alpha)})}
                    .disabled=${this.disabled}
                    aria-labelledby="label"
                    @click=${this.handleTriggerClick}
                    @keydown=${this.handleTriggerKeyDown}
                    @keyup=${this.handleTriggerKeyUp}
                ></button>

                ${b}
            </pc-popup>

            <slot
                class=${M({"has-hint":a})}
                part="hint"
                id="hint"
                name="hint"
                aria-hidden=${a?"false":"true"}
            >
                ${this.hint}
            </slot>
        `}};h.css=[tt,_,dt],h.shadowRootOptions={...F.shadowRootOptions,delegatesFocus:!0},l([$('[part~="base"]')],h.prototype,"base",2),l([$('[part~="input"]')],h.prototype,"input",2),l([$('[part~="popup"]')],h.prototype,"popup",2),l([$('[part~="preview"]')],h.prototype,"previewButton",2),l([$('[part~="trigger"]')],h.prototype,"trigger",2),l([w()],h.prototype,"hasFocus",2),l([w()],h.prototype,"hasEyeDropper",2),l([w()],h.prototype,"isDraggingGridHandle",2),l([w()],h.prototype,"isEmpty",2),l([w()],h.prototype,"inputValue",2),l([w()],h.prototype,"hue",2),l([w()],h.prototype,"saturation",2),l([w()],h.prototype,"brightness",2),l([w()],h.prototype,"alpha",2),l([w()],h.prototype,"value",1),l([d({attribute:"value",reflect:!0})],h.prototype,"defaultValue",2),l([d()],h.prototype,"label",2),l([d()],h.prototype,"hint",2),l([d()],h.prototype,"format",2),l([d({type:Boolean,reflect:!0})],h.prototype,"inline",2),l([d({reflect:!0})],h.prototype,"size",2),l([d({attribute:"no-format-toggle",type:Boolean})],h.prototype,"noFormatToggle",2),l([d()],h.prototype,"name",2),l([d({type:Boolean})],h.prototype,"disabled",2),l([d({type:Boolean,reflect:!0})],h.prototype,"open",2),l([d({type:Boolean})],h.prototype,"opacity",2),l([d({type:Boolean})],h.prototype,"uppercase",2),l([d()],h.prototype,"swatches",2),l([d({type:Boolean,reflect:!0})],h.prototype,"required",2),l([Z({passive:!1})],h.prototype,"handleTouchMove",1),l([H("format",{waitUntilFirstUpdate:!0})],h.prototype,"handleFormatChange",1),l([H("opacity",{waitUntilFirstUpdate:!0})],h.prototype,"handleOpacityChange",1),l([H("value")],h.prototype,"handleValueChange",1),l([H("open",{waitUntilFirstUpdate:!0})],h.prototype,"handleOpenChange",1),h=l([W("pc-color-picker")],h);export{h as a};
