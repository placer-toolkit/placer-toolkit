var e=class extends Event{constructor(t){super("pc-select",{bubbles:!0,cancelable:!0,composed:!0}),this.detail=t}};export{e as a};
