import{a as g}from"./chunk.IX4OV3X6.js";import{a as l}from"./chunk.RXMQHF36.js";import{a as w}from"./chunk.BSQP4EKW.js";import{a as p}from"./chunk.OVU4POJI.js";import{a as y}from"./chunk.S5DN2ZZE.js";import{a as k}from"./chunk.AGGS6MN5.js";import{a as b}from"./chunk.NOX5TXXZ.js";import{a as x}from"./chunk.UPTMZCQ7.js";import{a as m,b as e,c as s,e as d}from"./chunk.PLBYMK2K.js";import{d as u}from"./chunk.FKNAQN55.js";import{a as v}from"./chunk.H2EOXVSZ.js";import{b as o}from"./chunk.E6MOE4FE.js";var E=`:host {
    display: inline-block;
    position: relative;
}

.button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    inline-size: 100%;
    block-size: var(--pc-form-control-height);
    background-color: var(--pc-color-fill-loud);
    color: var(--pc-color-on-loud);
    border: var(--pc-border-width-s) var(--pc-border-style) transparent;
    border-radius: var(--pc-form-control-border-radius);
    padding: 0 var(--pc-form-control-padding-inline);
    box-sizing: border-box;
    font-family: inherit;
    font-size: inherit;
    font-weight: var(--pc-font-weight-bold);
    line-height: calc(var(--pc-form-control-height) - var(--border-width) * 2);
    vertical-align: middle;
    white-space: nowrap;
    user-select: none;
    -webkit-user-select: none;
    cursor: pointer;
    text-align: center;
    text-decoration: none;
    transition: all var(--pc-transition-fast) ease-in-out;
}

.button::-moz-focus-inner {
    border: 0;
}

.button:focus {
    outline: none;
}

.button:focus-visible {
    outline: var(--pc-focus-ring);
    outline-offset: var(--pc-focus-ring-offset);
    animation: focus-ring-animation var(--pc-transition-medium)
        cubic-bezier(0.33, 1, 0.68, 1);
}

.prefix,
.suffix {
    display: flex;
    align-items: center;
    pointer-events: none;
}

.prefix::slotted(*) {
    margin-inline-end: 0.75em;
}

.suffix::slotted(*) {
    margin-inline-start: 0.75em;
}

.label {
    display: flex;
    transition: color var(--pc-transition-fast) ease-in-out;
}

.label::slotted(pc-icon) {
    align-self: center;
}

:host([pill]) .button {
    border-radius: var(--pc-border-radius-pill);
}

.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.disabled * {
    pointer-events: none;
}

.icon-button {
    aspect-ratio: 1 / 1;
    inline-size: var(--pc-form-control-height);
}

:host([variant~="accent"]) {
    .button {
        background-color: var(--pc-color-fill-loud);
        color: var(--pc-color-on-loud);
        border-color: transparent;
    }

    @media (hover: hover) {
        .button:not(.disabled):hover {
            background-color: color-mix(
                in oklab,
                var(--pc-color-fill-loud),
                var(--pc-color-mix-hover)
            );
        }
    }

    .button:not(.disabled):active {
        background-color: color-mix(
            in oklab,
            var(--pc-color-fill-loud),
            var(--pc-color-mix-active)
        );
    }
}

:host([variant~="outlined"]) {
    .button {
        background-color: transparent;
        color: var(--pc-color-on-quiet);
        border-color: var(--pc-color-border-loud);
    }

    @media (hover: hover) {
        .button:not(.disabled):hover {
            background-color: color-mix(
                in oklab,
                var(--pc-color-fill-quiet),
                var(--pc-color-mix-hover)
            );
            color: var(--pc-color-on-quiet);
        }
    }

    .button:not(.disabled):active {
        background-color: color-mix(
            in oklab,
            var(--pc-color-fill-quiet),
            var(--pc-color-mix-active)
        );
        color: var(--pc-color-on-quiet);
    }
}

:host([variant~="filled"]) {
    .button {
        background-color: var(--pc-color-fill-normal);
        color: var(--pc-color-on-normal);
        border-color: transparent;
    }

    @media (hover: hover) {
        .button:not(.disabled):hover {
            background-color: color-mix(
                in oklab,
                var(--pc-color-fill-normal),
                var(--pc-color-mix-hover)
            );
        }
    }

    .button:not(.disabled):active {
        background-color: color-mix(
            in oklab,
            var(--pc-color-fill-normal),
            var(--pc-color-mix-active)
        );
    }
}

:host([variant~="filled"][variant~="outlined"]) .button {
    border-color: var(--pc-color-border-normal);
}

:host([variant~="plain"]) {
    .button {
        background-color: transparent;
        color: var(--pc-color-on-quiet);
        border-color: transparent;
    }

    @media (hover: hover) {
        .button:not(.disabled):hover {
            background-color: color-mix(
                in oklab,
                var(--pc-color-fill-quiet),
                var(--pc-color-mix-hover)
            );
            color: var(--pc-color-on-quiet);
        }
    }

    .button:not(.disabled):active {
        background-color: color-mix(
            in oklab,
            var(--pc-color-fill-quiet),
            var(--pc-color-mix-active)
        );
        color: var(--pc-color-on-quiet);
    }
}

:host(
        .pc-button-group-horizontal.pc-button-group-button-first:not(
                .pc-button-group-button-last
            )
    )
    .button {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
}

:host(
        .pc-button-group-horizontal.pc-button-group-button-last:not(
                .pc-button-group-button-first
            )
    )
    .button {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
}

:host(
        .pc-button-group-vertical.pc-button-group-button-first:not(
                .pc-button-group-button-last
            )
    )
    .button {
    border-end-start-radius: 0;
    border-end-end-radius: 0;
}

:host(
        .pc-button-group-vertical.pc-button-group-button-last:not(
                .pc-button-group-button-first
            )
    )
    .button {
    border-start-start-radius: 0;
    border-start-end-radius: 0;
}

:host(.pc-button-group-button-inner) .button {
    border-radius: 0;
}

:host(.pc-button-group-button-hover),
:host(.pc-button-group-button-focus) {
    z-index: 1;
}

:host(.pc-button-group-button[checked]) {
    z-index: 2;
}

@keyframes focus-ring-animation {
    0% {
        outline-width: 0;
    }

    50% {
        outline-width: calc(var(--pc-focus-ring-width) * 2);
    }

    100% {
        outline-width: var(--pc-focus-ring-width);
    }
}
`;var t=class extends b{constructor(){super(...arguments);this.assumeInteractionOn=["click"];this.hasSlotController=new k(this,"[default]","prefix","suffix");this.hasFocus=!1;this.isIconButton=!1;this.invalid=!1;this.title="";this.appearance="neutral";this.variant="accent";this.size="medium";this.disabled=!1;this.pill=!1;this.type="button";this.name="";this.value="";this.href="";this.rel="noreferrer noopener"}static get validators(){return[...super.validators,y()]}constructLightDOMButton(){let r=document.createElement("button");for(let i of this.attributes)i.name!=="style"&&r.setAttribute(i.name,i.value);return r.hidden=!0,r.type=this.type,this.name&&(r.name=this.name),r.value=this.value||"",r}handleClick(r){if(this.disabled){r.preventDefault(),r.stopImmediatePropagation();return}if(this.type!=="submit"&&this.type!=="reset"||!this.getForm())return;let a=this.constructLightDOMButton();this.parentElement?.append(a),a.click(),a.remove()}handleInvalid(){this.dispatchEvent(new x)}handleLabelSlotChange(){let r=this.labelSlot.assignedNodes({flatten:!0}),i=!1,a=!1,f=!1,h=!1;[...r].forEach(n=>{if(n.nodeType===Node.ELEMENT_NODE){let c=n;c.localName==="pc-icon"?(a=!0,i||(i=c.label!==void 0)):h=!0}else n.nodeType===Node.TEXT_NODE&&(n.textContent?.trim()||"").length>0&&(f=!0)}),this.isIconButton=a&&!f&&!h,this.isIconButton&&!i&&console.warn(`<pc-icon> is missing an accessible label. Add a label attribute/property to help screen reader users. ${this}`)}isButton(){return!this.href}isLink(){return!!this.href}handleDisabledChange(){this.updateValidity()}setValue(...r){}click(){this.button.click()}focus(r){this.button.focus(r)}blur(){this.button.blur()}render(){return this.isLink()?u`
                <a
                    part="base"
                    class=${p({button:!0,disabled:this.disabled,focused:this.hasFocus,"icon-button":this.isIconButton,"has-label":this.hasSlotController.test("[default]"),"has-prefix":this.hasSlotController.test("prefix"),"has-suffix":this.hasSlotController.test("suffix")})}
                    href=${l(this.disabled?void 0:this.href)}
                    target=${l(this.target)}
                    download=${l(this.download)}
                    rel=${l(this.rel)}
                    aria-disabled=${this.disabled?"true":"false"}
                    tabindex=${this.disabled?"-1":"0"}
                    @click=${this.handleClick}
                >
                    <slot class="prefix" part="prefix" name="prefix"></slot>
                    <slot
                        class="label"
                        part="label"
                        @slotchange=${this.handleLabelSlotChange}
                    ></slot>
                    <slot class="suffix" part="suffix" name="suffix"></slot>
                </a>
            `:u`
                <button
                    part="base"
                    class=${p({button:!0,disabled:this.disabled,focused:this.hasFocus,"icon-button":this.isIconButton,"has-label":this.hasSlotController.test("[default]"),"has-prefix":this.hasSlotController.test("prefix"),"has-suffix":this.hasSlotController.test("suffix")})}
                    type=${this.type}
                    title=${this.title}
                    name=${this.name}
                    value=${this.value}
                    role="button"
                    aria-disabled=${this.disabled?"true":"false"}
                    tabindex=${this.disabled?"-1":"0"}
                    @click=${this.handleClick}
                    @invalid=${this.handleInvalid}
                >
                    <slot class="prefix" part="prefix" name="prefix"></slot>
                    <slot
                        class="label"
                        part="label"
                        @slotchange=${this.handleLabelSlotChange}
                    ></slot>
                    <slot class="suffix" part="suffix" name="suffix"></slot>
                </button>
            `}};t.shadowRootOptions={...b.shadowRootOptions,delegatesFocus:!0},t.css=[g,w,E],o([d(".button")],t.prototype,"button",2),o([d("slot:not([name])")],t.prototype,"labelSlot",2),o([s()],t.prototype,"hasFocus",2),o([s()],t.prototype,"isIconButton",2),o([s()],t.prototype,"invalid",2),o([e()],t.prototype,"title",2),o([e({reflect:!0})],t.prototype,"appearance",2),o([e({reflect:!0})],t.prototype,"variant",2),o([e({reflect:!0})],t.prototype,"size",2),o([e({type:Boolean})],t.prototype,"disabled",2),o([e({type:Boolean,reflect:!0})],t.prototype,"pill",2),o([e({reflect:!0})],t.prototype,"type",2),o([e()],t.prototype,"name",2),o([e()],t.prototype,"value",2),o([e()],t.prototype,"href",2),o([e()],t.prototype,"target",2),o([e()],t.prototype,"rel",2),o([e()],t.prototype,"download",2),o([e({attribute:"formaction"})],t.prototype,"formAction",2),o([e({attribute:"formenctype"})],t.prototype,"formEnctype",2),o([e({attribute:"formmethod"})],t.prototype,"formMethod",2),o([e({attribute:"formnovalidate",type:Boolean})],t.prototype,"formNoValidate",2),o([e({attribute:"formtarget"})],t.prototype,"formTarget",2),o([v("disabled",{waitUntilFirstUpdate:!0})],t.prototype,"handleDisabledChange",1),t=o([m("pc-button")],t);export{t as a};
