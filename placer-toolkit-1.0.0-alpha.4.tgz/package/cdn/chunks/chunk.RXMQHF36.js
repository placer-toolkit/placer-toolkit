import{f as o}from"./chunk.FKNAQN55.js";var e=t=>t??o;export{e as a};
/*! Bundled license information:

lit-html/directives/if-defined.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
