import{a as f,b as m,c as h,h as y}from"./chunk.FKNAQN55.js";import{b as d}from"./chunk.E6MOE4FE.js";var v=r=>(s,t)=>{t!==void 0?t.addInitializer((()=>{customElements.define(r,s)})):customElements.define(r,s)};var b={attribute:!0,type:String,converter:m,reflect:!1,hasChanged:h},x=(r=b,s,t)=>{let{kind:e,metadata:o}=t,i=globalThis.litPropertyMetadata.get(o);if(i===void 0&&globalThis.litPropertyMetadata.set(o,i=new Map),e==="setter"&&((r=Object.create(r)).wrapped=!0),i.set(t.name,r),e==="accessor"){let{name:n}=t;return{set(a){let l=s.get.call(this);s.set.call(this,a),this.requestUpdate(n,l,r)},init(a){return a!==void 0&&this.C(n,void 0,r,a),a}}}if(e==="setter"){let{name:n}=t;return function(a){let l=this[n];s.call(this,a),this.requestUpdate(n,l,r)}}throw Error("Unsupported decorator location: "+e)};function u(r){return(s,t)=>typeof t=="object"?x(r,s,t):((e,o,i)=>{let n=o.hasOwnProperty(i);return o.constructor.createProperty(i,e),n?Object.getOwnPropertyDescriptor(o,i):void 0})(r,s,t)}function q(r){return u({...r,state:!0,attribute:!1})}function I(r){return(s,t)=>{let e=typeof s=="function"?s:s[t];Object.assign(e,r)}}var c=(r,s,t)=>(t.configurable=!0,t.enumerable=!0,Reflect.decorate&&typeof s!="object"&&Object.defineProperty(r,s,t),t);function O(r,s){return(t,e,o)=>{let i=n=>n.renderRoot?.querySelector(r)??null;if(s){let{get:n,set:a}=typeof e=="object"?t:o??(()=>{let l=Symbol();return{get(){return this[l]},set(S){this[l]=S}}})();return c(t,e,{get(){let l=n.call(this);return l===void 0&&(l=i(this),(l!==null||this.hasUpdated)&&a.call(this,l)),l}})}return c(t,e,{get(){return i(this)}})}}function G(r){return(s,t)=>c(s,t,{async get(){return await this.updateComplete,this.renderRoot?.querySelector(r)??null}})}var g=`:host {
    box-sizing: border-box !important;
}

:host *,
:host *::before,
:host *::after {
    box-sizing: inherit !important;
}

[hidden] {
    display: none !important;
}
`;var p=class extends y{constructor(){super();this.hasRecordedInitialProperties=!1;this.initialReflectedProperties=new Map;this.customStates={set:(t,e)=>{if(this.internals?.states)try{e?this.internals.states.add(t):this.internals.states.delete(t)}catch(o){if(String(o).includes("must start with '--'"))console.error("Your browser implements an outdated version of `CustomStateSet`. Consider using a polyfill.");else throw o}},has:t=>this.internals?.states?this.internals.states.has(t):!1};try{this.internals=this.attachInternals()}catch{console.error("ElementInternals are not supported in your browser. Consider using a polyfill.")}this.customStates.set("pc-defined",!0);let t=this.constructor;for(let[e,o]of t.elementProperties)o.default==="inherit"&&o.initial!==void 0&&typeof e=="string"&&this.customStates.set(`initial-${e}-${o.initial}`,!0)}static get styles(){let t=Array.isArray(this.css)?this.css:this.css?[this.css]:[];return[g,...t].map(e=>typeof e=="string"?f(e):e)}attributeChangedCallback(t,e,o){this.hasRecordedInitialProperties||(this.constructor.elementProperties.forEach((i,n)=>{if(typeof n=="string"&&i.reflect){let a=this[n];a!=null&&this.initialReflectedProperties.set(n,a)}}),this.hasRecordedInitialProperties=!0),super.attributeChangedCallback(t,e,o)}willUpdate(t){super.willUpdate(t),this.initialReflectedProperties.forEach((e,o)=>{t.has(o)&&this[o]==null&&(this[o]=e)})}firstUpdated(t){super.firstUpdated(t)}relayNativeEvent(t,e){t.stopImmediatePropagation(),this.dispatchEvent(new t.constructor(t.type,{...t,...e}))}};d([u()],p.prototype,"lang",2),d([u()],p.prototype,"dir",2);export{v as a,u as b,q as c,I as d,O as e,G as f,p as g};
/*! Bundled license information:

@lit/reactive-element/decorators/custom-element.js:
@lit/reactive-element/decorators/property.js:
@lit/reactive-element/decorators/state.js:
@lit/reactive-element/decorators/event-options.js:
@lit/reactive-element/decorators/base.js:
@lit/reactive-element/decorators/query.js:
@lit/reactive-element/decorators/query-all.js:
@lit/reactive-element/decorators/query-async.js:
@lit/reactive-element/decorators/query-assigned-nodes.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-elements.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
