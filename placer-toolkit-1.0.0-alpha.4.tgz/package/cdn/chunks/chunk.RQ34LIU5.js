function i(e){return e.split(" ").map(t=>t.trim()).filter(t=>t!=="")}export{i as a};
