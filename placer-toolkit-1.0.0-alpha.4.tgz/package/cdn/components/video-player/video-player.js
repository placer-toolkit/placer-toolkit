import"../../chunks/chunk.P2244JYL.js";import{a as v}from"../../chunks/chunk.JWIAHBHS.js";import"../../chunks/chunk.YPZD6W7B.js";import"../../chunks/chunk.E3B4V4GT.js";import"../../chunks/chunk.OVU4POJI.js";import"../../chunks/chunk.SMFJUIOR.js";import"../../chunks/chunk.Y452TQZB.js";import"../../chunks/chunk.OOPBLVP2.js";import"../../chunks/chunk.OMC4FRTB.js";import"../../chunks/chunk.V52RFTK3.js";import"../../chunks/chunk.5C3US2KL.js";import"../../chunks/chunk.BQPFQFVC.js";import"../../chunks/chunk.GFCFF7RE.js";import"../../chunks/chunk.RZZMGXAZ.js";import"../../chunks/chunk.OOQOIJSK.js";import"../../chunks/chunk.AGGS6MN5.js";import{a as h,b as u,c,e as d,g as m}from"../../chunks/chunk.PLBYMK2K.js";import{d as l}from"../../chunks/chunk.FKNAQN55.js";import"../../chunks/chunk.H2EOXVSZ.js";import"../../chunks/chunk.N5AZOOIZ.js";import"../../chunks/chunk.TBG3XWQL.js";import"../../chunks/chunk.3MBXGS36.js";import"../../chunks/chunk.ZPHZCJBG.js";import"../../chunks/chunk.IONUBRP7.js";import"../../chunks/chunk.D4QD2XWD.js";import"../../chunks/chunk.TRNOKNPO.js";import"../../chunks/chunk.MV54FYCN.js";import{b as s}from"../../chunks/chunk.E6MOE4FE.js";var b=`:host {
    --control-offset: 0.5em;

    display: block;
    max-inline-size: 100%;
}

.frame {
    position: relative;
    aspect-ratio: 16 / 9;

    .title {
        position: absolute;
        inset-block-start: var(--pc-spacing-s);
        inset-inline-start: var(--pc-spacing-s);
        padding-block: var(--pc-spacing-xs);
        padding-inline: var(--pc-spacing-s);
        background-color: color-mix(
            in oklab,
            var(--pc-color-neutral-20),
            transparent 20%
        );
        color: var(--pc-color-neutral-90);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        border-radius: var(--pc-border-radius-m);
        font-size: var(--pc-font-size-s);
        opacity: 0;
        transition: opacity var(--pc-transition-fast) ease-in-out;
        z-index: 2;

        :host(.controls-visible) &,
        :host(:focus-within) & {
            opacity: 1;
        }
    }

    video {
        display: block;
        inline-size: 100%;
        block-size: 100%;
        border-radius: var(--pc-border-radius-l);
        box-shadow: var(--pc-shadow-l);
    }

    .captions {
        position: absolute;
        inset: 0;
        overflow: hidden;
        pointer-events: none;
        z-index: 2;

        .caption-line {
            position: absolute;
            inset: 0;

            .caption-cue {
                position: absolute;
                padding-block: var(--pc-spacing-xxs);
                padding-inline: var(--pc-spacing-xs);
                max-inline-size: 90%;
                background-color: color-mix(
                    in oklab,
                    var(--pc-color-neutral-20),
                    transparent 20%
                );
                color: var(--pc-color-neutral-90);
                border-radius: var(--pc-border-radius-s);
                font-family: var(--pc-font-sans);
                font-size: var(--pc-font-size-s);
                text-align: center;

                & ruby rt {
                    font-size: var(--pc-font-size-smaller);
                    line-height: var(--pc-line-height-densest);
                }

                :host(.controls-visible) & {
                    --control-offset: calc(
                        (var(--pc-spacing-m) * 3) + 2.25rem + 0.5em
                    );
                }
            }
        }
    }

    .bar {
        display: flex;
        align-items: center;
        position: absolute;
        inset-block-end: calc(2.25rem + (var(--pc-spacing-m) * 2));
        inset-inline: 0;
        padding-inline: var(--pc-spacing-m);
        block-size: 0.5em;
        opacity: 0;

        :host(.controls-visible) &,
        :host(:focus-within) & {
            opacity: 1;
        }

        .progress-wrapper {
            position: relative;
            inline-size: 100%;
            block-size: 100%;
            background-color: var(--pc-color-neutral-fill-normal);
            border-radius: var(--pc-border-radius-pill);

            .buffered {
                position: absolute;
                inset-block: 0;
                inset-inline-start: 0;
                inline-size: 0;
                background-color: var(--pc-color-neutral-border-normal);
                border-radius: inherit;
                pointer-events: none;
            }

            .progress {
                position: absolute;
                inset-block: 0;
                inset-inline-start: 0;
                margin: 0;
                inline-size: 100%;
                block-size: 100%;
                appearance: none;
                -webkit-appearance: none;
                background-color: transparent;
                border-radius: inherit;
                outline: none;
                touch-action: none;
                cursor: pointer;

                &::part(slider) {
                    margin-block-start: 0;
                }

                &::part(label) {
                    position: absolute !important;
                    margin: -1px !important;
                    padding: 0 !important;
                    inline-size: 1px !important;
                    block-size: 1px !important;
                    width: 1px !important;
                    height: 1px !important;
                    clip-path: inset(50%) !important;
                    border: none !important;
                    overflow: hidden !important;
                    white-space: nowrap !important;
                }

                &::part(track) {
                    background-color: transparent;
                }

                &::part(thumb) {
                    border: var(--pc-border-width-s) var(--pc-border-style)
                        var(--pc-color-primary-border-loud);
                }
            }
        }
    }

    .controls {
        display: flex;
        position: absolute;
        align-items: center;
        inset-block-end: var(--pc-spacing-m);
        inset-inline: var(--pc-spacing-m);
        gap: var(--pc-spacing-s);
        block-size: 2.25rem;
        opacity: 0;
        transition: opacity var(--pc-transition-fast) ease-in-out;

        :host(.controls-visible) &,
        :host(:focus-within) & {
            opacity: 1;
        }

        > pc-button,
        pc-button-group > pc-button,
        pc-button-group > pc-popup > pc-button {
            &::part(base),
            &::part(base) {
                background-color: color-mix(
                    in oklab,
                    var(--pc-color-neutral-20),
                    transparent 20%
                );
                color: var(--pc-color-neutral-90);
                backdrop-filter: blur(4px);
                -webkit-backdrop-filter: blur(4px);
                border-radius: var(--pc-border-radius-circle);

                @media (hover: hover) {
                    &:hover,
                    &:hover {
                        background-color: color-mix(
                            in oklab,
                            color-mix(
                                in oklab,
                                var(--pc-color-neutral-20),
                                transparent 20%
                            ),
                            var(--pc-color-mix-hover)
                        );
                    }
                }

                pc-button:not(.mute) &:active {
                    background-color: color-mix(
                        in oklab,
                        color-mix(
                            in oklab,
                            var(--pc-color-neutral-20),
                            transparent 20%
                        ),
                        var(--pc-color-mix-active)
                    );
                }
            }

            .mute {
                display: inline-flex;
                align-items: center;
                inline-size: var(--pc-form-control-height);
                transition: inline-size var(--pc-transition-fast) ease-in-out;

                @media (hover: hover) {
                    &:hover,
                    &:focus-within {
                        inline-size: calc(
                            var(--pc-form-control-height) + 4.375rem +
                                var(--pc-spacing-m)
                        );
                    }
                }

                @media (hover: none) {
                    & {
                        display: none;
                    }
                }

                &::part(base) {
                    aspect-ratio: auto;
                    inline-size: 100%;
                    border-radius: var(--pc-border-radius-pill);
                }

                .volume {
                    display: block;
                    margin: 0;
                    inline-size: 0;
                    opacity: 0;
                    pointer-events: none;
                    transition:
                        margin var(--pc-transition-fast) ease-in-out,
                        inline-size var(--pc-transition-fast) ease-in-out,
                        opacity var(--pc-transition-fast) ease-in-out;

                    @media (hover: hover) {
                        .mute:hover > &,
                        .mute:focus-within > & {
                            margin-inline-start: var(--pc-spacing-m);
                            inline-size: 4.375rem;
                            opacity: 1;
                            pointer-events: auto;
                        }
                    }

                    &::part(label) {
                        position: absolute !important;
                        margin: -1px !important;
                        padding: 0 !important;
                        inline-size: 1px !important;
                        block-size: 1px !important;
                        width: 1px !important;
                        height: 1px !important;
                        clip-path: inset(50%) !important;
                        border: none !important;
                        overflow: hidden !important;
                        white-space: nowrap !important;
                    }
                }
            }
        }

        pc-popup .settings-menu {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: var(--pc-spacing-s);
            inline-size: 15rem;
            background-color: color-mix(
                in oklab,
                var(--pc-color-neutral-20),
                transparent 20%
            );
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
            border-radius: calc(
                var(--pc-border-radius-m) + var(--pc-spacing-s)
            );

            pc-button {
                inline-size: 100%;

                &::part(base) {
                    background-color: transparent;

                    pc-button:has(> pc-icon[slot="suffix"]) & {
                        margin-inline-start: auto;
                    }

                    pc-button:not(:has(> pc-icon[slot="suffix"])) & {
                        justify-content: flex-start;
                    }

                    @media (hover: hover) {
                        &:hover {
                            background-color: color-mix(
                                in oklab,
                                transparent,
                                var(--pc-color-mix-hover)
                            ) !important;
                        }
                    }

                    &:active {
                        background-color: color-mix(
                            in oklab,
                            transparent,
                            var(--pc-color-mix-active)
                        ) !important;
                    }
                }
            }
        }

        .time-container {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding-inline: var(--pc-form-control-padding-inline);
            block-size: var(--pc-form-control-height);
            background-color: color-mix(
                in oklab,
                var(--pc-color-neutral-20),
                transparent 20%
            );
            color: var(--pc-color-neutral-90);
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
            border-radius: var(--pc-border-radius-pill);
            font-size: var(--pc-font-size-s);
            font-variant-numeric: tabular-nums;
            line-height: calc(var(--pc-form-control-height) * 2);
            user-select: none;
            -webkit-user-select: none;
            white-space: nowrap;
        }

        .spacer {
            flex: 1;
        }
    }
}
`;var r=class extends m{constructor(){super(...arguments);this.duration=0;this.current=0;this.volume=1;this.playbackRate=1;this.isPlaying=!1;this.captionsOn=!1;this.isMuted=!1;this.bufferedEnd=0;this.panel="main";this.hideTimeoutID=null;this.lastMousePosition=null;this.animationFrameID=null;this.isCompact=!1;this.isScrubbing=!1;this.scrubTime=null;this.activeCues=[];this.src="";this.poster="";this.autoplay=!1;this.muted=!1;this.loop=!1;this.preload="metadata";this.playsinline=!1;this.dataTitle="";this.updateCaptionsState=()=>{let t=this.video?.textTracks;this.captionsOn=t?Array.from(t).some(e=>e.mode==="showing"):!1,this.updateCuePosition()};this.toggleCaptions=()=>{let t=Array.from(this.video?.textTracks||[]);if(!t.length)return;let e=[...t].reverse().find(o=>o.mode==="showing")||t[0];e.mode=e.mode==="showing"?"disabled":"showing",t.forEach(o=>o!==e&&(o.mode="disabled")),this.captionsOn=e.mode==="showing",this.updateCuePosition()};this.onInputScrub=t=>{let e=Number(t.target.value)/1e3;this.isScrubbing?this.scrubTime=e:this.video.currentTime=e}}async firstUpdated(){let t=this.video;this.src&&(t.src=this.src),this.poster&&(t.poster=this.poster),t.autoplay=this.autoplay,t.muted=this.muted,t.loop=this.loop,t.preload=this.preload,t.playbackRate=this.playbackRate,this.playsinline&&t.setAttribute("playsinline","");let e=Array.from(this.querySelectorAll("track"));for(let i of e){let a=i.getAttribute("src");if(!a)continue;let p=await(await fetch(a)).text();this.applyVTTStyles(p)}new ResizeObserver(i=>{for(let a of i)this.isCompact=a.contentRect.width<500}).observe(this),t.addEventListener("loadedmetadata",()=>{this.duration=t.duration||0,this.current=t.currentTime||0,this.volume=t.volume,this.updateBuffered(),this.updateCaptionsState(),Array.from(t.textTracks||[]).forEach(i=>i.addEventListener("cuechange",this.updateCuePosition.bind(this))),this.updateCuePosition()}),t.addEventListener("timeupdate",()=>this.current=t.currentTime||0),t.addEventListener("progress",()=>this.updateBuffered()),t.addEventListener("play",()=>{this.isPlaying=!0,this.startUpdateLoop()}),t.addEventListener("pause",()=>{this.isPlaying=!1,this.stopUpdateLoop()}),t.addEventListener("volumechange",()=>{this.volume=t.volume,this.isMuted=t.muted||t.volume===0}),this.hasAttribute("tabindex")||this.setAttribute("tabindex","0"),this.addEventListener("keydown",i=>this.onKeyDown(i)),this.addEventListener("mousemove",i=>this.onUserInteraction(i)),this.addEventListener("touchstart",i=>this.onUserInteraction(i));let o=this.progress;o.valueFormatter=()=>this.formatTime(this.scrubTime??0),["pointerdown","pointermove","pointerup","pointercancel"].forEach(i=>{o.addEventListener(i,a=>{i==="pointerdown"?this.onScrubStart(a):i==="pointermove"?this.onScrubMove(a):this.onScrubEnd(a)})}),this.toggleControlVisibility(),this.addEventListener("mouseenter",()=>this.toggleControlVisibility(!0)),this.addEventListener("mouseleave",()=>this.toggleControlVisibility()),Array.from(this.renderRoot.querySelectorAll("pc-dropdown")).forEach(i=>{i.addEventListener("pc-show",()=>this.toggleControlVisibility(!0)),i.addEventListener("pc-hide",()=>this.toggleControlVisibility())})}formatTime(t){t=Math.max(0,Math.floor(t));let e=Math.floor(t/3600),o=Math.floor(t%3600/60),i=t%60;return e>0?`${e}:${String(o).padStart(2,"0")}:${String(i).padStart(2,"0")}`:`${o}:${String(i).padStart(2,"0")}`}extractVTTStyleBlock(t){let e=t.match(/STYLE([\s\S]*?)(\n\n|$)/);return e?e[1].trim():""}transformCueCSS(t){return t.replace(/::cue\(v\[voice="([^"]+)"\]\)/g,(e,o)=>`.caption-cue .voice[data-voice="${o}"]`).replace(/::cue\(\.([^)]+)\)/g,(e,o)=>`.caption-cue .${o}`).replace(/::cue/g,".caption-cue")}applyVTTStyles(t){let e=this.extractVTTStyleBlock(t);if(!e)return;let o=this.transformCueCSS(e);if(this.renderRoot.querySelector("style[data-vtt]")?.textContent?.includes(o))return;let i=document.createElement("style");i.setAttribute("data-vtt",""),i.textContent=o,this.renderRoot.appendChild(i)}setSpeed(t){this.playbackRate=t,this.video.playbackRate=t}onKeyDown(t){if(t.composedPath().some(a=>a.tagName?.toLowerCase().includes("pc-dropdown")||a.tagName?.toLowerCase().includes("pc-slider")||a.tagName?.toLowerCase()==="input"))return;switch(t.key.toLowerCase()){case" ":case"k":t.preventDefault(),this.toggle();break;case"m":this.video.muted=!this.video.muted;break;case"arrowright":this.video.currentTime=Math.min(this.video.currentTime+5,this.video.duration||1/0);break;case"arrowleft":this.video.currentTime=Math.max(this.video.currentTime-5,0);break;case"arrowup":this.video.volume=Math.min(this.video.volume+.05,1);break;case"arrowdown":this.video.volume=Math.max(this.video.volume-.05,0);break;case"f":this.toggleFullscreen();break;case"c":this.toggleCaptions();break;case"p":this.togglePiP();break}}scheduleHideControls(t=3e3){this.hideTimeoutID&&clearTimeout(this.hideTimeoutID),this.hideTimeoutID=window.setTimeout(()=>{window.matchMedia("(hover: hover)").matches?(this.lastMousePosition?Math.hypot(this.lastMousePosition.x-(this.lastMousePosition?.x??0),this.lastMousePosition.y-(this.lastMousePosition?.y??0)):0)<=3?this.classList.remove("controls-visible"):this.scheduleHideControls(t):this.classList.remove("controls-visible")},t)}onUserInteraction(t){this.lastMousePosition="touches"in t&&t.touches.length?{x:t.touches[0].clientX,y:t.touches[0].clientY}:{x:t.clientX,y:t.clientY},this.classList.add("controls-visible"),this.scheduleHideControls()}updateCuePosition(){let t=Array.from(this.video.textTracks||[]),e=[];t.forEach(o=>{o.mode==="showing"&&(o.mode="hidden"),o.mode==="hidden"&&o.activeCues&&e.push(...Array.from(o.activeCues))}),this.activeCues=e}toggleControlVisibility(t){let e=this.matches(":hover"),o=Array.from(this.renderRoot.querySelectorAll("pc-popup")).some(n=>n.active),i=window.matchMedia("(hover: hover)").matches,a;typeof t=="boolean"?a=t:i?a=e||o||!this.isPlaying:a=!0,this.classList.toggle("controls-visible",a),this.updateCuePosition()}handlePopupClick(){this.popup.active=!this.popup.active}noTextTracks(){let t=this.video?.textTracks;return!t||t.length===0}onCaptionSelection(t){this.setCaptionTrack(Number(t.detail.item.value))}setCaptionTrack(t){Array.from(this.video?.textTracks||[]).forEach((o,i)=>o.mode=i===t?"showing":"disabled"),this.updateCaptionsState()}startUpdateLoop(){let t=()=>{!this.video.paused&&!this.isScrubbing&&(this.progress.value=Math.floor(this.video.currentTime*1e3),Math.floor(this.current)!==Math.floor(this.video.currentTime)&&(this.current=this.video.currentTime),this.animationFrameID=requestAnimationFrame(t))};this.animationFrameID=requestAnimationFrame(t)}stopUpdateLoop(){this.animationFrameID&&(cancelAnimationFrame(this.animationFrameID),this.animationFrameID=null)}async togglePiP(){try{document.pictureInPictureElement?await document.exitPictureInPicture():document.pictureInPictureEnabled&&await this.video.requestPictureInPicture()}catch{}}toggleFullscreen(){document.fullscreenElement===this||this.renderRoot.fullscreenElement===this?(document.exitFullscreen?.(),this.fullScreen.querySelector("pc-icon").name="expand"):(this.requestFullscreen?.().catch(()=>{}),this.fullScreen.querySelector("pc-icon").name="compress")}onFrameBackgroundClick(t){!t.composedPath().some(e=>e?.classList?.contains?.("controls"))&&!this.isScrubbing&&this.toggle()}parseVTT(t,e){let o=e.position!=null&&e.position!=="auto"?e.position:50,i=e.align||"center",a,n;e.line==="auto"?n=0:n=100-Number(e.line),a=`
            bottom: max(${n}%, var(--control-offset));
        `;let p=i==="center"?50:i==="end"?100:0,f=t.replace(/<v\s+([^>]+)>/g,'<span class="voice" data-voice="$1">').replace(/<\/v>/g,"</span>").replace(/<c\.([^>]+)>/g,(T,g)=>`<span class="class ${g.split(".").join(" ")}">`).replace(/<\/c>/g,"</span>").replace(/<(\/?)(b|i|u|s)>/g,"<$1$2>").replace(/\n/g,"<br>");return`
            <span
                class="caption-cue"
                style="
                    position: absolute;
                    left: ${o}%;
                    transform: translateX(-${p}%);
                    ${a}
                    text-align: ${i};
                    width: max-content;
                    max-width: 90%;
                "
            >
                ${f}
            </span>
        `}updateBuffered(){let t=0;for(let e=0;e<this.video.buffered.length;e++)t=Math.max(t,this.video.buffered.end(e));this.bufferedEnd=t}onScrubStart(t){this.isScrubbing=!0,t.target.setPointerCapture?.(t.pointerId),this.updateScrubFromEvent(t)}onScrubMove(t){this.isScrubbing&&this.updateScrubFromEvent(t)}onSeeked(){this.isScrubbing=!1,this.scrubTime=null,this.isPlaying&&this.startUpdateLoop(),this.video.removeEventListener("seeked",this.onSeeked)}onScrubEnd(t){this.isScrubbing&&(t.target.releasePointerCapture?.(t.pointerId),this.scrubTime!=null&&(this.video.currentTime=this.scrubTime,this.video.addEventListener("seeked",this.onSeeked)))}updateScrubFromEvent(t){let e=this.progressWrapper.getBoundingClientRect(),o=Math.min(1,Math.max(0,(t.clientX-e.left)/e.width));this.scrubTime=o*this.duration}play(){return this.video.play()}pause(){this.video.pause()}toggle(){this.video.paused?this.video.play():this.video.pause()}render(){let t=this.formatTime(this.duration),e=this.formatTime(this.current),o=document.pictureInPictureEnabled,i=this.duration>0?this.bufferedEnd/this.duration*100:0,a=this.isScrubbing&&this.scrubTime!=null?this.scrubTime:this.current;return l`
            <div
                class="frame"
                role="region"
                aria-label="Video player"
                @click=${this.onFrameBackgroundClick}
            >
                ${this.dataTitle?l`<div class="title">${this.dataTitle}</div>`:void 0}

                <video
                    part="video"
                    crossorigin="anonymous"
                    @loadeddata=${this.updateCaptionsState}
                >
                    ${this.src?l`<source src="${this.src}" />`:""}
                    ${Array.from(this.querySelectorAll("track")).map(n=>l`
                            <track
                                kind="${n.getAttribute("kind")||"subtitles"}"
                                src="${n.getAttribute("src")}"
                                srclang="${n.getAttribute("srclang")}"
                                label="${n.getAttribute("label")}"
                                ?default="${n.hasAttribute("default")}"
                            />
                        `)}
                </video>

                <div class="captions" part="captions" aria-hidden="true">
                    ${this.activeCues.map(n=>l`
                            <div class="caption-line">
                                ${v(this.parseVTT(n.text,n))}
                            </div>
                        `)}
                </div>

                <div class="bar" part="bar">
                    <div part="progress-wrapper" class="progress-wrapper">
                        <div
                            class="buffered"
                            style="inline-size: ${i}%"
                        ></div>
                        <pc-slider
                            part="progress"
                            class="progress"
                            min="0"
                            .max=${Math.max(1,Math.floor(this.duration*1e3))}
                            .value=${Math.floor(a*1e3)}
                            step="1"
                            label="Seek"
                            has-tooltip
                            @input=${this.onInputScrub}
                        ></pc-slider>
                    </div>
                </div>

                <div class="controls" aria-label="Controls">
                    <pc-button
                        class="play"
                        variant="filled"
                        @click=${this.toggle.bind(this)}
                    >
                        ${this.isPlaying?l`
                                  <pc-icon
                                      library="system"
                                      icon-style="solid"
                                      name="pause"
                                      label="Pause"
                                  ></pc-icon>
                              `:l`
                                  <pc-icon
                                      library="system"
                                      icon-style="solid"
                                      name="play"
                                      label="Play"
                                  ></pc-icon>
                              `}
                    </pc-button>

                    <pc-button
                        class="mute"
                        size="small"
                        variant="filled"
                        @click=${()=>this.video.muted=!this.video.muted}
                    >
                        ${this.isMuted?l`
                                  <pc-icon
                                      library="system"
                                      icon-style="solid"
                                      name="volume-off"
                                      label="Mute"
                                  ></pc-icon>
                              `:l`
                                  <pc-icon
                                      library="system"
                                      icon-style="solid"
                                      name="volume-high"
                                      label="Unmute"
                                  ></pc-icon>
                              `}

                        <pc-slider
                            class="volume"
                            min="0"
                            max="1"
                            step="0.01"
                            .value=${this.volume}
                            label="Volume"
                            @click=${n=>n.stopPropagation()}
                            @input=${n=>{let p=Number(n.target.value);this.video.volume=p,this.video.muted=p===0}}
                            @pointerdown=${n=>n.stopPropagation()}
                        ></pc-slider>
                    </pc-button>

                    <div class="time-container">
                        ${e} / ${t}
                    </div>

                    <div class="spacer"></div>

                    <pc-button-group>
                        <pc-button
                            class="pip"
                            size="small"
                            variant="filled"
                            ?hidden=${!o}
                            @click=${this.togglePiP}
                        >
                            <pc-icon
                                library="system"
                                icon-style="solid"
                                name="picture-in-picture"
                                label="Picture in Picture"
                            ></pc-icon>
                        </pc-button>

                        <pc-popup placement="top-end" part="popup">
                            <pc-button
                                slot="anchor"
                                size="small"
                                variant="filled"
                                @click=${this.handlePopupClick}
                            >
                                <pc-icon
                                    library="default"
                                    icon-style="solid"
                                    name="gear"
                                ></pc-icon>
                            </pc-button>

                            <div
                                class="settings-menu"
                                id="settings-menu"
                                role="listbox"
                            >
                                ${this.panel==="main"?l`
                                          <pc-button
                                              @click=${()=>this.panel="speed"}
                                          >
                                              <pc-icon
                                                  library="system"
                                                  icon-style="solid"
                                                  name="gauge-high"
                                                  slot="prefix"
                                              ></pc-icon>
                                              Playback rate
                                              <pc-icon
                                                  library="system"
                                                  icon-style="solid"
                                                  name="chevron-right"
                                                  slot="suffix"
                                              ></pc-icon>
                                          </pc-button>

                                          <pc-button
                                              ?hidden=${this.noTextTracks()}
                                              @click=${()=>this.panel="captions"}
                                          >
                                              <pc-icon
                                                  library="system"
                                                  icon-style="solid"
                                                  name="closed-captioning"
                                                  slot="prefix"
                                              ></pc-icon>
                                              Captions
                                              <pc-icon
                                                  library="system"
                                                  icon-style="solid"
                                                  name="chevron-right"
                                                  slot="suffix"
                                              ></pc-icon>
                                          </pc-button>
                                      `:""}
                                ${this.panel==="speed"?l`
                                          <pc-button
                                              @click=${()=>this.panel="main"}
                                          >
                                              ← Back
                                          </pc-button>

                                          ${[.25,.5,1,1.5,2].map(n=>l`
                                                  <pc-button
                                                      @click=${()=>this.setSpeed(n)}
                                                  >
                                                      ${n}
                                                  </pc-button>
                                              `)}
                                      `:""}
                                ${this.panel==="captions"?l`
                                          <pc-button
                                              @click=${()=>this.panel="main"}
                                          >
                                              ← Back
                                          </pc-button>

                                          ${Array.from(this.video?.textTracks||[]).map((n,p)=>l`
                                                  <pc-button
                                                      @click=${()=>this.setCaptionTrack(p)}
                                                  >
                                                      ${n.label||`Track ${p+1}`}
                                                  </pc-button>
                                              `)}
                                      `:""}
                            </div>
                        </pc-popup>

                        <pc-button
                            class="full-screen"
                            part="full-screen"
                            size="small"
                            variant="filled"
                            @click=${this.toggleFullscreen}
                        >
                            <pc-icon
                                library="system"
                                icon-style="solid"
                                name="expand"
                                label="Full screen"
                            ></pc-icon>
                        </pc-button>
                    </pc-button-group>
                </div>
            </div>
        `}};r.css=b,s([d('[part~="video"]')],r.prototype,"video",2),s([d('[part~="progress-wrapper"]')],r.prototype,"progressWrapper",2),s([d('[part~="progress"]')],r.prototype,"progress",2),s([d('[part~="full-screen"]')],r.prototype,"fullScreen",2),s([d('[part~="captions"]')],r.prototype,"captions",2),s([d('[part~="popup"]')],r.prototype,"popup",2),s([c()],r.prototype,"duration",2),s([c()],r.prototype,"current",2),s([c()],r.prototype,"volume",2),s([c()],r.prototype,"playbackRate",2),s([c()],r.prototype,"isPlaying",2),s([c()],r.prototype,"captionsOn",2),s([c()],r.prototype,"isMuted",2),s([c()],r.prototype,"bufferedEnd",2),s([c()],r.prototype,"panel",2),s([c()],r.prototype,"hideTimeoutID",2),s([c()],r.prototype,"lastMousePosition",2),s([c()],r.prototype,"animationFrameID",2),s([c()],r.prototype,"isCompact",2),s([c()],r.prototype,"isScrubbing",2),s([c()],r.prototype,"scrubTime",2),s([c()],r.prototype,"activeCues",2),s([u()],r.prototype,"src",2),s([u()],r.prototype,"poster",2),s([u({type:Boolean,reflect:!0})],r.prototype,"autoplay",2),s([u({type:Boolean,reflect:!0})],r.prototype,"muted",2),s([u({type:Boolean,reflect:!0})],r.prototype,"loop",2),s([u()],r.prototype,"preload",2),s([u({type:Boolean,reflect:!0})],r.prototype,"playsinline",2),s([u({attribute:"data-title"})],r.prototype,"dataTitle",2),r=s([h("pc-video-player")],r);export{r as PcVideoPlayer};
