import{a,b,c}from"../chunks/chunk.N5AZOOIZ.js";import"../chunks/chunk.E6MOE4FE.js";export{c as getAnimation,b as setAnimation,a as setDefaultAnimation};
