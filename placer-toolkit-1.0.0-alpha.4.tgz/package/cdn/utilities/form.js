import{a}from"../chunks/chunk.EQSNSOXP.js";import"../chunks/chunk.E6MOE4FE.js";export{a as serialize};
