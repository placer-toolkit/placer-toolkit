import{a,b}from"../chunks/chunk.MV54FYCN.js";import"../chunks/chunk.E6MOE4FE.js";export{b as getKitCode,a as setKitCode};
